import { MENU, type CategoryId, type Dish } from "@/lib/data/menu";
import { SEED_REVIEWS } from "@/lib/data/content";

export type CartLine = {
  id: string;
  name: string;
  price: number;
  qty: number;
  image: string;
  category: CategoryId | string;
};

export type OrderInput = {
  customerName: string;
  phone: string;
  address?: string;
  area?: string;
  orderType: string;
  notes?: string;
  paymentMethod: string;
  promoCode?: string;
  items: CartLine[];
};

export type OrderTotals = {
  subtotal: number;
  deliveryFee: number;
  discount: number;
  total: number;
  itemCount: number;
};

export type OrderResult =
  | ({ ok: true; code: string; id: number; persisted: true; totals: OrderTotals })
  | ({ ok: true; code: string; id: null; persisted: false; totals: OrderTotals })
  | { ok: false; error: string };

export type ReviewInput = {
  name: string;
  city?: string;
  rating: number;
  title?: string;
  body: string;
  dish?: string;
};

export type StoredReview = {
  id: number | string;
  name: string;
  city: string;
  rating: number;
  title: string;
  body: string;
  dish?: string;
  date: string;
  source: string;
};

export function toDish(row: {
  id: string;
  name: string;
  category: string;
  description: string;
  price: number;
  oldPrice: number | null;
  image: string;
  tags: unknown;
  rating: number;
  serves: string | null;
  popular: boolean;
}): Dish {
  return {
    id: row.id,
    name: row.name,
    category: row.category as CategoryId,
    description: row.description,
    price: row.price,
    oldPrice: row.oldPrice ?? undefined,
    image: row.image,
    tags: Array.isArray(row.tags) ? (row.tags as string[]) : [],
    rating: row.rating,
    serves: row.serves ?? undefined,
    popular: row.popular,
  };
}

export { MENU, SEED_REVIEWS };
