/** Curated photography library (Pexels CDN) + locally generated brand imagery. */

const px = (id: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=900&h=700`;

const pxWide = (id: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1400&h=900`;

const pxNamed = (id: number, slug: string) =>
  `https://images.pexels.com/photos/${id}/${slug}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=900&h=700`;

export const IMG = {
  /* --- Rice, karahi & desi gravies --- */
  biryaniTop: px(18601877),
  biryaniPlatter: px(39536492),
  biryaniBrass: px(16020573),
  biryaniSides: px(37309267),
  biryaniRustic: px(36652961),
  biryaniTomato: px(8250738),
  pilaf: px(4439740),
  riceChicken: px(23830980),
  riceRestaurant: px(23547666),
  karahi: px(39378356),
  haleem: px(40262785),
  curryAlmond: px(37309417),
  lambCurry: px(30203318),
  lambSpicy: px(30203312),

  /* --- BBQ & kababs --- */
  bbqSkewers: px(37058646),
  bbqCharcoal: px(27668700),
  kebabCoals: px(36890237),
  kebabOutdoor: px(38843568),
  skewersGrill: px(12738462),
  kebabYemen: px(31249644),
  kebabSizzle: px(37080253),
  kebabSmoke: px(29259327),

  /* --- Burgers & fast food --- */
  burgerDark: px(28828555),
  burgerTray: px(12129480),
  burgerCombo: px(31300959),
  burgerBoard: px(15476362),
  burgerBeef: px(6006599),
  burgerCheese: px(35832465),
  burgerBlack: px(28272159),
  burgerLava: px(16148038),

  /* --- Pizza --- */
  pizzaWhite: px(9685234),
  pizzaMargherita: px(17932142),
  pizzaBoard: px(3343620),
  pizzaFlatlay: px(5848277),
  pizzaSlice: px(18437685),
  pizzaOven: px(32764481),

  /* --- Chinese --- */
  chowMein: px(8895736),
  friedRice: px(3727196),
  asianFusion: px(36388450),
  noodlesPlate: px(36701464),
  wokFlame: px(3054690),
  noodlesWok: px(5602458),
  padSeeEw: px(35063430),
  noodlesBowl: px(28895971),
  chineseKitchen: px(32513359),

  /* --- Continental --- */
  steakFlame: px(34003513),
  steakPasta: px(27200330),
  fishPlate: px(19615785),
  steakVeg: px(35546723),
  steakRisotto: px(4001870),
  steakSides: px(29221429),

  /* --- Pasta --- */
  pastaChicken: px(10165859),
  carbonara: px(40798219),
  macTomato: px(885468),
  pastaBowl: px(10165873),
  alfredo: px(13294544),
  macCheese: px(40646834),

  /* --- Breakfast --- */
  omeletteParatha: px(40864814),
  parathaChai: px(28885201),
  omeletteTea: px(35238489),
  streetTea: px(38834852),
  flatbreadTea: px(35079286),
  parathaTawa: px(38834853),

  /* --- Shawarma, wraps & fries --- */
  shawarmaCut: px(5779364),
  shawarmaWrap: px(29306505),
  donerPlate: px(16022887),
  shawarmaFries: px(37322775),
  kebabPlate: px(18852568),
  shawarmaWood: px(37322774),
  friesPlate: px(19297802),
  friesBasket: px(17354196),
  friesParmesan: px(28992238),
  friesMetal: px(13161027),
  friesRustic: px(1586942),

  /* --- Desserts --- */
  brownieIce: px(33312980),
  brownieCream: px(683499),
  chocCake: px(21564311),
  chocSyrup: px(9500628),
  caramelCake: px(5163947),
  lavaCake: px(14457501),
  kheer: px(31109623),
  gulabJamunPot: px(30577321),
  gulabJamunSyrup: px(9198596),
  gulabJamunBowl: px(7406887),
  gulabJamunWhite: px(37294501),
  jamunCheesecake: px(35021308),
  kulfi: px(36576778),
  falooda: px(18646641),
  iceCreamCups: px(1362534),
  sundae: px(38371324),
  iceCone: px(39798836),

  /* --- Beverages --- */
  fruitShakes: px(3948523),
  juices: pxNamed(4239, "restaurant-drink-colorful-colourful"),
  strawberrySmoothie: px(20205945),
  tropicalSmoothie: px(20205953),
  strawberryGlass: px(8743884),
  juiceTable: px(8215110),
  cappuccinoSaucer: px(6747870),
  latteArt: px(19252265),
  latteHeart: px(2226091),
  greenCup: px(111159),
  coffeeDark: px(244407),

  /* --- Soups --- */
  soupCorn: px(29538430),
  soupWhite: px(29538427),
  soupBlue: px(29538431),
  bowlsSoup: px(39851695),

  /* --- Interior, kitchen & lifestyle --- */
  cafeLamps: pxWide(4577715),
  romanticTable: pxWide(36747296),
  elegantDark: pxWide(14803087),
  dimTable: pxWide(34723813),
  chandeliers: pxWide(19343364),
  marbleTable: pxWide(11689788),
  candleTable: pxWide(36747300),
  roundTables: pxWide(11906296),
  chefGrill: pxWide(5779787),
  kitchenFlame: pxWide(16547110),
  chefFlame: pxWide(5779781),
  chefBW: pxWide(36073025),
  chefPortraitFlame: pxWide(36073022),
  picnicSpread: pxWide(17549690),
  medSpread: pxWide(7239432),
  festiveTable: pxWide(36579873),
  buffetTable: pxNamed(5927, "food-salad-red-lunch"),
  breadBoard: pxWide(3756523),
} as const;

/** Locally generated brand imagery (always available, no network needed). */
export const LOCAL = {
  heroFeast: "/images/hero-feast.jpg",
  owner: "/images/owner-faiz-guru.jpg",
  interior: "/images/interior.jpg",
  delivery: "/images/delivery.jpg",
} as const;

export type ImageKey = keyof typeof IMG;
