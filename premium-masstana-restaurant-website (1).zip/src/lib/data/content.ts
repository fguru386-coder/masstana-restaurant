import { IMG, LOCAL } from "./images";

/* ------------------------------------------------------------------ */
/*  OFFERS & PROMO CODES                                               */
/* ------------------------------------------------------------------ */

export type Offer = {
  code: string;
  title: string;
  subtitle: string;
  description: string;
  kind: "percent" | "flat" | "free-delivery";
  value: number;
  minOrder: number;
  maxDiscount?: number;
  validUntil: string;
  image: string;
  badge: string;
  terms: string[];
  featured?: boolean;
};

export const OFFERS: Offer[] = [
  {
    code: "MASS10",
    title: "10% Off Every Order",
    subtitle: "All menu · all day",
    description:
      "Flat 10% off your entire bill on dine-in, takeaway and home delivery. No minimum spend games.",
    kind: "percent",
    value: 10,
    minOrder: 500,
    maxDiscount: 1500,
    validUntil: "Ongoing offer",
    image: IMG.biryaniTop,
    badge: "Most used",
    terms: ["Minimum order Rs 500", "Maximum discount capped at Rs 1,500", "Cannot be combined with other codes"],
    featured: true,
  },
  {
    code: "FAMILY20",
    title: "20% Off Family Deals",
    subtitle: "Family & party platters",
    description:
      "Weekend feast saver — 20% off on family biryani boxes, family deals and BBQ party platters.",
    kind: "percent",
    value: 20,
    minOrder: 2000,
    maxDiscount: 2500,
    validUntil: "Fri – Sun",
    image: IMG.festiveTable,
    badge: "Weekends",
    terms: ["Valid Friday to Sunday", "Minimum order Rs 2,000", "Maximum discount Rs 2,500"],
    featured: true,
  },
  {
    code: "STUDENT15",
    title: "Student Pocket Saver",
    subtitle: "15% off with student ID",
    description:
      "Students of Sargodha University, UCF, NUML & Punjab Group colleges get 15% off every bill.",
    kind: "percent",
    value: 15,
    minOrder: 600,
    maxDiscount: 800,
    validUntil: "Semester offer",
    image: IMG.shawarmaWood,
    badge: "Students",
    terms: ["Show a valid student ID at the counter or share a photo on WhatsApp", "Minimum order Rs 600"],
    featured: true,
  },
  {
    code: "FREESHIP",
    title: "Free Home Delivery",
    subtitle: "On orders above Rs 1,500",
    description:
      "We waive the delivery fee entirely on qualifying orders inside all covered Sargodha zones.",
    kind: "free-delivery",
    value: 0,
    minOrder: 1500,
    validUntil: "Ongoing offer",
    image: LOCAL.delivery,
    badge: "Delivery",
    terms: ["Delivery only (not pickup)", "Within 18 km of 49 Tail, Sargodha"],
    featured: true,
  },
  {
    code: "BBQ25",
    title: "25% Off BBQ Nights",
    subtitle: "Grill platters after 8 PM",
    description:
      "Charcoal grill hour — seekh kabab, malai boti, tikka and mixed BBQ platters at a quarter off.",
    kind: "percent",
    value: 25,
    minOrder: 1500,
    maxDiscount: 2000,
    validUntil: "Daily 8 PM – 1 AM",
    image: IMG.bbqSkewers,
    badge: "Late night",
    terms: ["Applies to BBQ category items", "Daily from 8:00 PM"],
  },
  {
    code: "LATE15",
    title: "Midnight Craving 15%",
    subtitle: "11 PM – 2 AM",
    description: "Late night menu discount on nihari, haleem, karahi, paratha rolls and chai.",
    kind: "percent",
    value: 15,
    minOrder: 700,
    maxDiscount: 1000,
    validUntil: "Nightly",
    image: IMG.kebabSizzle,
    badge: "After hours",
    terms: ["Valid only between 11 PM and 2 AM"],
  },
  {
    code: "FIRST500",
    title: "Rs 500 Off First Order",
    subtitle: "New online customers",
    description: "Your first online order gets Rs 500 off when you spend Rs 2,000 or more.",
    kind: "flat",
    value: 500,
    minOrder: 2000,
    validUntil: "First order only",
    image: IMG.burgerCombo,
    badge: "New here",
    terms: ["One use per phone number", "Minimum order Rs 2,000"],
  },
  {
    code: "SWEET100",
    title: "Rs 100 Off Desserts",
    subtitle: "Sweet endings",
    description: "Add any two desserts and we take Rs 100 off — kheer, brownie, kulfi falooda or cake.",
    kind: "flat",
    value: 100,
    minOrder: 800,
    validUntil: "Ongoing offer",
    image: IMG.brownieIce,
    badge: "Desserts",
    terms: ["At least two dessert items in the cart", "Minimum order Rs 800"],
  },
];

export const OFFER_BY_CODE = OFFERS.reduce(
  (acc, o) => ({ ...acc, [o.code.toUpperCase()]: o }),
  {} as Record<string, Offer>,
);

export function evaluatePromo(
  code: string,
  subtotal: number,
  deliveryFee: number,
): { ok: boolean; discount: number; message: string; offer?: Offer } {
  const key = code.trim().toUpperCase();
  if (!key) return { ok: false, discount: 0, message: "Enter a promo code." };
  const offer = OFFER_BY_CODE[key];
  if (!offer) return { ok: false, discount: 0, message: `"${key}" is not a valid code.` };
  if (subtotal < offer.minOrder) {
    return {
      ok: false,
      discount: 0,
      message: `Add Rs ${(offer.minOrder - subtotal).toLocaleString("en-PK")} more — code needs Rs ${offer.minOrder.toLocaleString("en-PK")}.`,
    };
  }
  if (offer.kind === "percent") {
    const raw = (subtotal * offer.value) / 100;
    const discount = Math.round(offer.maxDiscount ? Math.min(raw, offer.maxDiscount) : raw);
    return {
      ok: true,
      discount,
      offer,
      message: `${offer.value}% applied — you saved Rs ${discount.toLocaleString("en-PK")}.`,
    };
  }
  if (offer.kind === "free-delivery") {
    return {
      ok: true,
      discount: deliveryFee,
      offer,
      message: deliveryFee > 0 ? "Delivery fee waived — enjoy it on us." : "Delivery is already free on this order.",
    };
  }
  const discount = Math.min(offer.value, subtotal);
  return {
    ok: true,
    discount,
    offer,
    message: `Rs ${discount.toLocaleString("en-PK")} off applied.`,
  };
}

/* ------------------------------------------------------------------ */
/*  DELIVERY ZONES (Sargodha)                                          */
/* ------------------------------------------------------------------ */

export type DeliveryZone = {
  area: string;
  fee: number;
  eta: string;
  distance: string;
};

export const DELIVERY_ZONES: DeliveryZone[] = [
  { area: "49 Tail & Satellite Town", fee: 120, eta: "20–30 min", distance: "0–3 km" },
  { area: "University Road / UCF Area", fee: 150, eta: "25–35 min", distance: "3–5 km" },
  { area: "Bhowana Bazaar & Trust Plaza", fee: 130, eta: "20–30 min", distance: "2–4 km" },
  { area: "Khayyam Chowk to Jinnah Colony", fee: 140, eta: "25–35 min", distance: "3–6 km" },
  { area: "Gulshan-e-Iqbal & Shaheen Town", fee: 180, eta: "30–40 min", distance: "5–8 km" },
  { area: "Sillanwali Road", fee: 160, eta: "30–40 min", distance: "4–7 km" },
  { area: "Sargodha Cantt & PAF Area", fee: 170, eta: "30–45 min", distance: "5–9 km" },
  { area: "Faisalabad Road (up to Chak)", fee: 220, eta: "40–55 min", distance: "9–14 km" },
  { area: "Mianwali Road & Bhikhi Kalan", fee: 250, eta: "45–60 min", distance: "12–18 km" },
  { area: "Outside 18 km radius", fee: 0, eta: "Call to confirm", distance: "18 km+" },
];

/* ------------------------------------------------------------------ */
/*  GALLERY                                                            */
/* ------------------------------------------------------------------ */

export type GalleryItem = { src: string; alt: string; group: string; tall?: boolean };

export const GALLERY: GalleryItem[] = [
  { src: LOCAL.heroFeast, alt: "Masstana signature feast spread with biryani and BBQ", group: "Signature", tall: true },
  { src: IMG.bbqCharcoal, alt: "Kebab skewers grilling over glowing charcoal", group: "BBQ" },
  { src: LOCAL.interior, alt: "Masstana dining room with warm gold lighting", group: "Interior", tall: true },
  { src: IMG.biryaniBrass, alt: "Chicken biryani served on a brass plate", group: "Signature" },
  { src: IMG.chefGrill, alt: "Chef grilling kebabs over an open flame", group: "Kitchen" },
  { src: IMG.burgerDark, alt: "Smoky BBQ burger with fries on a dark table", group: "Fast Food" },
  { src: IMG.karahi, alt: "Chicken karahi simmering in a traditional pan", group: "Signature", tall: true },
  { src: IMG.pizzaOven, alt: "Brick oven pizza with melted cheese", group: "Fast Food" },
  { src: IMG.chowMein, alt: "Wok tossed chicken chow mein noodles", group: "Chinese" },
  { src: IMG.chandeliers, alt: "Golden chandeliers above restaurant tables", group: "Interior" },
  { src: IMG.kitchenFlame, alt: "Chef working the flame in a busy kitchen", group: "Kitchen", tall: true },
  { src: IMG.brownieIce, alt: "Warm chocolate brownie with vanilla ice cream", group: "Desserts" },
  { src: IMG.falooda, alt: "Kulfi falooda topped with pistachio and rose syrup", group: "Desserts" },
  { src: IMG.fruitShakes, alt: "Fresh fruit shakes served in glass cups", group: "Drinks" },
  { src: IMG.steakFlame, alt: "Charcoal grilled ribeye steak plated", group: "Continental", tall: true },
  { src: IMG.donerPlate, alt: "Chicken doner plate with hummus and pita", group: "Fast Food" },
  { src: IMG.candleTable, alt: "Candlelit table setting for two", group: "Interior" },
  { src: IMG.haleem, alt: "Special chicken haleem garnished with mint and lime", group: "Signature" },
  { src: IMG.noodlesPlate, alt: "Chicken manchurian with peppers and spring onion", group: "Chinese" },
  { src: LOCAL.delivery, alt: "Masstana rider delivering food at night", group: "Delivery", tall: true },
  { src: IMG.omeletteParatha, alt: "Desi omelette served with hot paratha", group: "Breakfast" },
  { src: IMG.streetTea, alt: "Doodh patti chai being poured at the tea counter", group: "Drinks" },
  { src: IMG.kebabSizzle, alt: "Juicy kebabs sizzling on the barbecue", group: "BBQ" },
  { src: IMG.marbleTable, alt: "Marble table seating inside the restaurant", group: "Interior" },
];

export const GALLERY_GROUPS = ["All", ...Array.from(new Set(GALLERY.map((g) => g.group)))];

/* ------------------------------------------------------------------ */
/*  REVIEWS (seeded)                                                   */
/* ------------------------------------------------------------------ */

export type Review = {
  id?: number;
  name: string;
  city: string;
  rating: number;
  title: string;
  body: string;
  date?: string;
  source?: string;
  dish?: string;
};

export const SEED_REVIEWS: Review[] = [
  {
    name: "Hamza Tariq",
    city: "Satellite Town, Sargodha",
    rating: 5,
    title: "Best biryani in Sargodha, hands down",
    body: "I have tried every biryani spot in the city. Masstana's dum biryani is on another level — the rice is separate, the masala is deep and the chicken is never dry. Faiz Guru bhai personally asked if everything was fine.",
    date: "2026-01-18",
    source: "Google",
    dish: "Masstana Chicken Biryani",
  },
  {
    name: "Ayesha Noor",
    city: "University Road, Sargodha",
    rating: 5,
    title: "Delivery reached in 28 minutes, still steaming",
    body: "Ordered the family deal for a get-together. Packed beautifully, nothing spilled, and the karahi was hot enough to burn my fingers. Online ordering through the website was super easy.",
    date: "2026-02-02",
    source: "Website",
    dish: "Masstana Family Deal",
  },
  {
    name: "Bilal Ahmed Khan",
    city: "Khayyam Chowk, Sargodha",
    rating: 4,
    title: "BBQ platter is worth every rupee",
    body: "The charcoal BBQ platter with malai boti and seekh kabab is my Friday ritual. Only reason for four stars is that it gets crowded on weekends — book a table early.",
    date: "2025-12-21",
    source: "Google",
    dish: "Charcoal BBQ Mixed Platter",
  },
  {
    name: "Sana Malik",
    city: "Gulshan-e-Iqbal, Sargodha",
    rating: 5,
    title: "Finally a place with real Chinese",
    body: "Chicken shashlik on the iron plate came sizzling exactly like Lahore restaurants. The chow mein had proper wok flavour, not that soggy version you usually get in small cities.",
    date: "2026-01-30",
    source: "Foodpanda",
    dish: "Iron Plate Chicken Shashlik",
  },
  {
    name: "Usman Javed",
    city: "Sargodha Cantt",
    rating: 5,
    title: "Student deal saved my semester",
    body: "Rs 649 for shawarma, fries and a drink with a student discount — unbeatable near UCF. The staff never makes you feel bad about a small order.",
    date: "2026-02-11",
    source: "Website",
    dish: "Student Pocket Deal",
  },
  {
    name: "Fatima Rizvi",
    city: "Bhowana Bazaar, Sargodha",
    rating: 5,
    title: "Halwa puri breakfast is a ritual now",
    body: "Every Sunday morning my family comes for halwa puri and doodh patti chai. The puris are always fresh, halwa is not oily, and the tea is thick the way it should be.",
    date: "2026-01-05",
    source: "Facebook",
    dish: "Halwa Puri Special",
  },
  {
    name: "Zain Abbas",
    city: "Sillanwali Road, Sargodha",
    rating: 4,
    title: "Great steaks for a small city",
    body: "Did not expect a proper ribeye with peppercorn sauce in Sargodha. Cooked medium as requested. Portion is big enough for two if you add a side.",
    date: "2025-11-28",
    source: "Google",
    dish: "Charcoal Ribeye Steak",
  },
  {
    name: "Maryam Sheikh",
    city: "Shaheen Town, Sargodha",
    rating: 5,
    title: "Kulfi falooda & warm brownie = heaven",
    body: "Desserts are made in-house and it shows. The warm brownie with ice cream arrives hot and cold at the same time. My kids ask for it by name.",
    date: "2026-02-14",
    source: "Instagram",
    dish: "Warm Brownie & Ice Cream",
  },
  {
    name: "Rao Abdul Rehman",
    city: "Jinnah Colony, Sargodha",
    rating: 5,
    title: "Nihari that reminds me of old Delhi",
    body: "Thick, glossy and full of marrow. The ginger and lemon garnish is generous. I order it every winter morning before work.",
    date: "2025-12-09",
    source: "WhatsApp",
    dish: "Shahi Beef Nihari",
  },
  {
    name: "Nimra Aslam",
    city: "Faisalabad Road, Sargodha",
    rating: 5,
    title: "Party platter for 40 guests — flawless",
    body: "We booked the BBQ party platter for my brother's engagement. Everything was on time, quantity was honest, and guests kept asking which restaurant it was.",
    date: "2026-01-22",
    source: "Phone order",
    dish: "BBQ Party Platter",
  },
];

/* ------------------------------------------------------------------ */
/*  FAQ                                                                */
/* ------------------------------------------------------------------ */

export type Faq = { q: string; a: string; group: string };

export const FAQS: Faq[] = [
  {
    group: "Ordering",
    q: "How do I place an online order on this website?",
    a: "Browse the Menu page, tap “Add to Cart” on any dish, then open the cart drawer and press Checkout. Fill in your name, phone number, delivery address and any cooking notes. Your order is recorded and a formatted WhatsApp message is generated so you can confirm it with us in one tap.",
  },
  {
    group: "Ordering",
    q: "Is this ordering system live or a demo?",
    a: "The cart, pricing, delivery calculation, promo codes and order records all work in this build — orders are written to the restaurant database and you receive an order code. The only thing you must personalise before going live is the WhatsApp number, which currently uses the placeholder YOUR_WHATSAPP_NUMBER in src/lib/site.ts.",
  },
  {
    group: "Ordering",
    q: "Do I need an account to order?",
    a: "No account and no password. Your cart is stored on your own device in the browser, so you can close the tab and come back later to finish the order.",
  },
  {
    group: "Delivery",
    q: "Which areas of Sargodha do you deliver to?",
    a: "We deliver within an 18 km radius of 49 Tail, Sargodha — including Satellite Town, University Road, Bhowana Bazaar, Khayyam Chowk, Jinnah Colony, Gulshan-e-Iqbal, Shaheen Town, Sillanwali Road, Cantt, Faisalabad Road and Bhikhi Kalan. Each zone has its own fee and estimated time listed on the Home Delivery page.",
  },
  {
    group: "Delivery",
    q: "What are the delivery charges?",
    a: "Delivery starts at Rs 120 inside Satellite Town and goes up to Rs 250 for outer zones. Orders above Rs 3,000 get free delivery automatically, and the FREESHIP code waives the fee on orders above Rs 1,500.",
  },
  {
    group: "Delivery",
    q: "How long does delivery take?",
    a: "Most orders reach you in 25–40 minutes. BBQ and karahi orders take a little longer because they are cooked after you order. On Friday nights and Eid days, please allow an extra 15–20 minutes.",
  },
  {
    group: "Menu",
    q: "Is all your meat halal?",
    a: "Yes. 100% of our meat, chicken and dairy is halal certified and sourced daily from trusted Sargodha suppliers. Nothing is frozen for more than 24 hours.",
  },
  {
    group: "Menu",
    q: "Can you make the food less spicy or without onions?",
    a: "Absolutely. Add your preference in the “Order notes” box at checkout — mild, medium or extra spicy, no onion, no mayo, extra naan, separate gravy. Our kitchen reads every note before plating.",
  },
  {
    group: "Menu",
    q: "Do you have vegetarian options?",
    a: "Yes — daal mash chawal, arrabiata penne, baked mac & cheese, garden salad, halwa puri, aloo paratha, masala fries, kheer, gulab jamun, fresh juices and lassi are all meat-free. Filter the menu with the “Vegetarian” chip.",
  },
  {
    group: "Reservations & Events",
    q: "Can I book a table for a family dinner or birthday?",
    a: "Call the restaurant or send us a message on the Contact page with your date, time and number of guests. We hold tables for up to 20 minutes past your reservation time. Birthday cakes and decoration can be arranged one day in advance.",
  },
  {
    group: "Reservations & Events",
    q: "Do you cater weddings and office events?",
    a: "Yes. Our party platters serve 6–8 people and we cater events of up to 400 guests with biryani deg, BBQ counters and live chaat stations. Share your headcount and menu on the Contact page and we will send a quotation within 24 hours.",
  },
  {
    group: "Payments",
    q: "What payment methods do you accept?",
    a: "Cash on delivery and cash at the counter are the standard methods. Bank transfer, EasyPaisa, JazzCash and card payments can be arranged for bulk and event orders — mention it in your order notes.",
  },
  {
    group: "Payments",
    q: "Are prices in PKR and do they include tax?",
    a: "All prices on this website are in Pakistani Rupees (PKR) and are menu prices. Applicable government taxes or service charges, if any, are shown separately on your bill at checkout.",
  },
  {
    group: "Hygiene & Quality",
    q: "How do you keep the food hot during delivery?",
    a: "Karahi and handi are sealed with foil and packed in insulated thermal bags. BBQ is wrapped in butter paper and aluminium to hold the smoke. Cold desserts and drinks travel in a separate chilled compartment.",
  },
  {
    group: "Hygiene & Quality",
    q: "Something was wrong with my order — what should I do?",
    a: "Contact us within 30 minutes with your order code and a photo. Genuine mistakes are replaced free of charge or fully refunded. Call the restaurant or message us on WhatsApp — we would rather fix it than lose your trust.",
  },
];

/* ------------------------------------------------------------------ */
/*  ABOUT / HOME CONTENT                                               */
/* ------------------------------------------------------------------ */

export const STATS = [
  { value: "12+", label: "Years of service" },
  { value: "96", label: "Dishes on the menu" },
  { value: "4.8", label: "Average guest rating" },
  { value: "90K+", label: "Orders delivered" },
];

export const FEATURES = [
  {
    icon: "flame",
    title: "Live charcoal grill",
    body: "Every kabab, tikka and steak is cooked on real coal — never on a flat electric grill. That smoke is our signature.",
  },
  {
    icon: "leaf",
    title: "Fresh, halal & local",
    body: "Meat arrives daily from Sargodha suppliers, vegetables from the morning mandi, and dairy from nearby farms.",
  },
  {
    icon: "chef",
    title: "Four specialised kitchens",
    body: "Separate desi, Chinese wok, continental grill and bakery sections so no cuisine borrows another's flavours.",
  },
  {
    icon: "bike",
    title: "Insulated home delivery",
    body: "Thermal bags and sealed packing keep karahi hot and kulfi frozen across an 18 km delivery radius.",
  },
  {
    icon: "shield",
    title: "Hygiene first, always",
    body: "Daily oil changes, sanitised prep tables, hairnets and gloves in every section. Open kitchen, nothing to hide.",
  },
  {
    icon: "clock",
    title: "Open till 2 AM",
    body: "Breakfast from 7 AM, BBQ from 5 PM and a full late-night menu for Sargodha's midnight cravings.",
  },
];

export const TIMELINE = [
  {
    year: "2014",
    title: "A single tawa on 49 Tail",
    body: "Faiz Guru started with one tawa, a chai kettle and a paratha recipe from his mother. Twenty plates a day, sold out by noon.",
  },
  {
    year: "2017",
    title: "The BBQ counter opens",
    body: "Word spread about the malai boti. A charcoal grill was added and Masstana became Sargodha's late-night kabab address.",
  },
  {
    year: "2019",
    title: "Multi-cuisine expansion",
    body: "Chinese wok and continental grill sections were built with chefs trained in Lahore and Islamabad kitchens.",
  },
  {
    year: "2021",
    title: "Home delivery fleet",
    body: "Thermal delivery bags and our own riders launched, covering an 18 km radius across Sargodha.",
  },
  {
    year: "2023",
    title: "The new dining room",
    body: "A 120-seat interior with family halls, an open kitchen view and private party rooms replaced the old shed.",
  },
  {
    year: "2026",
    title: "Online ordering goes live",
    body: "This website — full menu, live cart, promo codes and WhatsApp ordering — so guests can order without a phone call.",
  },
];

export const TEAM = [
  {
    name: "Faiz Guru",
    role: "Founder & Head Chef",
    bio: "Started Masstana with a single tawa in 2014. Still tastes every new recipe before it reaches the menu, and still greets tables on Friday nights.",
    image: LOCAL.owner,
  },
  {
    name: "Chef Imran Yousaf",
    role: "BBQ & Desi Kitchen Head",
    bio: "Twenty years behind charcoal grills across Lahore and Multan. Guardian of the nihari pot and the karahi masala.",
    image: IMG.chefPortraitFlame,
  },
  {
    name: "Chef Wei Lim",
    role: "Wok Section Head",
    bio: "Trained in Kuala Lumpur, obsessed with wok hei. Runs the Chinese counter every evening from 4 PM.",
    image: IMG.chineseKitchen,
  },
  {
    name: "Hina Shahzad",
    role: "Pastry & Desserts",
    bio: "Bakes the brownies, churns the kulfi and plates every cheesecake slice by hand each morning.",
    image: IMG.lavaCake,
  },
];

export const DELIVERY_STEPS = [
  {
    step: "01",
    title: "Build your cart",
    body: "Browse the menu by category, search for a dish or start from a deal. Tap Add to Cart and adjust quantities any time.",
  },
  {
    step: "02",
    title: "Apply a promo code",
    body: "Codes like MASS10, FAMILY20, STUDENT15 or FREESHIP are validated instantly and the discount shows in your summary.",
  },
  {
    step: "03",
    title: "Checkout in 60 seconds",
    body: "Name, phone, area and address. Add cooking notes — mild spice, no onion, extra naan — the kitchen reads every one.",
  },
  {
    step: "04",
    title: "Confirm on WhatsApp",
    body: "A formatted order message is generated with your items, totals and address. One tap sends it to the restaurant.",
  },
  {
    step: "05",
    title: "Hot food at your door",
    body: "Our rider leaves within minutes in an insulated bag. Most Sargodha zones receive their order in 25–40 minutes.",
  },
];

export const DELIVERY_PROMISES = [
  { icon: "bike", title: "25–40 min average", body: "Real-time kitchen dispatch across Sargodha." },
  { icon: "shield", title: "Sealed packing", body: "Tamper-proof boxes and thermal insulation." },
  { icon: "clock", title: "Open till 2 AM", body: "Late-night delivery every single day." },
  { icon: "tag", title: "Free over Rs 3,000", body: "Automatic waiver, no code required." },
];
