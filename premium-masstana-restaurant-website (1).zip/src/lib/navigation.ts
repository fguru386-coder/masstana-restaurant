/** Shared navigation data — safe to import from both server and client components. */

export const NAV_ITEMS = [
  { href: "/", label: "Home" },
  { href: "/menu", label: "Menu" },
  { href: "/about", label: "About Us" },
  { href: "/gallery", label: "Gallery" },
  { href: "/offers", label: "Offers" },
  { href: "/delivery", label: "Delivery" },
  { href: "/contact", label: "Contact" },
];

export const MORE_ITEMS = [
  { href: "/order", label: "Order Online" },
  { href: "/reviews", label: "Customer Reviews" },
  { href: "/faq", label: "FAQ" },
];

export const ALL_NAV_ITEMS = [...NAV_ITEMS, ...MORE_ITEMS];
