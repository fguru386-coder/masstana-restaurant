/**
 * ------------------------------------------------------------------
 *  MASSTANA RESTAURANT — global site configuration
 * ------------------------------------------------------------------
 *  ⚠️  OWNER SETUP (Faiz Guru):
 *  1. Replace the WhatsApp placeholder below with the real number in
 *     international format WITHOUT "+" or spaces, e.g. "923001234567".
 *     You can also set it as an environment variable:
 *        NEXT_PUBLIC_WHATSAPP_NUMBER=923001234567
 *  2. Replace the phone numbers with the real restaurant lines.
 *  3. Once the exact location is shared, update `mapEmbedUrl` /
 *     `mapQuery` with the precise Google Maps pin for 49 Tail, Sargodha.
 * ------------------------------------------------------------------
 */

/** Placeholder — the owner must replace this with the real WhatsApp number. */
export const WHATSAPP_NUMBER =
  (process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "").trim() || "YOUR_WHATSAPP_NUMBER";

export const IS_WHATSAPP_PLACEHOLDER = !/^\d{7,15}$/.test(WHATSAPP_NUMBER);

export const SITE = {
  name: "MASSTANA RESTAURANT",
  shortName: "Masstana",
  monogram: "MR",
  tagline: "Multi-Cuisine Kitchen & BBQ House",
  city: "Sargodha",
  owner: "Faiz Guru",
  ownerTitle: "Founder & Head Chef",
  addressLine: "49 Tail, Sargodha, Pakistan",
  addressShort: "49 Tail, Sargodha",
  country: "Pakistan",
  currency: "PKR",
  since: 2014,

  /* Phone numbers are placeholders until the owner confirms the real lines. */
  phoneDisplay: "+92 300 000 0000",
  phoneHref: "tel:+923000000000",
  phoneAltDisplay: "+92 48 000 0000",
  phoneAltHref: "tel:+92480000000",
  email: "hello@masstanarestaurant.pk",

  /** Google Maps — PLACEHOLDER pin for Sargodha until exact location is given. */
  mapIsPlaceholder: true,
  mapQuery: "49 Tail, Sargodha, Punjab, Pakistan",
  mapEmbedUrl:
    "https://www.google.com/maps?q=49%20Tail%2C%20Sargodha%2C%20Punjab%2C%20Pakistan&z=13&output=embed",
  mapLinkUrl: "https://www.google.com/maps/search/?api=1&query=49+Tail+Sargodha+Pakistan",

  hours: [
    { days: "Monday – Thursday", time: "7:00 AM – 1:00 AM" },
    { days: "Friday", time: "7:00 AM – 12:30 PM · 2:30 PM – 2:00 AM" },
    { days: "Saturday – Sunday", time: "7:00 AM – 2:30 AM" },
    { days: "Breakfast counter", time: "7:00 AM – 11:30 AM daily" },
    { days: "BBQ grill fires up", time: "5:00 PM – 1:00 AM daily" },
  ],

  socials: [
    { label: "Facebook", href: "https://facebook.com", icon: "facebook" as const },
    { label: "Instagram", href: "https://instagram.com", icon: "instagram" as const },
    { label: "TikTok", href: "https://tiktok.com", icon: "tiktok" as const },
    { label: "YouTube", href: "https://youtube.com", icon: "youtube" as const },
  ],
} as const;

/** Delivery pricing rules (PKR). */
export const DELIVERY = {
  baseFee: 150,
  freeOver: 3000,
  pickupDiscount: 0,
  minOrder: 300,
  prepTime: "25–40",
  radiusKm: 18,
} as const;

export function whatsappLink(message: string): string {
  const number = IS_WHATSAPP_PLACEHOLDER ? "" : WHATSAPP_NUMBER;
  const text = encodeURIComponent(message);
  return number ? `https://wa.me/${number}?text=${text}` : `https://wa.me/?text=${text}`;
}

export function formatPKR(amount: number): string {
  return `Rs ${Math.round(amount).toLocaleString("en-PK")}`;
}
