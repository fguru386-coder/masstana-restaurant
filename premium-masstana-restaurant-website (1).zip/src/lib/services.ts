import { desc, eq } from "drizzle-orm";

import { db } from "@/db";
import { contactMessages, menuItems, orders, reviews } from "@/db/schema";
import { DELIVERY_ZONES, SEED_REVIEWS, evaluatePromo } from "@/lib/data/content";
import { MENU, type Dish } from "@/lib/data/menu";
import { DELIVERY } from "@/lib/site";
import { toDish, type CartLine, type OrderInput, type OrderResult, type ReviewInput, type StoredReview } from "@/lib/types";

/* ------------------------------------------------------------------ */
/*  MENU                                                               */
/* ------------------------------------------------------------------ */

async function seedMenu(): Promise<void> {
  await db.insert(menuItems).values(
    MENU.map((dish, index) => ({
      id: dish.id,
      name: dish.name,
      category: dish.category,
      description: dish.description,
      price: dish.price,
      oldPrice: dish.oldPrice ?? null,
      image: dish.image,
      tags: dish.tags ?? [],
      rating: dish.rating ?? 4.5,
      serves: dish.serves ?? null,
      popular: Boolean(dish.popular),
      sortOrder: index,
    })),
  );
}

/**
 * Reads the catalogue from PostgreSQL and self-seeds on first run.
 * Falls back to the bundled dataset so the site never renders broken
 * (for example when the database is unreachable in a preview sandbox).
 */
export async function getMenuItems(): Promise<Dish[]> {
  try {
    const rows = await db.select().from(menuItems);
    if (rows.length === 0) {
      try {
        await seedMenu();
        return MENU;
      } catch {
        return MENU;
      }
    }
    return rows
      .sort((a, b) => a.sortOrder - b.sortOrder)
      .map((row) => toDish({ ...row, oldPrice: row.oldPrice, serves: row.serves }));
  } catch {
    return MENU;
  }
}

export async function getPriceMap(): Promise<Record<string, number>> {
  try {
    const rows = await db.select({ id: menuItems.id, price: menuItems.price }).from(menuItems);
    if (rows.length === 0) return MENU.reduce((acc, d) => ({ ...acc, [d.id]: d.price }), {} as Record<string, number>);
    return rows.reduce((acc, r) => ({ ...acc, [r.id]: r.price }), {} as Record<string, number>);
  } catch {
    return MENU.reduce((acc, d) => ({ ...acc, [d.id]: d.price }), {} as Record<string, number>);
  }
}

/* ------------------------------------------------------------------ */
/*  ORDERS                                                             */
/* ------------------------------------------------------------------ */

function zoneFee(area?: string): number {
  if (!area) return DELIVERY.baseFee;
  const zone = DELIVERY_ZONES.find((z) => z.area.toLowerCase() === area.toLowerCase());
  return zone ? zone.fee : DELIVERY.baseFee;
}

function orderCode(): string {
  const stamp = new Date();
  const ymd = `${stamp.getFullYear()}${String(stamp.getMonth() + 1).padStart(2, "0")}${String(
    stamp.getDate(),
  ).padStart(2, "0")}`;
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `MST-${ymd}-${rand}`;
}

export async function computeTotals(input: OrderInput, prices: Record<string, number>) {
  const lines: CartLine[] = (input.items ?? [])
    .filter((item) => item && typeof item.id === "string" && item.qty > 0)
    .slice(0, 60)
    .map((item) => {
      const price = prices[item.id] ?? Number(item.price) ?? 0;
      return {
        id: item.id,
        name: item.name ?? item.id,
        price: Math.max(0, Math.round(price)),
        qty: Math.min(99, Math.max(1, Math.round(item.qty))),
        image: item.image ?? "",
        category: item.category ?? "",
      };
    });

  const subtotal = lines.reduce((sum, line) => sum + line.price * line.qty, 0);
  const itemCount = lines.reduce((sum, line) => sum + line.qty, 0);
  const isDelivery = input.orderType === "delivery";
  let deliveryFee = isDelivery ? zoneFee(input.area) : 0;
  if (isDelivery && subtotal >= DELIVERY.freeOver) deliveryFee = 0;

  const promo = evaluatePromo(input.promoCode ?? "", subtotal, deliveryFee);
  const discount = promo.ok ? promo.discount : 0;
  const total = Math.max(0, subtotal + deliveryFee - discount);

  return { lines, subtotal, deliveryFee, discount, total, itemCount, promo };
}

export async function createOrder(input: OrderInput): Promise<OrderResult> {
  if (!input?.customerName || input.customerName.trim().length < 2) {
    return { ok: false, error: "Please provide your full name." };
  }
  const phone = String(input.phone ?? "").replace(/[^\d+]/g, "");
  if (phone.length < 10) return { ok: false, error: "Please provide a valid phone number (at least 10 digits)." };
  if (!Array.isArray(input.items) || input.items.length === 0) {
    return { ok: false, error: "Your cart is empty." };
  }

  const prices = await getPriceMap();
  const { lines, subtotal, deliveryFee, discount, total, itemCount, promo } = await computeTotals(input, prices);
  if (lines.length === 0) return { ok: false, error: "No valid items found in your cart." };
  if (subtotal < DELIVERY.minOrder) {
    return { ok: false, error: `Minimum order value is Rs ${DELIVERY.minOrder}.` };
  }

  const code = orderCode();
  const payload = {
    code,
    customerName: input.customerName.trim().slice(0, 120),
    phone,
    address: input.orderType === "delivery" ? (input.address ?? "").slice(0, 400) : null,
    area: input.area ?? null,
    orderType: input.orderType === "pickup" || input.orderType === "dine-in" ? input.orderType : "delivery",
    notes: (input.notes ?? "").slice(0, 600) || null,
    paymentMethod: input.paymentMethod || "cash",
    items: lines,
    itemCount,
    subtotal,
    deliveryFee,
    discount,
    total,
    promoCode: promo.ok ? promo.offer?.code ?? null : null,
    status: "received",
    channel: "website",
  };

  try {
    const inserted = await db.insert(orders).values(payload).returning({ id: orders.id });
    return {
      ok: true,
      code,
      id: inserted[0]?.id ?? null,
      persisted: true,
      totals: { subtotal, deliveryFee, discount, total, itemCount },
    };
  } catch {
    // Database unavailable (e.g. offline preview) — the order is still
    // returned to the customer and can be sent through WhatsApp.
    return {
      ok: true,
      code,
      id: null,
      persisted: false,
      totals: { subtotal, deliveryFee, discount, total, itemCount },
    };
  }
}

export async function getOrder(code: string) {
  const rows = await db.select().from(orders).where(eq(orders.code, code)).limit(1);
  return rows[0] ?? null;
}

export async function recentOrders(limit = 25) {
  return db.select().from(orders).orderBy(desc(orders.createdAt)).limit(limit);
}

/* ------------------------------------------------------------------ */
/*  REVIEWS                                                            */
/* ------------------------------------------------------------------ */

async function seedReviews(): Promise<void> {
  await db.insert(reviews).values(
    SEED_REVIEWS.map((review) => ({
      name: review.name,
      city: review.city,
      rating: review.rating,
      title: review.title,
      body: review.body,
      dish: review.dish ?? null,
      source: review.source ?? "Website",
    })),
  );
}

export async function getReviews(): Promise<StoredReview[]> {
  try {
    const rows = await db.select().from(reviews).orderBy(desc(reviews.createdAt));
    if (rows.length === 0) {
      try {
        await seedReviews();
      } catch {
        /* ignore — seed data below is used instead */
      }
    }
    const all = rows.length > 0 ? rows : [];
    if (all.length === 0) {
      return SEED_REVIEWS.map((review, index) => ({
        id: `seed-${index}`,
        name: review.name,
        city: review.city,
        rating: review.rating,
        title: review.title,
        body: review.body,
        dish: review.dish,
        date: review.date ?? "",
        source: review.source ?? "Website",
      }));
    }
    return all.map((row) => ({
      id: row.id,
      name: row.name,
      city: row.city ?? "Sargodha",
      rating: row.rating,
      title: row.title ?? "Great experience",
      body: row.body,
      dish: row.dish ?? undefined,
      date: row.createdAt.toISOString().slice(0, 10),
      source: row.source,
    }));
  } catch {
    return SEED_REVIEWS.map((review, index) => ({
      id: `seed-${index}`,
      name: review.name,
      city: review.city,
      rating: review.rating,
      title: review.title,
      body: review.body,
      dish: review.dish,
      date: review.date ?? "",
      source: review.source ?? "Website",
    }));
  }
}

export async function addReview(input: ReviewInput): Promise<StoredReview> {
  const clean = {
    name: input.name.trim().slice(0, 60) || "Guest",
    city: (input.city ?? "Sargodha").trim().slice(0, 60),
    rating: Math.min(5, Math.max(1, Math.round(input.rating))),
    title: (input.title ?? "").trim().slice(0, 90) || "Wonderful experience",
    body: input.body.trim().slice(0, 800),
    dish: (input.dish ?? "").trim().slice(0, 90) || null,
    source: "Website",
  };

  try {
    const inserted = await db
      .insert(reviews)
      .values(clean)
      .returning({ id: reviews.id, createdAt: reviews.createdAt });
    return {
      id: inserted[0].id,
      name: clean.name,
      city: clean.city,
      rating: clean.rating,
      title: clean.title,
      body: clean.body,
      dish: clean.dish ?? undefined,
      date: inserted[0].createdAt.toISOString().slice(0, 10),
      source: clean.source,
    };
  } catch {
    return {
      id: `local-${Date.now()}`,
      name: clean.name,
      city: clean.city,
      rating: clean.rating,
      title: clean.title,
      body: clean.body,
      dish: clean.dish ?? undefined,
      date: new Date().toISOString().slice(0, 10),
      source: clean.source,
    };
  }
}

/* ------------------------------------------------------------------ */
/*  CONTACT MESSAGES                                                   */
/* ------------------------------------------------------------------ */

export async function addContactMessage(input: {
  name: string;
  email?: string;
  phone?: string;
  subject?: string;
  message: string;
  kind?: string;
}): Promise<{ ok: boolean; persisted: boolean; id?: number }> {
  try {
    const inserted = await db
      .insert(contactMessages)
      .values({
        name: input.name.trim().slice(0, 80),
        email: (input.email ?? "").trim().slice(0, 120) || null,
        phone: (input.phone ?? "").trim().slice(0, 40) || null,
        subject: (input.subject ?? "").trim().slice(0, 120) || null,
        message: input.message.trim().slice(0, 2000),
        kind: input.kind ?? "general",
      })
      .returning({ id: contactMessages.id });
    return { ok: true, persisted: true, id: inserted[0].id };
  } catch {
    return { ok: true, persisted: false };
  }
}
