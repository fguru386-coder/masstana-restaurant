import type { CartLine } from "@/lib/types";
import { SITE, formatPKR } from "@/lib/site";

export type OrderMessageInput = {
  lines: CartLine[];
  subtotal: number;
  deliveryFee: number;
  discount: number;
  total: number;
  itemCount?: number;
  customerName?: string;
  phone?: string;
  address?: string;
  area?: string;
  orderType?: string;
  notes?: string;
  promoCode?: string;
  orderCode?: string;
  paymentMethod?: string;
};

/** Builds the formatted WhatsApp order message the owner receives. */
export function buildOrderMessage(input: OrderMessageInput): string {
  const lines: string[] = [];
  lines.push(`*${SITE.name} — NEW ORDER*`);
  if (input.orderCode) lines.push(`Order Code: *${input.orderCode}*`);
  lines.push("");
  lines.push(`*Customer:* ${input.customerName?.trim() || "Guest"}`);
  if (input.phone) lines.push(`*Phone:* ${input.phone}`);
  lines.push(`*Order Type:* ${prettyOrderType(input.orderType ?? "delivery")}`);
  if (input.orderType === "delivery" || !input.orderType) {
    if (input.area) lines.push(`*Area:* ${input.area}`);
    if (input.address) lines.push(`*Address:* ${input.address}`);
  }
  lines.push("");
  lines.push("*Items:*");
  input.lines.forEach((line, index) => {
    lines.push(
      `${index + 1}. ${line.qty} x ${line.name} — ${formatPKR(line.price * line.qty)} (${formatPKR(line.price)} each)`,
    );
  });
  lines.push("");
  lines.push(`Subtotal: ${formatPKR(input.subtotal)}`);
  lines.push(`Delivery: ${input.deliveryFee === 0 ? "FREE" : formatPKR(input.deliveryFee)}`);
  if (input.discount > 0) {
    lines.push(`Discount${input.promoCode ? ` (${input.promoCode})` : ""}: -${formatPKR(input.discount)}`);
  }
  lines.push(`*TOTAL: ${formatPKR(input.total)}*`);
  if (input.paymentMethod) lines.push(`Payment: ${prettyPayment(input.paymentMethod)}`);
  if (input.notes?.trim()) lines.push(`Notes: ${input.notes.trim()}`);
  lines.push("");
  lines.push(`${SITE.addressLine}`);
  lines.push(`Sent from the ${SITE.name} website`);
  return lines.join("\n");
}

export function prettyOrderType(type: string): string {
  switch (type) {
    case "pickup":
      return "Takeaway / Pickup";
    case "dine-in":
      return "Dine-in (table booking)";
    default:
      return "Home Delivery";
  }
}

export function prettyPayment(method: string): string {
  switch (method) {
    case "easypaisa":
      return "EasyPaisa / JazzCash";
    case "card":
      return "Card on delivery";
    default:
      return "Cash on delivery";
  }
}
