"use client";

import { useMemo, useState } from "react";

import { Icon, StarIcon, Stars } from "@/components/ui/icons";
import { Reveal } from "@/components/ui/reveal";
import { MENU } from "@/lib/data/menu";
import type { StoredReview } from "@/lib/types";

const FILTERS = [
  { value: 0, label: "All reviews" },
  { value: 5, label: "5 star" },
  { value: 4, label: "4 star" },
  { value: 3, label: "3 star & below" },
];

function initials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
}

export function ReviewWall({ initial }: { initial: StoredReview[] }) {
  const [list, setList] = useState<StoredReview[]>(initial);
  const [filter, setFilter] = useState(0);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", city: "Sargodha", dish: "", title: "", body: "", rating: 5 });
  const [status, setStatus] = useState<{ kind: "idle" | "sending" | "ok" | "error"; message: string }>({
    kind: "idle",
    message: "",
  });

  const stats = useMemo(() => {
    const total = list.length || 1;
    const sum = list.reduce((acc, r) => acc + r.rating, 0);
    const average = sum / total;
    const distribution = [5, 4, 3, 2, 1].map((star) => ({
      star,
      count: list.filter((r) => Math.round(r.rating) === star).length,
      percent: Math.round((list.filter((r) => Math.round(r.rating) === star).length / total) * 100),
    }));
    return { average, count: list.length, distribution };
  }, [list]);

  const visible = useMemo(() => {
    if (filter === 0) return list;
    if (filter === 3) return list.filter((r) => r.rating <= 3);
    return list.filter((r) => Math.round(r.rating) === filter);
  }, [list, filter]);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (form.name.trim().length < 2 || form.body.trim().length < 15) {
      setStatus({ kind: "error", message: "Please add your name and a review of at least 15 characters." });
      return;
    }
    setStatus({ kind: "sending", message: "" });
    try {
      const response = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          city: form.city,
          rating: form.rating,
          title: form.title,
          body: form.body,
          dish: form.dish,
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data?.error ?? "Could not save review");
      const review: StoredReview = data.review ?? {
        id: Date.now(),
        name: form.name,
        city: form.city || "Sargodha",
        rating: form.rating,
        title: form.title || "Great experience",
        body: form.body,
        dish: form.dish || undefined,
        date: new Date().toISOString().slice(0, 10),
        source: "Website",
      };
      setList((prev) => [review, ...prev]);
      setForm({ name: "", city: "Sargodha", dish: "", title: "", body: "", rating: 5 });
      setShowForm(false);
      setStatus({ kind: "ok", message: "Shukriya! Your review is now live on this page." });
    } catch (error) {
      setStatus({
        kind: "error",
        message: error instanceof Error ? error.message : "Something went wrong. Please try again.",
      });
    }
  };

  return (
    <div className="grid gap-8 lg:grid-cols-[0.85fr_1.15fr] lg:items-start">
      {/* Summary + form */}
      <div className="space-y-6 lg:sticky lg:top-28">
        <Reveal>
          <section className="glass rounded-[1.75rem] p-6">
            <div className="flex items-end gap-4">
              <span className="font-display text-6xl gold-text">{stats.average.toFixed(1)}</span>
              <div className="pb-1">
                <Stars value={stats.average} className="h-4 w-4" />
                <p className="mt-1 text-[0.78rem] text-sand/65">{stats.count} verified guest reviews</p>
              </div>
            </div>

            <ul className="mt-6 space-y-2">
              {stats.distribution.map((row) => (
                <li key={row.star} className="flex items-center gap-3">
                  <span className="flex w-12 items-center gap-1 text-[0.72rem] text-sand/70">
                    {row.star}
                    <StarIcon className="h-3 w-3 text-gold-400" />
                  </span>
                  <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-cream/10">
                    <span
                      className="block h-full rounded-full bg-gradient-to-r from-gold-400 to-ember-500 transition-[width] duration-700"
                      style={{ width: `${row.percent}%` }}
                    />
                  </span>
                  <span className="w-8 text-right text-[0.72rem] text-sand/55">{row.count}</span>
                </li>
              ))}
            </ul>

            <div className="mt-6 flex flex-wrap gap-2">
              {FILTERS.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => setFilter(option.value)}
                  data-active={filter === option.value}
                  className="chip !text-[0.62rem]"
                >
                  {option.label}
                </button>
              ))}
            </div>

            <button type="button" onClick={() => setShowForm((v) => !v)} className="btn btn-gold mt-6 w-full">
              <Icon name={showForm ? "close" : "quote"} className="h-4 w-4" />
              {showForm ? "Close form" : "Write a review"}
            </button>

            {status.kind === "ok" && (
              <p className="mt-3 rounded-xl border border-emerald-400/30 bg-emerald-400/10 px-4 py-3 text-[0.78rem] text-emerald-200">
                {status.message}
              </p>
            )}
          </section>
        </Reveal>

        {showForm && (
          <Reveal>
            <form onSubmit={submit} className="glass rounded-[1.75rem] p-6">
              <h3 className="text-lg text-cream">Share your experience</h3>
              <p className="mt-1 text-[0.78rem] text-sand/60">
                Reviews are published instantly on this page — honest feedback keeps our kitchen sharp.
              </p>

              <div className="mt-5 space-y-4">
                <div>
                  <span className="mb-2 block text-[0.7rem] font-bold uppercase tracking-[0.16em] text-sand/60">Your rating</span>
                  <div className="flex gap-1.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setForm((prev) => ({ ...prev, rating: star }))}
                        aria-label={`${star} star${star > 1 ? "s" : ""}`}
                        className={`transition-transform duration-200 hover:scale-115 ${
                          star <= form.rating ? "text-gold-300" : "text-cream/25"
                        }`}
                      >
                        <StarIcon className="h-7 w-7" filled={star <= form.rating} />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  <input
                    className="field"
                    placeholder="Your name *"
                    value={form.name}
                    onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
                  />
                  <input
                    className="field"
                    placeholder="City / area"
                    value={form.city}
                    onChange={(e) => setForm((p) => ({ ...p, city: e.target.value }))}
                  />
                </div>

                <select
                  className="field"
                  value={form.dish}
                  onChange={(e) => setForm((p) => ({ ...p, dish: e.target.value }))}
                  aria-label="Dish you ordered"
                >
                  <option value="">Which dish did you order? (optional)</option>
                  {MENU.map((dish) => (
                    <option key={dish.id} value={dish.name}>
                      {dish.name}
                    </option>
                  ))}
                </select>

                <input
                  className="field"
                  placeholder="Headline (optional)"
                  value={form.title}
                  onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))}
                />
                <textarea
                  className="field resize-none"
                  rows={4}
                  placeholder="Tell other guests about the food, service and delivery…"
                  value={form.body}
                  onChange={(e) => setForm((p) => ({ ...p, body: e.target.value }))}
                />
                {status.kind === "error" && (
                  <p className="rounded-xl border border-ember-400/35 bg-ember-500/10 px-4 py-3 text-[0.78rem] text-ember-200">
                    {status.message}
                  </p>
                )}
                <button type="submit" disabled={status.kind === "sending"} className="btn btn-gold w-full">
                  {status.kind === "sending" ? "Publishing…" : "Publish review"}
                  <Icon name="send" className="h-4 w-4" />
                </button>
              </div>
            </form>
          </Reveal>
        )}
      </div>

      {/* Review cards */}
      <div>
        {visible.length === 0 ? (
          <div className="glass rounded-[1.75rem] p-10 text-center">
            <h3 className="text-lg text-cream">No reviews with that rating yet</h3>
            <p className="mt-2 text-[0.85rem] text-sand/65">Be the first to review — tap “Write a review”.</p>
          </div>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2">
            {visible.map((review, index) => (
              <Reveal key={`${review.id}-${index}`} delay={(index % 2) * 90} className="h-full">
                <article className="tilt-card flex h-full flex-col gap-4 rounded-[1.5rem] border border-gold-400/12 bg-gradient-to-br from-noir-800/80 to-noir-950/90 p-6">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="grid h-11 w-11 place-items-center rounded-full bg-gradient-to-br from-gold-300 to-ember-500 font-display text-sm text-noir-950">
                        {initials(review.name)}
                      </span>
                      <div>
                        <h3 className="text-[0.95rem] text-cream">{review.name}</h3>
                        <p className="text-[0.72rem] text-sand/55">{review.city}</p>
                      </div>
                    </div>
                    <Icon name="quote" className="h-7 w-7 text-gold-400/25" />
                  </div>

                  <div className="flex items-center gap-3">
                    <Stars value={review.rating} className="h-3.5 w-3.5" />
                    <span className="text-[0.68rem] uppercase tracking-[0.14em] text-sand/45">
                      {review.date} · {review.source}
                    </span>
                  </div>

                  <div>
                    <h4 className="text-[0.95rem] font-bold text-gold-200">{review.title}</h4>
                    <p className="mt-2 text-[0.85rem] leading-relaxed text-sand/75">{review.body}</p>
                  </div>

                  {review.dish && (
                    <p className="mt-auto inline-flex items-center gap-2 self-start rounded-full border border-gold-400/25 bg-gold-400/8 px-3 py-1.5 text-[0.68rem] text-gold-200">
                      <Icon name="utensils" className="h-3.5 w-3.5" />
                      {review.dish}
                    </p>
                  )}
                </article>
              </Reveal>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
