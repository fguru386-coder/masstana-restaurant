"use client";

import Link from "next/link";
import { useMemo, useState } from "react";

import { Icon } from "@/components/ui/icons";
import { Reveal } from "@/components/ui/reveal";
import { SITE, whatsappLink } from "@/lib/site";
import type { Faq } from "@/lib/data/content";

export function FaqAccordion({ faqs }: { faqs: Faq[] }) {
  const groups = useMemo(() => ["All", ...Array.from(new Set(faqs.map((f) => f.group)))], [faqs]);
  const [group, setGroup] = useState("All");
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState<string | null>(faqs[0]?.q ?? null);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return faqs.filter((faq) => {
      if (group !== "All" && faq.group !== group) return false;
      if (!q) return true;
      return faq.q.toLowerCase().includes(q) || faq.a.toLowerCase().includes(q);
    });
  }, [faqs, group, query]);

  return (
    <div>
      <div className="mb-8 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
          {groups.map((name) => (
            <button key={name} type="button" onClick={() => setGroup(name)} data-active={group === name} className="chip">
              {name}
            </button>
          ))}
        </div>
        <div className="relative lg:w-72">
          <Icon name="search" className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-gold-400/70" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search questions…"
            aria-label="Search frequently asked questions"
            className="field !rounded-full !py-2.5 !pl-11 text-[0.82rem]"
          />
        </div>
      </div>

      {visible.length === 0 ? (
        <div className="glass rounded-3xl p-10 text-center">
          <h3 className="text-lg text-cream">We couldn't find that question</h3>
          <p className="mt-2 text-[0.85rem] text-sand/70">
            Ask us directly — we reply during opening hours, 7 AM to 2 AM.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link href="/contact" className="btn btn-gold !text-[0.7rem]">
              <Icon name="mail" className="h-4 w-4" />
              Contact us
            </Link>
            <a
              href={whatsappLink(`Assalam-o-Alaikum ${SITE.name}, I have a question:`)}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-outline !text-[0.7rem]"
            >
              <Icon name="phone" className="h-4 w-4" />
              WhatsApp
            </a>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          {visible.map((faq, index) => {
            const isOpen = open === faq.q;
            return (
              <Reveal key={faq.q} delay={Math.min(index, 6) * 55}>
                <div
                  className={`overflow-hidden rounded-2xl border transition-colors duration-400 ${
                    isOpen ? "border-gold-400/45 bg-gold-400/[0.06]" : "border-cream/10 bg-cream/[0.02] hover:border-gold-400/25"
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => setOpen(isOpen ? null : faq.q)}
                    aria-expanded={isOpen}
                    className="flex w-full items-center justify-between gap-4 px-5 py-5 text-left sm:px-6"
                  >
                    <span className="flex items-start gap-4">
                      <span
                        className={`mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full border text-[0.68rem] font-bold transition-colors ${
                          isOpen ? "border-gold-400 bg-gold-400 text-noir-950" : "border-gold-400/35 text-gold-300"
                        }`}
                      >
                        {String(index + 1).padStart(2, "0")}
                      </span>
                      <span>
                        <span className={`block text-[0.98rem] font-semibold transition-colors ${isOpen ? "text-gold-200" : "text-cream"}`}>
                          {faq.q}
                        </span>
                        <span className="mt-1 block text-[0.62rem] uppercase tracking-[0.18em] text-sand/45">{faq.group}</span>
                      </span>
                    </span>
                    <Icon
                      name="chevronDown"
                      className={`h-5 w-5 shrink-0 text-gold-300 transition-transform duration-400 ${isOpen ? "rotate-180" : ""}`}
                    />
                  </button>
                  <div
                    className="grid transition-[grid-template-rows] duration-500 [transition-timing-function:cubic-bezier(0.22,1,0.36,1)]"
                    style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
                  >
                    <div className="overflow-hidden">
                      <p className="px-5 pb-6 pl-[4.6rem] text-[0.88rem] leading-relaxed text-sand/75 sm:px-6 sm:pl-[5rem]">
                        {faq.a}
                      </p>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      )}
    </div>
  );
}
