"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useMemo, useState } from "react";

import { FoodCard } from "@/components/ui/food-card";
import { Icon } from "@/components/ui/icons";
import { Reveal } from "@/components/ui/reveal";
import { CATEGORIES, type CategoryId, type Dish } from "@/lib/data/menu";

type SortKey = "recommended" | "price-asc" | "price-desc" | "rating" | "name";

const SORTS: { value: SortKey; label: string }[] = [
  { value: "recommended", label: "Recommended" },
  { value: "price-asc", label: "Price: low to high" },
  { value: "price-desc", label: "Price: high to low" },
  { value: "rating", label: "Top rated" },
  { value: "name", label: "Name A–Z" },
];

const PRICE_FILTERS = [
  { value: 0, label: "Any price" },
  { value: 500, label: "Under Rs 500" },
  { value: 1000, label: "Under Rs 1,000" },
  { value: 2000, label: "Under Rs 2,000" },
];

export function MenuBrowser({ dishes }: { dishes: Dish[] }) {
  const params = useSearchParams();
  const initial = params.get("c") as CategoryId | null;
  const validInitial = initial && CATEGORIES.some((c) => c.id === initial) ? initial : "all";

  const [category, setCategory] = useState<CategoryId | "all">(validInitial);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<SortKey>("recommended");
  const [vegOnly, setVegOnly] = useState(false);
  const [spicyOnly, setSpicyOnly] = useState(false);
  const [topOnly, setTopOnly] = useState(false);
  const [maxPrice, setMaxPrice] = useState(0);

  const filtersOn = Boolean(query.trim()) || vegOnly || spicyOnly || topOnly || maxPrice > 0 || sort !== "recommended";
  const grouped = category === "all" && !filtersOn;

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = dishes.filter((dish) => {
      if (category !== "all" && dish.category !== category) return false;
      if (vegOnly && !(dish.tags ?? []).includes("veg")) return false;
      if (spicyOnly && !(dish.tags ?? []).includes("spicy")) return false;
      if (topOnly && !(dish.tags ?? []).includes("bestseller")) return false;
      if (maxPrice > 0 && dish.price > maxPrice) return false;
      if (!q) return true;
      return (
        dish.name.toLowerCase().includes(q) ||
        dish.description.toLowerCase().includes(q) ||
        dish.category.toLowerCase().includes(q) ||
        (dish.tags ?? []).some((tag) => tag.includes(q))
      );
    });

    switch (sort) {
      case "price-asc":
        list = [...list].sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        list = [...list].sort((a, b) => b.price - a.price);
        break;
      case "rating":
        list = [...list].sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0));
        break;
      case "name":
        list = [...list].sort((a, b) => a.name.localeCompare(b.name));
        break;
      default:
        list = [...list].sort((a, b) => Number(Boolean(b.popular)) - Number(Boolean(a.popular)));
    }
    return list;
  }, [dishes, category, query, vegOnly, spicyOnly, topOnly, maxPrice, sort]);

  const reset = () => {
    setCategory("all");
    setQuery("");
    setSort("recommended");
    setVegOnly(false);
    setSpicyOnly(false);
    setTopOnly(false);
    setMaxPrice(0);
  };

  return (
    <div>
      {/* Sticky control bar */}
      <div className="sticky top-[76px] z-40 -mx-5 mb-10 border-y border-gold-400/12 bg-noir-950/85 px-5 py-4 backdrop-blur-xl sm:-mx-8 sm:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center">
            <div className="relative flex-1">
              <Icon name="search" className="pointer-events-none absolute left-4 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-gold-400/70" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search biryani, zinger, shashlik, kheer…"
                aria-label="Search the menu"
                className="field !rounded-full !py-3 !pl-12 text-[0.86rem]"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery("")}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-sand/60 transition hover:text-gold-200"
                  aria-label="Clear search"
                >
                  <Icon name="close" className="h-4 w-4" strokeWidth={2} />
                </button>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value as SortKey)}
                aria-label="Sort menu"
                className="field !w-auto !rounded-full !py-2.5 text-[0.78rem]"
              >
                {SORTS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <select
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                aria-label="Maximum price"
                className="field !w-auto !rounded-full !py-2.5 text-[0.78rem]"
              >
                {PRICE_FILTERS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <button type="button" onClick={() => setVegOnly((v) => !v)} data-active={vegOnly} className="chip">
                <Icon name="leaf" className="h-3.5 w-3.5" />
                Veg
              </button>
              <button type="button" onClick={() => setSpicyOnly((v) => !v)} data-active={spicyOnly} className="chip">
                <Icon name="flame" className="h-3.5 w-3.5" />
                Spicy
              </button>
              <button type="button" onClick={() => setTopOnly((v) => !v)} data-active={topOnly} className="chip">
                <Icon name="sparkle" className="h-3.5 w-3.5" />
                Bestsellers
              </button>
            </div>
          </div>

          <div className="no-scrollbar mt-4 flex gap-2 overflow-x-auto pb-1">
            <button
              type="button"
              onClick={() => setCategory("all")}
              data-active={category === "all"}
              className="chip"
            >
              All dishes · {dishes.length}
            </button>
            {CATEGORIES.map((item) => {
              const count = dishes.filter((d) => d.category === item.id).length;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setCategory(item.id)}
                  data-active={category === item.id}
                  className="chip"
                >
                  <Icon name={item.icon} className="h-3.5 w-3.5" />
                  {item.label} · {count}
                </button>
              );
            })}
          </div>

          <div className="mt-3 flex flex-wrap items-center justify-between gap-3 text-[0.75rem] text-sand/60">
            <span>
              Showing <span className="font-bold text-gold-200">{filtered.length}</span>{" "}
              {grouped ? "dishes across all kitchens" : "matching dishes"}
            </span>
            {(filtersOn || category !== "all") && (
              <button type="button" onClick={reset} className="inline-flex items-center gap-1.5 text-gold-300 underline-offset-4 hover:underline">
                <Icon name="close" className="h-3.5 w-3.5" strokeWidth={2.2} />
                Reset filters
              </button>
            )}
          </div>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="glass mx-auto max-w-lg rounded-3xl p-10 text-center">
          <span className="mx-auto grid h-16 w-16 place-items-center rounded-full border border-gold-400/25 bg-gold-400/5">
            <Icon name="search" className="h-7 w-7 text-gold-300" />
          </span>
          <h3 className="mt-5 text-xl text-cream">No dishes match that search</h3>
          <p className="mt-2 text-[0.86rem] text-sand/70">
            Try “biryani”, “zinger”, “shashlik”, “kheer” or clear the filters to see the full menu.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-2">
            <button type="button" onClick={reset} className="btn btn-gold !text-[0.7rem]">
              Show everything
            </button>
            <Link href="/contact" className="btn btn-outline !text-[0.7rem]">
              Request a dish
            </Link>
          </div>
        </div>
      ) : grouped ? (
        <div className="space-y-16">
          {CATEGORIES.map((item) => {
            const list = dishes.filter((d) => d.category === item.id);
            if (list.length === 0) return null;
            return (
              <section key={item.id} id={item.id} className="scroll-mt-44">
                <Reveal>
                  <div className="mb-6 flex flex-wrap items-end justify-between gap-4 border-b border-gold-400/12 pb-4">
                    <div className="flex items-center gap-4">
                      <span className="grid h-12 w-12 place-items-center rounded-2xl border border-gold-400/25 bg-gold-400/8 text-gold-300">
                        <Icon name={item.icon} className="h-6 w-6" />
                      </span>
                      <div>
                        <h2 className="text-2xl text-cream sm:text-3xl">
                          {item.label} <span className="script text-lg text-gold-300/80">{item.urdu}</span>
                        </h2>
                        <p className="text-[0.82rem] text-sand/65">{item.blurb}</p>
                      </div>
                    </div>
                    <span className="text-[0.7rem] uppercase tracking-[0.2em] text-sand/50">{list.length} dishes</span>
                  </div>
                </Reveal>
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {list.map((dish, index) => (
                    <FoodCard key={dish.id} dish={dish} index={index} />
                  ))}
                </div>
              </section>
            );
          })}
        </div>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((dish, index) => (
            <FoodCard key={dish.id} dish={dish} index={index} />
          ))}
        </div>
      )}
    </div>
  );
}
