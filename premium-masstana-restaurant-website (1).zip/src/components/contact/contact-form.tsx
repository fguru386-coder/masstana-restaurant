"use client";

import { useState } from "react";

import { Icon } from "@/components/ui/icons";
import { Reveal } from "@/components/ui/reveal";
import { SITE } from "@/lib/site";

const KINDS = [
  { id: "general", label: "General enquiry", icon: "mail" },
  { id: "reservation", label: "Table reservation", icon: "utensils" },
  { id: "catering", label: "Catering / event", icon: "chef" },
  { id: "feedback", label: "Feedback", icon: "heart" },
  { id: "complaint", label: "Order complaint", icon: "shield" },
];

export function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", kind: "general", subject: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [state, setState] = useState<{ kind: "idle" | "sending" | "ok" | "error"; message: string }>({
    kind: "idle",
    message: "",
  });

  const update = (key: keyof typeof form, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: "" }));
    setState({ kind: "idle", message: "" });
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    const next: Record<string, string> = {};
    if (form.name.trim().length < 2) next.name = "Please enter your name.";
    if (form.message.trim().length < 12) next.message = "Tell us a little more (at least 12 characters).";
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email)) next.email = "That email looks incomplete.";
    if (form.phone && form.phone.replace(/\D/g, "").length < 10) next.phone = "That phone number looks incomplete.";
    setErrors(next);
    if (Object.keys(next).length > 0) return;

    setState({ kind: "sending", message: "" });
    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data?.error ?? "Could not send message");
      setState({
        kind: "ok",
        message: data.persisted
          ? "Message received. Our team replies within a few hours during opening times."
          : "Message captured in demo mode — the database was unreachable, but the form works. Please call us for urgent orders.",
      });
      setForm({ name: "", email: "", phone: "", kind: "general", subject: "", message: "" });
    } catch (error) {
      setState({
        kind: "error",
        message: error instanceof Error ? error.message : "Something went wrong. Please try again.",
      });
    }
  };

  return (
    <Reveal>
      <form onSubmit={submit} className="glass rounded-[1.75rem] p-6 sm:p-8">
        <h2 className="text-2xl text-cream">Send us a message</h2>
        <p className="mt-2 text-[0.86rem] text-sand/70">
          Reservations, catering quotations, complaints or a simple “biryani kab ready hogi?” — write to us here.
        </p>

        <div className="mt-6 space-y-4">
          <fieldset>
            <legend className="mb-2 block text-[0.7rem] font-bold uppercase tracking-[0.16em] text-sand/60">
              What is it about?
            </legend>
            <div className="flex flex-wrap gap-2">
              {KINDS.map((kind) => (
                <button
                  key={kind.id}
                  type="button"
                  onClick={() => update("kind", kind.id)}
                  data-active={form.kind === kind.id}
                  className="chip !text-[0.64rem]"
                >
                  <Icon name={kind.icon} className="h-3.5 w-3.5" />
                  {kind.label}
                </button>
              ))}
            </div>
          </fieldset>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="c-name" className="mb-2 block text-[0.7rem] font-bold uppercase tracking-[0.16em] text-sand/60">
                Your name *
              </label>
              <input id="c-name" className="field" value={form.name} onChange={(e) => update("name", e.target.value)} placeholder="Full name" />
              {errors.name && <p className="mt-1.5 text-[0.72rem] text-ember-300">{errors.name}</p>}
            </div>
            <div>
              <label htmlFor="c-phone" className="mb-2 block text-[0.7rem] font-bold uppercase tracking-[0.16em] text-sand/60">
                Phone
              </label>
              <input
                id="c-phone"
                className="field"
                value={form.phone}
                onChange={(e) => update("phone", e.target.value)}
                placeholder="0300 0000000"
                inputMode="tel"
              />
              {errors.phone && <p className="mt-1.5 text-[0.72rem] text-ember-300">{errors.phone}</p>}
            </div>
            <div className="sm:col-span-2">
              <label htmlFor="c-email" className="mb-2 block text-[0.7rem] font-bold uppercase tracking-[0.16em] text-sand/60">
                Email
              </label>
              <input
                id="c-email"
                className="field"
                value={form.email}
                onChange={(e) => update("email", e.target.value)}
                placeholder="you@example.com"
                inputMode="email"
              />
              {errors.email && <p className="mt-1.5 text-[0.72rem] text-ember-300">{errors.email}</p>}
            </div>
            <div className="sm:col-span-2">
              <label htmlFor="c-subject" className="mb-2 block text-[0.7rem] font-bold uppercase tracking-[0.16em] text-sand/60">
                Subject
              </label>
              <input
                id="c-subject"
                className="field"
                value={form.subject}
                onChange={(e) => update("subject", e.target.value)}
                placeholder="Birthday dinner for 12 on Saturday"
              />
            </div>
            <div className="sm:col-span-2">
              <label htmlFor="c-message" className="mb-2 block text-[0.7rem] font-bold uppercase tracking-[0.16em] text-sand/60">
                Message *
              </label>
              <textarea
                id="c-message"
                rows={5}
                className="field resize-none"
                value={form.message}
                onChange={(e) => update("message", e.target.value)}
                placeholder="Share the details — date, time, headcount, dishes, budget…"
              />
              {errors.message && <p className="mt-1.5 text-[0.72rem] text-ember-300">{errors.message}</p>}
            </div>
          </div>

          {state.kind !== "idle" && state.message && (
            <p
              className={`rounded-xl border px-4 py-3 text-[0.8rem] ${
                state.kind === "ok"
                  ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-200"
                  : "border-ember-400/35 bg-ember-500/10 text-ember-200"
              }`}
            >
              {state.message}
            </p>
          )}

          <div className="flex flex-wrap items-center gap-3">
            <button type="submit" disabled={state.kind === "sending"} className="btn btn-gold">
              {state.kind === "sending" ? (
                <>
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-noir-950/40 border-t-noir-950" />
                  Sending…
                </>
              ) : (
                <>
                  <Icon name="send" className="h-4 w-4" />
                  Send message
                </>
              )}
            </button>
            <a href={SITE.phoneHref} className="btn btn-outline">
              <Icon name="phone" className="h-4 w-4" />
              {SITE.phoneDisplay}
            </a>
          </div>
          <p className="text-[0.7rem] text-sand/45">
            Phone numbers shown are placeholders until the restaurant confirms its live lines.
          </p>
        </div>
      </form>
    </Reveal>
  );
}
