"use client";

import { useState } from "react";

import { Icon } from "./icons";

/**
 * Network-resilient image: plain <img> (so the browser fetches directly from the
 * CDN) with a shimmer placeholder while loading and an elegant monogram fallback
 * if a photo ever fails — no broken image icons anywhere on the site.
 */
export function SmartImage({
  src,
  alt,
  className = "",
  imgClassName = "",
  sizes,
  priority = false,
}: {
  src: string;
  alt: string;
  className?: string;
  imgClassName?: string;
  sizes?: string;
  priority?: boolean;
}) {
  const [state, setState] = useState<"loading" | "ready" | "failed">("loading");

  return (
    <div className={`relative overflow-hidden bg-noir-850 ${className}`}>
      <div
        className={`absolute inset-0 transition-opacity duration-700 ${
          state === "ready" ? "opacity-0" : "opacity-100"
        }`}
        style={{
          background:
            "linear-gradient(130deg, #15111d 0%, #241c2c 38%, #2e2218 62%, #15111d 100%)",
        }}
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <Icon name="utensils" className="h-8 w-8 text-gold-400/35" />
        </div>
        {state === "loading" && <div className="loader-bar absolute inset-x-0 bottom-0" />}
      </div>

      {state !== "failed" ? (
        <img
          src={src}
          alt={alt}
          sizes={sizes}
          loading={priority ? "eager" : "lazy"}
          decoding="async"
          draggable={false}
          onLoad={() => setState("ready")}
          onError={() => setState("failed")}
          className={`h-full w-full object-cover transition-opacity duration-700 ${
            state === "ready" ? "opacity-100" : "opacity-0"
          } ${imgClassName}`}
        />
      ) : (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-gradient-to-br from-noir-800 via-noir-850 to-[#2b1d12] text-center">
          <Icon name="utensils" className="h-9 w-9 text-gold-400/60" />
          <span className="px-3 text-[0.62rem] font-semibold uppercase tracking-[0.22em] text-gold-300/70">
            Masstana
          </span>
        </div>
      )}
    </div>
  );
}
