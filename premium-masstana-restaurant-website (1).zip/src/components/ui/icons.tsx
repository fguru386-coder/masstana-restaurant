import type { ReactNode } from "react";

const PATHS: Record<string, ReactNode> = {
  bowl: (
    <>
      <path d="M3 11h18a9 9 0 0 1-18 0Z" />
      <path d="M8 21h8" />
      <path d="M9 4.5c0 1.2-1 1.6-1 2.8M13 3.5c0 1.4-1 1.8-1 3.2M17 4.5c0 1.2-1 1.6-1 2.8" />
    </>
  ),
  burger: (
    <>
      <path d="M4 8.5C4 6 7.6 4 12 4s8 2 8 4.5" />
      <path d="M3.5 11.5h17" />
      <path d="M4 15c0 2.2 3.6 3.8 8 3.8s8-1.6 8-3.8" />
    </>
  ),
  wok: (
    <>
      <path d="M2.5 10.5h19l-1.7 6.2A4 4 0 0 1 16 19.5H8a4 4 0 0 1-3.8-2.8L2.5 10.5Z" />
      <path d="M7 7.5c1-1.5 2.5-2 4-2M13 4c.8 1.4.6 2.7-.2 3.8" />
    </>
  ),
  steak: <path d="M6.4 14.4C4.4 11.4 6.2 7.2 10.4 6.2c5-1.3 9.1 1.6 9.1 5.6 0 4.1-3.7 6.6-7.2 6.6-2.5 0-4.5-1.5-5.9-4Z" />,
  sun: (
    <>
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5 19 19M19 5l-1.5 1.5M6.5 17.5 5 19" />
    </>
  ),
  dessert: (
    <>
      <path d="M6 11h12l-1.1 8.2a2 2 0 0 1-2 1.8H9.1a2 2 0 0 1-2-1.8L6 11Z" />
      <path d="M8.4 11a3.6 3.6 0 1 1 7.2 0" />
      <path d="M12 3.5v1.6" />
    </>
  ),
  cup: (
    <>
      <path d="M5 8h11v6.5a4.5 4.5 0 0 1-4.5 4.5h-2A4.5 4.5 0 0 1 5 14.5V8Z" />
      <path d="M16 10.5h1.8a2.2 2.2 0 0 1 0 4.4H16" />
      <path d="M4 21.5h13" />
    </>
  ),
  tag: (
    <>
      <path d="M3 12.4 11.6 3.8a2 2 0 0 1 1.2-.6l5.6-.7.7 5.6a2 2 0 0 1-.6 1.2L10.9 18a2 2 0 0 1-2.8 0l-5.1-5.1a2 2 0 0 1 0-.5Z" />
      <circle cx="16" cy="7" r="1.4" />
    </>
  ),
  flame: <path d="M12 22c3.9 0 6.8-2.6 6.8-6.3 0-4.6-4.5-6.5-5.1-13.7-2.4 1.9-3.4 4.3-3.3 6.6-.7-1.3-1.7-2.3-3-3-.7 1.7-1.6 3.4-2 5.3-.4 1.7-.6 3-.6 4.3C4.8 19 8 22 12 22Z" />,
  leaf: (
    <>
      <path d="M4 20c0-9.4 6-15.4 16-15.4C20 14.4 14 20 4 20Z" />
      <path d="M9.5 15c1.8-2.9 4.6-5.2 8-6.4" />
    </>
  ),
  chef: (
    <>
      <path d="M7 20.5h10v-3H7v3Z" />
      <path d="M6.2 13a3 3 0 1 1 1.4-5.7A3.6 3.6 0 0 1 12 4.4a3.6 3.6 0 0 1 4.4 2.9A3 3 0 1 1 17.8 13v4.5H6.2V13Z" />
    </>
  ),
  bike: (
    <>
      <circle cx="5.5" cy="17.5" r="2.8" />
      <circle cx="18.5" cy="17.5" r="2.8" />
      <path d="M5.5 17.5 9 8.5h4l1.6 3.6M13 8.5h4.2l1.3 9" />
    </>
  ),
  shield: (
    <>
      <path d="M12 3 5 6v5.4c0 4.4 2.9 8.2 7 9.6 4.1-1.4 7-5.2 7-9.6V6l-7-3Z" />
      <path d="m9 12 2 2 4-4" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7.5V12l3.2 2" />
    </>
  ),
  cart: (
    <>
      <path d="M2.5 4h2.2l2.5 10.6a2 2 0 0 0 2 1.6h7.6a2 2 0 0 0 2-1.6L20.5 7H6" />
      <circle cx="10" cy="20" r="1.3" />
      <circle cx="17.5" cy="20" r="1.3" />
    </>
  ),
  plus: <path d="M12 5v14M5 12h14" />,
  minus: <path d="M5 12h14" />,
  trash: (
    <>
      <path d="M4 7h16M9.5 7V5.2A1.2 1.2 0 0 1 10.7 4h2.6a1.2 1.2 0 0 1 1.2 1.2V7" />
      <path d="M6.5 7 7.6 19.2a1.8 1.8 0 0 0 1.8 1.6h5.2a1.8 1.8 0 0 0 1.8-1.6L17.5 7" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="6.5" />
      <path d="m16 16 4.5 4.5" />
    </>
  ),
  close: <path d="M6 6l12 12M18 6 6 18" />,
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  arrowRight: <path d="M4 12h15m-5.5-5.5L19.5 12l-6 5.5" />,
  arrowLeft: <path d="M20 12H5m5.5-5.5L4.5 12l6 5.5" />,
  arrowUp: <path d="M12 20V5m-5.5 5.5L12 4.5l5.5 6" />,
  chevronDown: <path d="m6 9.5 6 6 6-6" />,
  quote: (
    <>
      <path d="M9.5 6C6.5 7.5 5 10 5 13.2V18h5.5v-5.5H8c0-2 .7-3.4 2.4-4.4L9.5 6Z" />
      <path d="M19 6c-3 1.5-4.5 4-4.5 7.2V18H20v-5.5h-2.5c0-2 .7-3.4 2.4-4.4L19 6Z" />
    </>
  ),
  phone: (
    <path d="M6.2 3.5h3l1.4 3.6-2 1.4a12 12 0 0 0 5.9 5.9l1.4-2 3.6 1.4v3a2 2 0 0 1-2.2 2C11.3 18.2 5.8 12.7 4.2 5.7a2 2 0 0 1 2-2.2Z" />
  ),
  pin: (
    <>
      <path d="M12 21.5s7-6 7-11.2A7 7 0 0 0 5 10.3C5 15.5 12 21.5 12 21.5Z" />
      <circle cx="12" cy="10" r="2.6" />
    </>
  ),
  mail: (
    <>
      <rect x="3" y="5.5" width="18" height="13" rx="2" />
      <path d="m3.8 7 8.2 6 8.2-6" />
    </>
  ),
  check: <path d="m4.5 12.5 5 5L20 6.5" />,
  sparkle: <path d="M12 3.2 13.8 9 19.6 10.8 13.8 12.6 12 18.4 10.2 12.6 4.4 10.8 10.2 9 12 3.2Z" />,
  utensils: (
    <>
      <path d="M6.5 3v7a2.5 2.5 0 0 0 5 0V3M9 12.5V21" />
      <path d="M16.5 3c1.8 1.4 2.6 3.6 2.6 6.2 0 2-1 3.4-2.6 3.9V21" />
    </>
  ),
  map: (
    <>
      <path d="M9 4 3 6.2v14L9 18l6 2.2 6-2.2v-14L15 6.2 9 4Z" />
      <path d="M9 4v14M15 6.2v14" />
    </>
  ),
  truck: (
    <>
      <path d="M2.5 7.5h10v9h-10v-9Z" />
      <path d="M12.5 10.5H17l3.5 3v3h-8v-6Z" />
      <circle cx="6.5" cy="18.5" r="1.8" />
      <circle cx="17" cy="18.5" r="1.8" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8" r="3.6" />
      <path d="M4.8 20a7.2 7.2 0 0 1 14.4 0" />
    </>
  ),
  send: <path d="M21 3 10.5 13.8M21 3l-6.6 18-3.9-7.2L3 9.9 21 3Z" />,
  bag: (
    <>
      <path d="M5.5 8h13l1 12.2a1.6 1.6 0 0 1-1.6 1.8H6.1a1.6 1.6 0 0 1-1.6-1.8L5.5 8Z" />
      <path d="M9 8V6.4a3 3 0 0 1 6 0V8" />
    </>
  ),
  heart: <path d="M12 20s-7.4-4.4-7.4-9.4A4.1 4.1 0 0 1 12 8a4.1 4.1 0 0 1 7.4 2.6c0 5-7.4 9.4-7.4 9.4Z" />,
  receipt: (
    <>
      <path d="M6 3h12v18l-2.2-1.6L13.6 21l-1.6-1.6L10.4 21l-2.2-1.6L6 21V3Z" />
      <path d="M9 8h6M9 12h6M9 16h3" />
    </>
  ),
  fire: <path d="M12 22c3.6 0 6.4-2.4 6.4-5.8 0-4.3-4.3-6.1-4.9-12.2-2.3 1.8-3.3 4.1-3.1 6.4-.6-1.2-1.6-2.2-2.9-2.9-.7 1.6-1.5 3.2-1.9 5-.4 1.6-.6 2.8-.6 4C5 19.6 8.4 22 12 22Z" />,
};

export type IconName = keyof typeof PATHS;

export function Icon({
  name,
  className = "h-5 w-5",
  strokeWidth = 1.6,
}: {
  name: IconName | string;
  className?: string;
  strokeWidth?: number;
}) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
      focusable="false"
    >
      {PATHS[name] ?? PATHS.sparkle}
    </svg>
  );
}

export function StarIcon({ className = "h-4 w-4", filled = true }: { className?: string; filled?: boolean }) {
  return (
    <svg
      viewBox="0 0 24 24"
      className={className}
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth={filled ? 0 : 1.6}
      aria-hidden="true"
    >
      <path d="m12 3.6 2.5 5.4 5.9.7-4.4 4 1.2 5.8L12 16.6 6.8 19.5 8 13.7l-4.4-4 5.9-.7L12 3.6Z" />
    </svg>
  );
}

export function Stars({ value, className = "h-3.5 w-3.5" }: { value: number; className?: string }) {
  const rounded = Math.round(value);
  return (
    <span className="inline-flex items-center gap-0.5 text-gold-300" aria-label={`${value} out of 5`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <StarIcon key={i} className={className} filled={i <= rounded} />
      ))}
    </span>
  );
}

const BRANDS: Record<string, ReactNode> = {
  whatsapp: (
    <path d="M12.04 2C6.6 2 2.2 6.4 2.2 11.84c0 1.9.53 3.68 1.46 5.2L2 22l5.1-1.63a9.8 9.8 0 0 0 4.94 1.33h.01c5.43 0 9.84-4.4 9.84-9.84C21.89 6.4 17.48 2 12.04 2Zm5.75 13.83c-.24.68-1.4 1.3-1.94 1.35-.5.05-.98.23-3.3-.7-2.77-1.1-4.53-3.95-4.67-4.14-.13-.19-1.1-1.47-1.1-2.8 0-1.34.7-1.99.95-2.26.24-.27.53-.34.7-.34l.5.01c.16 0 .38-.06.59.45.24.58.8 2 .87 2.14.07.14.12.31.02.5-.1.19-.15.31-.29.48-.15.16-.31.37-.44.5-.15.14-.3.29-.13.58.17.29.76 1.25 1.63 2.02 1.12 1 2.06 1.31 2.35 1.46.29.14.46.12.63-.07.17-.2.73-.85.92-1.14.2-.29.39-.24.65-.14.27.1 1.68.79 1.97.94.29.14.48.22.55.34.07.12.07.7-.17 1.38Z" />
  ),
  facebook: (
    <path d="M13.5 21v-7.3h2.5l.4-2.9h-2.9V8.9c0-.84.23-1.4 1.44-1.4h1.55V4.9c-.27-.04-1.2-.12-2.28-.12-2.26 0-3.8 1.38-3.8 3.9v2.14H8v2.9h2.4V21h3.1Z" />
  ),
  instagram: (
    <>
      <path d="M12 2.2c3.2 0 3.58.01 4.85.07 1.17.05 1.8.25 2.23.41.56.22.96.48 1.38.9.42.42.68.82.9 1.38.16.42.36 1.06.41 2.23.06 1.27.07 1.65.07 4.85s-.01 3.58-.07 4.85c-.05 1.17-.25 1.8-.41 2.23a3.7 3.7 0 0 1-.9 1.38c-.42.42-.82.68-1.38.9-.42.16-1.06.36-2.23.41-1.27.06-1.65.07-4.85.07s-3.58-.01-4.85-.07c-1.17-.05-1.8-.25-2.23-.41a3.7 3.7 0 0 1-1.38-.9 3.7 3.7 0 0 1-.9-1.38c-.16-.42-.36-1.06-.41-2.23C2.21 15.58 2.2 15.2 2.2 12s.01-3.58.07-4.85c.05-1.17.25-1.8.41-2.23.22-.56.48-.96.9-1.38.42-.42.82-.68 1.38-.9.42-.16 1.06-.36 2.23-.41C8.42 2.21 8.8 2.2 12 2.2Zm0 3.05a6.75 6.75 0 1 0 0 13.5 6.75 6.75 0 0 0 0-13.5Zm0 11.13a4.38 4.38 0 1 1 0-8.76 4.38 4.38 0 0 1 0 8.76Zm6.99-11.4a1.58 1.58 0 1 1-3.15 0 1.58 1.58 0 0 1 3.15 0Z" />
    </>
  ),
  tiktok: (
    <path d="M16.6 5.82A4.28 4.28 0 0 1 15.54 3h-3.09v12.4a2.59 2.59 0 1 1-1.83-2.48V9.77a5.76 5.76 0 1 0 4.92 5.7V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3a4.28 4.28 0 0 1-3.24-1.48Z" />
  ),
  youtube: (
    <path d="M21.58 7.19a2.5 2.5 0 0 0-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42A2.5 2.5 0 0 0 2.42 7.2 26 26 0 0 0 2 12a26 26 0 0 0 .42 4.81 2.5 2.5 0 0 0 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42a2.5 2.5 0 0 0 1.77-1.77A26 26 0 0 0 22 12a26 26 0 0 0-.42-4.81ZM10 15.5v-7l6 3.5-6 3.5Z" />
  ),
};

export function BrandIcon({ name, className = "h-5 w-5" }: { name: string; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      {BRANDS[name] ?? BRANDS.facebook}
    </svg>
  );
}

export function Logo({ className = "h-11 w-11" }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="mrGold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#fbf1d9" />
          <stop offset="45%" stopColor="#d9a94f" />
          <stop offset="100%" stopColor="#f2701c" />
        </linearGradient>
      </defs>
      <circle cx="32" cy="32" r="29" fill="none" stroke="url(#mrGold)" strokeWidth="1.6" opacity="0.85" />
      <circle cx="32" cy="32" r="24" fill="none" stroke="url(#mrGold)" strokeWidth="0.7" opacity="0.45" />
      <path
        d="M20 41V23l6.6 9.2L33.2 23v18"
        fill="none"
        stroke="url(#mrGold)"
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M38 41V23h5.4c3.4 0 5.6 2 5.6 5.1 0 2.3-1.2 4-3.2 4.7l3.8 8.2h-3.4l-3.4-7.6H41v7.6h-3Zm3-10.6h2.2c1.6 0 2.7-.9 2.7-2.4s-1.1-2.3-2.7-2.3H41v4.7Z"
        fill="url(#mrGold)"
      />
    </svg>
  );
}
