"use client";

import Link from "next/link";

import { useCart } from "@/components/cart/cart-provider";
import { CATEGORY_MAP, type CategoryId, type Dish } from "@/lib/data/menu";
import { formatPKR } from "@/lib/site";

import { Icon, Stars } from "./icons";
import { Reveal } from "./reveal";
import { SmartImage } from "./smart-image";

const TAG_META: Record<string, { label: string; icon: string; className: string }> = {
  bestseller: { label: "Bestseller", icon: "star", className: "border-gold-400/50 bg-gold-400/15 text-gold-200" },
  chef: { label: "Chef's pick", icon: "chef", className: "border-ember-400/50 bg-ember-400/15 text-ember-200" },
  new: { label: "New", icon: "sparkle", className: "border-cream/25 bg-cream/10 text-cream" },
  spicy: { label: "Spicy", icon: "flame", className: "border-ember-500/50 bg-ember-500/15 text-ember-300" },
  veg: { label: "Vegetarian", icon: "leaf", className: "border-emerald-400/40 bg-emerald-400/12 text-emerald-200" },
};

export function FoodCard({ dish, index = 0 }: { dish: Dish; index?: number }) {
  const { add, increment, decrement, qtyOf } = useCart();
  const qty = qtyOf(dish.id);
  const category = CATEGORY_MAP[dish.category as CategoryId];
  const offPercent = dish.oldPrice ? Math.round(((dish.oldPrice - dish.price) / dish.oldPrice) * 100) : 0;
  const tags = (dish.tags ?? []).slice(0, 2);

  return (
    <Reveal delay={(index % 3) * 90} className="h-full">
      <article className="food-card group flex h-full flex-col">
        <div className="food-card-media relative aspect-[4/3] overflow-hidden">
          <SmartImage
            src={dish.image}
            alt={dish.name}
            className="h-full w-full"
            sizes="(max-width: 640px) 92vw, (max-width: 1024px) 45vw, 30vw"
          />
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-noir-950 via-noir-950/25 to-transparent" />
          <div className="food-card-shine" />

          <div className="pointer-events-none absolute left-3 top-3 flex flex-wrap gap-1.5">
            {offPercent > 0 && (
              <span className="rounded-full bg-gradient-to-r from-ember-400 to-ember-600 px-2.5 py-1 text-[0.6rem] font-black uppercase tracking-widest text-noir-950 shadow-lg">
                -{offPercent}%
              </span>
            )}
            {tags.map((tag) => {
              const meta = TAG_META[tag];
              if (!meta) return null;
              return (
                <span
                  key={tag}
                  className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[0.6rem] font-bold uppercase tracking-[0.14em] backdrop-blur-md ${meta.className}`}
                >
                  <Icon name={meta.icon} className="h-3 w-3" strokeWidth={2} />
                  {meta.label}
                </span>
              );
            })}
          </div>

          {dish.rating && (
            <span className="pointer-events-none absolute right-3 top-3 inline-flex items-center gap-1 rounded-full border border-gold-400/30 bg-noir-950/70 px-2.5 py-1 text-[0.68rem] font-bold text-gold-200 backdrop-blur-md">
              <Stars value={dish.rating} className="h-3 w-3" />
              {dish.rating.toFixed(1)}
            </span>
          )}

          <span className="pointer-events-none absolute bottom-3 left-3 text-[0.6rem] font-bold uppercase tracking-[0.24em] text-gold-300/85">
            {category?.label ?? "Menu"}
          </span>
        </div>

        <div className="flex flex-1 flex-col gap-3 p-5">
          <div>
            <h3 className="text-lg leading-snug text-cream transition-colors duration-300 group-hover:text-gold-200">
              {dish.name}
            </h3>
            <p className="mt-1.5 line-clamp-2 text-[0.83rem] leading-relaxed text-sand/70">{dish.description}</p>
          </div>

          <div className="mt-auto flex items-end justify-between gap-3">
            <div>
              <div className="flex items-baseline gap-2">
                <span className="font-display text-2xl text-gold-200">{formatPKR(dish.price)}</span>
                {dish.oldPrice && (
                  <span className="text-xs text-sand/50 line-through">{formatPKR(dish.oldPrice)}</span>
                )}
              </div>
              <span className="mt-0.5 block text-[0.66rem] uppercase tracking-[0.18em] text-sand/45">
                {dish.serves ?? "Single serving"}
              </span>
            </div>

            {qty === 0 ? (
              <button
                type="button"
                onClick={() => add(dish)}
                className="btn btn-gold shrink-0 !px-4 !py-2.5 !text-[0.7rem]"
                aria-label={`Add ${dish.name} to cart`}
              >
                <Icon name="plus" className="h-4 w-4" strokeWidth={2.4} />
                Add
              </button>
            ) : (
              <div className="flex shrink-0 items-center gap-1 rounded-full border border-gold-400/45 bg-gold-400/10 p-1">
                <button
                  type="button"
                  onClick={() => decrement(dish.id)}
                  className="grid h-8 w-8 place-items-center rounded-full text-gold-200 transition hover:bg-gold-400/25 active:scale-90"
                  aria-label={`Decrease quantity of ${dish.name}`}
                >
                  <Icon name="minus" className="h-4 w-4" strokeWidth={2.4} />
                </button>
                <span className="min-w-6 text-center font-display text-lg text-gold-100">{qty}</span>
                <button
                  type="button"
                  onClick={() => increment(dish.id)}
                  className="grid h-8 w-8 place-items-center rounded-full text-gold-200 transition hover:bg-gold-400/25 active:scale-90"
                  aria-label={`Increase quantity of ${dish.name}`}
                >
                  <Icon name="plus" className="h-4 w-4" strokeWidth={2.4} />
                </button>
              </div>
            )}
          </div>
        </div>

        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-gold-400/50 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
      </article>
    </Reveal>
  );
}

/** Wide "deal" card used on the offers + home pages. */
export function DealCard({ dish, index = 0 }: { dish: Dish; index?: number }) {
  const { add, qtyOf } = useCart();
  const qty = qtyOf(dish.id);
  const off = dish.oldPrice ? Math.round(((dish.oldPrice - dish.price) / dish.oldPrice) * 100) : 0;

  return (
    <Reveal delay={(index % 2) * 110} className="h-full">
      <article className="tilt-card group relative flex h-full flex-col overflow-hidden rounded-[1.4rem] border border-gold-400/15 bg-gradient-to-br from-noir-800/90 to-noir-950/95 sm:flex-row">
        <div className="relative aspect-[16/10] w-full shrink-0 overflow-hidden sm:aspect-auto sm:w-56">
          <SmartImage src={dish.image} alt={dish.name} className="h-full w-full" sizes="240px" />
          <div className="absolute inset-0 bg-gradient-to-r from-transparent to-noir-950/85" />
        </div>
        <div className="flex flex-1 flex-col gap-3 p-6">
          <div className="flex items-center gap-2">
            {off > 0 && (
              <span className="rounded-full bg-gradient-to-r from-ember-400 to-ember-600 px-2.5 py-1 text-[0.6rem] font-black uppercase tracking-widest text-noir-950">
                Save {off}%
              </span>
            )}
            <span className="text-[0.62rem] font-bold uppercase tracking-[0.2em] text-gold-300/80">
              {dish.serves}
            </span>
          </div>
          <h3 className="text-xl text-cream transition-colors group-hover:text-gold-200">{dish.name}</h3>
          <p className="text-[0.85rem] leading-relaxed text-sand/70">{dish.description}</p>
          <div className="mt-auto flex flex-wrap items-center justify-between gap-4 pt-2">
            <div className="flex items-baseline gap-2">
              <span className="font-display text-2xl gold-text">{formatPKR(dish.price)}</span>
              {dish.oldPrice && <span className="text-xs text-sand/50 line-through">{formatPKR(dish.oldPrice)}</span>}
            </div>
            {qty === 0 ? (
              <button type="button" onClick={() => add(dish)} className="btn btn-outline !px-5 !py-2.5 !text-[0.7rem]">
                <Icon name="bag" className="h-4 w-4" />
                Add deal
              </button>
            ) : (
              <Link href="/order" className="btn btn-gold !px-5 !py-2.5 !text-[0.7rem]">
                <Icon name="check" className="h-4 w-4" strokeWidth={2.4} />
                {qty} in cart
              </Link>
            )}
          </div>
        </div>
      </article>
    </Reveal>
  );
}
