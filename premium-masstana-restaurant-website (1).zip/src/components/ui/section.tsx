import type { ReactNode } from "react";

import { Reveal } from "./reveal";

export function GoldRule({ className = "mx-auto" }: { className?: string }) {
  return (
    <span className={`block h-px w-24 bg-gradient-to-r from-transparent via-gold-400/70 to-transparent ${className}`} />
  );
}

export function Eyebrow({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <span className={`inline-flex items-center gap-3 eyebrow ${className}`}>
      <span className="h-px w-8 bg-gold-400/60" />
      {children}
    </span>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  highlight,
  description,
  align = "center",
  className = "",
}: {
  eyebrow?: string;
  title: string;
  highlight?: string;
  description?: string;
  align?: "center" | "left";
  className?: string;
}) {
  const isCenter = align === "center";
  return (
    <div className={`${isCenter ? "mx-auto max-w-3xl text-center" : "max-w-2xl"} ${className}`}>
      {eyebrow && (
        <Reveal>
          <span className={`inline-flex items-center gap-3 eyebrow ${isCenter ? "" : ""}`}>
            <span className="h-px w-8 bg-gold-400/60" />
            {eyebrow}
            {isCenter && <span className="h-px w-8 bg-gold-400/60" />}
          </span>
        </Reveal>
      )}
      <Reveal delay={80}>
        <h2 className="mt-4 text-3xl leading-[1.1] text-cream sm:text-4xl lg:text-[2.9rem]">
          {title} {highlight && <span className="gold-text">{highlight}</span>}
        </h2>
      </Reveal>
      {description && (
        <Reveal delay={150}>
          <p className={`mt-4 text-[0.95rem] leading-relaxed text-sand/80 ${isCenter ? "mx-auto" : ""}`}>
            {description}
          </p>
        </Reveal>
      )}
      <Reveal delay={200}>
        <div className={`mt-6 ${isCenter ? "flex justify-center" : ""}`}>
          <GoldRule className={isCenter ? "" : "ml-0"} />
        </div>
      </Reveal>
    </div>
  );
}

export function Section({
  children,
  id,
  className = "",
}: {
  children: ReactNode;
  id?: string;
  className?: string;
}) {
  return (
    <section id={id} className={`relative z-10 scroll-mt-24 px-5 py-20 sm:px-8 lg:py-28 ${className}`}>
      <div className="mx-auto w-full max-w-7xl">{children}</div>
    </section>
  );
}

export function Badge({
  children,
  tone = "gold",
  className = "",
}: {
  children: ReactNode;
  tone?: "gold" | "ember" | "ghost";
  className?: string;
}) {
  const tones = {
    gold: "border-gold-400/40 bg-gold-400/12 text-gold-200",
    ember: "border-ember-400/40 bg-ember-400/12 text-ember-200",
    ghost: "border-cream/15 bg-cream/5 text-sand",
  } as const;
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[0.62rem] font-bold uppercase tracking-[0.18em] ${tones[tone]} ${className}`}
    >
      {children}
    </span>
  );
}
