"use client";

import Link from "next/link";
import { useState } from "react";

import { Icon } from "@/components/ui/icons";
import { Reveal } from "@/components/ui/reveal";
import { SmartImage } from "@/components/ui/smart-image";
import type { Offer } from "@/lib/data/content";

export function OfferGrid({ offers }: { offers: Offer[] }) {
  return (
    <div className="grid gap-6 md:grid-cols-2">
      {offers.map((offer, index) => (
        <OfferCard key={offer.code} offer={offer} index={index} />
      ))}
    </div>
  );
}

export function OfferCard({ offer, index = 0 }: { offer: Offer; index?: number }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(offer.code);
    } catch {
      /* clipboard blocked — code stays visible on screen */
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  const valueLabel =
    offer.kind === "percent"
      ? `${offer.value}% off`
      : offer.kind === "flat"
        ? `Rs ${offer.value.toLocaleString("en-PK")} off`
        : "Free delivery";

  return (
    <Reveal delay={(index % 2) * 100} className="h-full">
      <article className="tilt-card group relative flex h-full flex-col overflow-hidden rounded-[1.6rem] border border-gold-400/15 bg-gradient-to-br from-noir-800/90 to-noir-950/95">
        <div className="relative h-44 overflow-hidden">
          <SmartImage
            src={offer.image}
            alt={offer.title}
            className="h-full w-full"
            imgClassName="transition-transform duration-[900ms] group-hover:scale-110"
            sizes="(max-width: 768px) 92vw, 45vw"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-noir-950 via-noir-950/45 to-transparent" />
          <span className="absolute left-4 top-4 rounded-full bg-gradient-to-r from-ember-400 to-ember-600 px-3 py-1.5 text-[0.6rem] font-black uppercase tracking-[0.18em] text-noir-950">
            {offer.badge}
          </span>
          <span className="absolute bottom-4 left-4 font-display text-3xl gold-text">{valueLabel}</span>
        </div>

        <div className="flex flex-1 flex-col gap-3 p-6">
          <div>
            <p className="text-[0.66rem] uppercase tracking-[0.2em] text-gold-300/80">{offer.subtitle}</p>
            <h3 className="mt-1.5 text-xl text-cream transition-colors group-hover:text-gold-200">{offer.title}</h3>
          </div>
          <p className="text-[0.85rem] leading-relaxed text-sand/70">{offer.description}</p>

          <ul className="mt-1 space-y-1.5">
            {offer.terms.map((term) => (
              <li key={term} className="flex items-start gap-2 text-[0.75rem] text-sand/60">
                <Icon name="check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-gold-400" strokeWidth={2.2} />
                {term}
              </li>
            ))}
          </ul>

          <div className="mt-auto flex flex-wrap items-center justify-between gap-3 pt-4">
            <button
              type="button"
              onClick={copy}
              className="inline-flex items-center gap-2 rounded-xl border border-dashed border-gold-400/50 bg-gold-400/8 px-4 py-2 font-display text-base tracking-[0.14em] text-gold-200 transition hover:border-gold-400 hover:bg-gold-400/15 active:scale-95"
              aria-label={`Copy promo code ${offer.code}`}
            >
              <Icon name={copied ? "check" : "tag"} className="h-4 w-4" strokeWidth={2} />
              {offer.code}
              <span className="text-[0.62rem] uppercase tracking-[0.14em] text-sand/55">
                {copied ? "copied" : "tap to copy"}
              </span>
            </button>
            <span className="text-[0.7rem] text-sand/50">{offer.validUntil}</span>
          </div>

          <Link href="/order" className="btn btn-outline mt-2 w-full !text-[0.68rem]">
            <Icon name="bag" className="h-4 w-4" />
            Use this offer
          </Link>
        </div>
      </article>
    </Reveal>
  );
}
