"use client";

import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

import { Icon, Logo } from "../ui/icons";

/** Gold scroll-progress line pinned to the very top of the viewport. */
export function ScrollProgress() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const update = () => {
      const height = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(height > 0 ? Math.min(1, window.scrollY / height) : 0);
    };
    update();
    window.addEventListener("scroll", update, { passive: true });
    window.addEventListener("resize", update);
    return () => {
      window.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, []);

  return (
    <div className="pointer-events-none fixed inset-x-0 top-0 z-[100] h-0.5">
      <div
        className="h-full origin-left bg-gradient-to-r from-gold-300 via-gold-400 to-ember-500 shadow-[0_0_14px_rgba(217,169,79,0.7)]"
        style={{ transform: `scaleX(${progress})`, transition: "transform 120ms linear" }}
      />
    </div>
  );
}

/** Short cinematic brand loader shown once per session. */
export function Preloader() {
  const [visible, setVisible] = useState(true);
  const [gone, setGone] = useState(false);

  useEffect(() => {
    try {
      if (window.sessionStorage.getItem("masstana-loaded") === "1") {
        setVisible(false);
        setGone(true);
        return;
      }
    } catch {
      /* sessionStorage unavailable */
    }
    const hide = window.setTimeout(() => {
      setVisible(false);
      try {
        window.sessionStorage.setItem("masstana-loaded", "1");
      } catch {
        /* ignore */
      }
    }, 1100);
    const remove = window.setTimeout(() => setGone(true), 1900);
    return () => {
      window.clearTimeout(hide);
      window.clearTimeout(remove);
    };
  }, []);

  if (gone) return null;

  return (
    <div
      className={`fixed inset-0 z-[200] grid place-items-center bg-noir-950 transition-opacity duration-700 ${
        visible ? "opacity-100" : "pointer-events-none opacity-0"
      }`}
      aria-hidden={!visible}
    >
      <div className="flex flex-col items-center gap-6">
        <span className="animate-float">
          <Logo className="h-20 w-20" />
        </span>
        <div className="text-center">
          <p className="font-display text-2xl tracking-[0.42em] text-gold-200 text-shadow-gold">MASSTANA</p>
          <p className="mt-2 text-[0.58rem] font-semibold uppercase tracking-[0.5em] text-sand/60">
            Restaurant · Sargodha
          </p>
        </div>
        <div className="h-px w-44 overflow-hidden bg-cream/10">
          <div className="h-full w-1/3 animate-[loaderBar_1.1s_ease-in-out_infinite] bg-gradient-to-r from-transparent via-gold-300 to-transparent" />
        </div>
      </div>
    </div>
  );
}

/** Fade-up wrapper that re-animates on every route change. */
export function PageTransition({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  useEffect(() => {
    if (!("scrollRestoration" in window.history)) return;
    window.history.scrollRestoration = "manual";
  }, []);
  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!reduce && !window.location.hash) window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  }, [pathname]);

  return (
    <div key={pathname} className="page-enter">
      {children}
    </div>
  );
}

export function BackToTop() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 700);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <button
      type="button"
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      aria-label="Back to top"
      className={`fixed bottom-6 right-5 z-[70] grid h-12 w-12 place-items-center rounded-full border border-gold-400/40 bg-noir-900/85 text-gold-200 shadow-[0_16px_40px_-16px_rgba(217,169,79,0.8)] backdrop-blur-md transition-all duration-400 hover:-translate-y-1 hover:border-gold-400/90 active:scale-90 ${
        show ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0"
      }`}
    >
      <Icon name="arrowUp" className="h-5 w-5" strokeWidth={2} />
    </button>
  );
}
