"use client";

import { useState } from "react";

import { Icon } from "../ui/icons";

export function NewsletterForm() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "ok" | "error">("idle");

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    const valid = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim());
    setStatus(valid ? "ok" : "error");
    if (valid) setEmail("");
  };

  return (
    <form onSubmit={submit} className="mt-4">
      <div className="flex gap-2">
        <input
          type="email"
          required
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
            setStatus("idle");
          }}
          placeholder="Your email address"
          aria-label="Email address"
          className="field !py-3 text-[0.82rem]"
        />
        <button type="submit" className="btn btn-gold shrink-0 !px-4 !text-[0.66rem]" aria-label="Subscribe">
          <Icon name="send" className="h-4 w-4" strokeWidth={2} />
        </button>
      </div>
      <p
        className={`mt-2 text-[0.72rem] transition-opacity ${
          status === "idle" ? "text-sand/50" : status === "ok" ? "text-emerald-300" : "text-ember-300"
        }`}
      >
        {status === "ok"
          ? "Shukriya! You will receive our weekly deal sheet."
          : status === "error"
            ? "Please enter a valid email address."
            : "Weekly deals, new dishes and BBQ nights. No spam."}
      </p>
    </form>
  );
}
