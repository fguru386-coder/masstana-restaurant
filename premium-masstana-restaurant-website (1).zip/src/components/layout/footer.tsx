import Link from "next/link";

import { CATEGORIES } from "@/lib/data/menu";
import { IS_WHATSAPP_PLACEHOLDER, SITE, WHATSAPP_NUMBER } from "@/lib/site";
import { NAV_ITEMS, MORE_ITEMS as MORE_LINKS } from "@/lib/navigation";

import { NewsletterForm } from "./newsletter";
import { BrandIcon, Icon, Logo } from "../ui/icons";

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative z-10 mt-10 border-t border-gold-400/15 bg-noir-950/85">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold-400/60 to-transparent" />
      <div className="pointer-events-none absolute -top-28 left-1/2 h-56 w-[46rem] -translate-x-1/2 rounded-full bg-gold-500/8 blur-[110px]" />

      <div className="mx-auto max-w-[92rem] px-5 py-16 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.35fr_1fr_1fr_1.25fr]">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3">
              <Logo className="h-12 w-12" />
              <div>
                <p className="font-display text-lg tracking-[0.16em] text-cream">MASSTANA</p>
                <p className="text-[0.55rem] font-semibold uppercase tracking-[0.42em] text-gold-300/80">Restaurant</p>
              </div>
            </div>
            <p className="mt-5 max-w-sm text-[0.85rem] leading-relaxed text-sand/70">
              {SITE.tagline} in the heart of Sargodha. Charcoal BBQ, dum biryani, wok-fresh Chinese, continental grills,
              desi nashta and in-house desserts — served dine-in, takeaway or delivered hot to your door.
            </p>
            <p className="mt-4 inline-flex items-center gap-2 rounded-full border border-gold-400/25 bg-gold-400/8 px-3.5 py-1.5 text-[0.7rem] font-semibold uppercase tracking-[0.14em] text-gold-200">
              <Icon name="chef" className="h-4 w-4" />
              Owner · {SITE.owner}
            </p>
            <div className="mt-5 flex gap-2.5">
              {SITE.socials.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={social.label}
                  className="grid h-10 w-10 place-items-center rounded-full border border-cream/12 bg-cream/[0.03] text-sand transition duration-300 hover:-translate-y-1 hover:border-gold-400/60 hover:text-gold-200"
                >
                  <BrandIcon name={social.icon} className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Explore */}
          <div>
            <h3 className="eyebrow !text-[0.6rem]">Explore</h3>
            <ul className="mt-5 space-y-2.5">
              {[...NAV_ITEMS, ...MORE_LINKS].map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="group inline-flex items-center gap-2 text-[0.84rem] text-sand/75 transition hover:text-gold-200"
                  >
                    <span className="h-px w-0 bg-gold-400 transition-all duration-300 group-hover:w-4" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Menu */}
          <div>
            <h3 className="eyebrow !text-[0.6rem]">Our Kitchen</h3>
            <ul className="mt-5 space-y-2.5">
              {CATEGORIES.map((category) => (
                <li key={category.id}>
                  <Link
                    href={`/menu?c=${category.id}`}
                    className="group inline-flex items-center gap-2 text-[0.84rem] text-sand/75 transition hover:text-gold-200"
                  >
                    <span className="h-px w-0 bg-gold-400 transition-all duration-300 group-hover:w-4" />
                    {category.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Visit + newsletter */}
          <div>
            <h3 className="eyebrow !text-[0.6rem]">Visit &amp; Order</h3>
            <ul className="mt-5 space-y-3.5 text-[0.84rem] text-sand/75">
              <li className="flex items-start gap-3">
                <Icon name="pin" className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
                <span>
                  {SITE.name}
                  <br />
                  {SITE.addressLine}
                </span>
              </li>
              <li className="flex items-start gap-3">
                <Icon name="phone" className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
                <span>
                  <a href={SITE.phoneHref} className="transition hover:text-gold-200">
                    {SITE.phoneDisplay}
                  </a>
                  <br />
                  <span className="text-sand/55">(placeholder line)</span>
                </span>
              </li>
              <li className="flex items-start gap-3">
                <Icon name="mail" className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
                <a href={`mailto:${SITE.email}`} className="transition hover:text-gold-200">
                  {SITE.email}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Icon name="clock" className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
                <span>
                  Mon – Thu · 7 AM – 1 AM
                  <br />
                  Fri – Sun · 7 AM – 2:30 AM
                </span>
              </li>
            </ul>
            <NewsletterForm />
          </div>
        </div>

        <div className="mt-14 hairline" />

        <div className="mt-6 flex flex-col items-center justify-between gap-4 text-center text-[0.72rem] text-sand/50 sm:flex-row sm:text-left">
          <p>
            © {year} {SITE.name} · {SITE.addressShort}, {SITE.country} · Owned &amp; operated by {SITE.owner}
          </p>
          <p className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1">
            <span>Dine-in · Takeaway · Home Delivery</span>
            <span className="hidden h-3 w-px bg-cream/15 sm:block" />
            <span>All prices in PKR (Rs)</span>
          </p>
        </div>

        {IS_WHATSAPP_PLACEHOLDER && (
          <div className="mt-6 flex flex-col gap-2 rounded-2xl border border-ember-400/25 bg-ember-500/8 p-4 text-[0.74rem] leading-relaxed text-ember-200/90 sm:flex-row sm:items-center">
            <span className="inline-flex shrink-0 items-center gap-2 font-bold uppercase tracking-[0.16em] text-ember-300">
              <Icon name="sparkle" className="h-4 w-4" />
              Owner setup
            </span>
            <span>
              The WhatsApp number is still the placeholder <code className="rounded bg-noir-950/70 px-1.5 py-0.5 text-gold-200">{WHATSAPP_NUMBER}</code>.
              Replace it in <code className="rounded bg-noir-950/70 px-1.5 py-0.5 text-gold-200">src/lib/site.ts</code> (or set{" "}
              <code className="rounded bg-noir-950/70 px-1.5 py-0.5 text-gold-200">NEXT_PUBLIC_WHATSAPP_NUMBER</code>) with your real number in
              international format, e.g. 923001234567.
            </span>
          </div>
        )}
      </div>
    </footer>
  );
}
