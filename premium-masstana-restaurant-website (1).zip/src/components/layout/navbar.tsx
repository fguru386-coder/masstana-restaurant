"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

import { useCart } from "@/components/cart/cart-provider";
import { SITE, whatsappLink } from "@/lib/site";

import { MORE_ITEMS, NAV_ITEMS } from "@/lib/navigation";

import { BrandIcon, Icon, Logo } from "../ui/icons";

export function Navbar() {
  const pathname = usePathname();
  const { itemCount, openCart } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 26);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    setMoreOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  const isActive = (href: string) => (href === "/" ? pathname === "/" : pathname.startsWith(href));

  return (
    <>
      {/* Utility strip */}
      <div
        className={`relative z-50 hidden overflow-hidden border-b border-gold-400/10 bg-noir-950/80 text-[0.68rem] text-sand/70 transition-all duration-500 lg:block ${
          scrolled ? "max-h-0 opacity-0" : "max-h-12 opacity-100"
        }`}
      >
        <div className="mx-auto flex max-w-[92rem] items-center justify-between gap-6 px-8 py-2">
          <span className="inline-flex items-center gap-2">
            <Icon name="pin" className="h-3.5 w-3.5 text-gold-400" />
            {SITE.addressLine}
          </span>
          <span className="inline-flex items-center gap-2">
            <Icon name="clock" className="h-3.5 w-3.5 text-gold-400" />
            Open daily 7:00 AM – 2:00 AM · BBQ from 5 PM
          </span>
          <span className="flex items-center gap-5">
            <a href={SITE.phoneHref} className="inline-flex items-center gap-2 transition hover:text-gold-200">
              <Icon name="phone" className="h-3.5 w-3.5 text-gold-400" />
              {SITE.phoneDisplay}
            </a>
            <span className="h-3 w-px bg-cream/15" />
            {SITE.socials.map((social) => (
              <a
                key={social.label}
                href={social.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={social.label}
                className="transition hover:text-gold-200"
              >
                <BrandIcon name={social.icon} className="h-3.5 w-3.5" />
              </a>
            ))}
          </span>
        </div>
      </div>

      <header
        className={`sticky top-0 z-[80] transition-all duration-500 ${
          scrolled || mobileOpen
            ? "border-b border-gold-400/15 bg-noir-950/85 shadow-[0_16px_44px_-28px_rgba(0,0,0,1)] backdrop-blur-xl"
            : "border-b border-transparent bg-gradient-to-b from-noir-950/70 to-transparent"
        }`}
      >
        <nav className="mx-auto flex max-w-[92rem] items-center justify-between gap-6 px-5 py-3.5 sm:px-8">
          <Link href="/" className="group flex items-center gap-3">
            <Logo className="h-11 w-11 transition-transform duration-500 group-hover:rotate-[8deg]" />
            <span className="leading-none">
              <span className="block font-display text-[1.05rem] tracking-[0.16em] text-cream sm:text-[1.2rem]">
                MASSTANA
              </span>
              <span className="mt-1 block text-[0.54rem] font-semibold uppercase tracking-[0.42em] text-gold-300/80">
                Restaurant
              </span>
            </span>
          </Link>

          <div className="hidden items-center gap-6 xl:flex">
            {NAV_ITEMS.map((item) => (
              <Link key={item.href} href={item.href} className="nav-link" data-active={isActive(item.href)}>
                {item.label}
              </Link>
            ))}
            <div className="relative">
              <button
                type="button"
                onClick={() => setMoreOpen((v) => !v)}
                className="nav-link inline-flex items-center gap-1"
                data-active={MORE_ITEMS.some((i) => isActive(i.href))}
                aria-expanded={moreOpen}
              >
                More
                <Icon name="chevronDown" className={`h-3.5 w-3.5 transition-transform ${moreOpen ? "rotate-180" : ""}`} />
              </button>
              <div
                className={`glass absolute right-0 top-full mt-3 w-52 overflow-hidden rounded-2xl p-2 transition-all duration-300 ${
                  moreOpen ? "translate-y-0 opacity-100" : "pointer-events-none -translate-y-2 opacity-0"
                }`}
              >
                {MORE_ITEMS.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="flex items-center gap-2 rounded-xl px-3 py-2.5 text-[0.78rem] font-semibold uppercase tracking-[0.1em] text-sand transition hover:bg-gold-400/12 hover:text-gold-200"
                  >
                    <span className="h-1 w-1 rounded-full bg-gold-400" />
                    {item.label}
                  </Link>
                ))}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <a
              href={whatsappLink(
                `Assalam-o-Alaikum ${SITE.name}! I would like to place an order.\n\n${SITE.addressLine}`,
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden h-11 w-11 place-items-center rounded-full border border-gold-400/30 text-gold-200 transition hover:border-gold-400/70 hover:bg-gold-400/10 sm:grid"
              aria-label="Order on WhatsApp"
            >
              <BrandIcon name="whatsapp" className="h-5 w-5" />
            </a>

            <button
              type="button"
              onClick={openCart}
              className="relative grid h-11 w-11 place-items-center rounded-full border border-gold-400/30 text-gold-200 transition hover:border-gold-400/70 hover:bg-gold-400/10 active:scale-90"
              aria-label={`Open cart, ${itemCount} items`}
            >
              <Icon name="bag" className="h-5 w-5" />
              {itemCount > 0 && (
                <span className="animate-pop absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-gradient-to-br from-ember-400 to-ember-600 px-1 text-[0.62rem] font-black text-noir-950">
                  {itemCount}
                </span>
              )}
            </button>

            <Link href="/order" className="btn btn-gold hidden !px-5 !py-2.5 !text-[0.68rem] md:inline-flex">
              Order Now
              <Icon name="arrowRight" className="h-4 w-4" />
            </Link>

            <button
              type="button"
              onClick={() => setMobileOpen((v) => !v)}
              className="grid h-11 w-11 place-items-center rounded-full border border-cream/15 text-cream transition hover:border-gold-400/60 xl:hidden"
              aria-label="Toggle navigation menu"
              aria-expanded={mobileOpen}
            >
              <Icon name={mobileOpen ? "close" : "menu"} className="h-5 w-5" strokeWidth={2} />
            </button>
          </div>
        </nav>
      </header>

      {/* Mobile drawer */}
      <div
        className={`fixed inset-0 z-[79] xl:hidden ${mobileOpen ? "" : "pointer-events-none"}`}
        aria-hidden={!mobileOpen}
      >
        <div
          className={`absolute inset-0 bg-noir-950/85 backdrop-blur-md transition-opacity duration-400 ${
            mobileOpen ? "opacity-100" : "opacity-0"
          }`}
          onClick={() => setMobileOpen(false)}
        />
        <div
          className={`absolute inset-x-0 top-0 origin-top overflow-y-auto px-5 pb-10 pt-24 transition-all duration-500 [transition-timing-function:cubic-bezier(0.22,1,0.36,1)] ${
            mobileOpen ? "translate-y-0 opacity-100" : "-translate-y-6 opacity-0"
          }`}
        >
          <div className="glass mx-auto max-w-lg rounded-3xl p-6">
            <p className="eyebrow !text-[0.6rem]">Explore Masstana</p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              {[...NAV_ITEMS, ...MORE_ITEMS].map((item, index) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex items-center gap-2 rounded-2xl border px-4 py-3 text-[0.8rem] font-semibold uppercase tracking-[0.1em] transition ${
                    isActive(item.href)
                      ? "border-gold-400/60 bg-gold-400/12 text-gold-200"
                      : "border-cream/10 bg-cream/[0.03] text-sand hover:border-gold-400/40 hover:text-gold-200"
                  }`}
                  style={{ transitionDelay: `${index * 18}ms` }}
                >
                  <span className="h-1.5 w-1.5 rounded-full bg-gradient-to-r from-gold-400 to-ember-500" />
                  {item.label}
                </Link>
              ))}
            </div>

            <div className="mt-5 grid gap-2">
              <Link href="/order" className="btn btn-gold w-full">
                <Icon name="bag" className="h-4 w-4" />
                Order online
              </Link>
              <div className="grid grid-cols-2 gap-2">
                <a href={SITE.phoneHref} className="btn btn-outline w-full !px-3 !text-[0.66rem]">
                  <Icon name="phone" className="h-4 w-4" />
                  Call
                </a>
                <a
                  href={SITE.mapLinkUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-ghost w-full !px-3 !text-[0.66rem]"
                >
                  <Icon name="map" className="h-4 w-4" />
                  Map
                </a>
              </div>
            </div>

            <div className="mt-6 space-y-2 border-t border-gold-400/15 pt-5 text-[0.78rem] text-sand/70">
              <p className="flex items-start gap-2">
                <Icon name="pin" className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
                {SITE.addressLine}
              </p>
              <p className="flex items-start gap-2">
                <Icon name="clock" className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
                Open daily 7:00 AM – 2:00 AM
              </p>
              <p className="flex items-start gap-2">
                <Icon name="user" className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
                Owner: {SITE.owner}
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
