import Link from "next/link";
import type { ReactNode } from "react";

import { Icon } from "../ui/icons";
import { SmartImage } from "../ui/smart-image";

export function PageHero({
  eyebrow,
  title,
  highlight,
  description,
  image,
  crumb,
  children,
  compact = false,
}: {
  eyebrow: string;
  title: string;
  highlight?: string;
  description?: string;
  image: string;
  crumb: string;
  children?: ReactNode;
  compact?: boolean;
}) {
  return (
    <section
      className={`relative overflow-hidden ${compact ? "min-h-[300px] py-20" : "min-h-[380px] py-24"} sm:py-28 lg:py-32`}
    >
      <div className="absolute inset-0 -z-10">
        <SmartImage
          src={image}
          alt=""
          className="h-full w-full animate-kenburns"
          imgClassName="opacity-45"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-noir-950/85 via-noir-950/75 to-noir-950" />
        <div className="absolute inset-0 bg-[radial-gradient(60rem_30rem_at_20%_20%,rgba(217,169,79,0.18),transparent_65%)]" />
      </div>

      <div className="mx-auto w-full max-w-7xl px-5 sm:px-8">
        <nav aria-label="Breadcrumb" className="page-enter flex items-center gap-2 text-[0.68rem] uppercase tracking-[0.2em] text-sand/55">
          <Link href="/" className="transition hover:text-gold-200">
            Home
          </Link>
          <Icon name="chevronDown" className="h-3 w-3 -rotate-90 text-gold-400/60" />
          <span className="text-gold-300">{crumb}</span>
        </nav>

        <div className="page-enter mt-6 max-w-3xl" style={{ animationDelay: "80ms" }}>
          <span className="inline-flex items-center gap-3 eyebrow">
            <span className="h-px w-8 bg-gold-400/60" />
            {eyebrow}
          </span>
          <h1 className="mt-4 text-4xl leading-[1.05] text-cream sm:text-5xl lg:text-[3.6rem]">
            {title} {highlight && <span className="gold-text">{highlight}</span>}
          </h1>
          {description && <p className="mt-5 max-w-2xl text-[0.95rem] leading-relaxed text-sand/80">{description}</p>}
          {children && <div className="mt-8">{children}</div>}
        </div>
      </div>

      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-noir-950 to-transparent" />
    </section>
  );
}
