"use client";

import { useCallback, useEffect, useState } from "react";

import { GALLERY_GROUPS, type GalleryItem } from "@/lib/data/content";

import { Icon } from "../ui/icons";
import { Reveal } from "../ui/reveal";
import { SmartImage } from "../ui/smart-image";

export function GalleryGrid({ items }: { items: GalleryItem[] }) {
  const [group, setGroup] = useState("All");
  const [lightbox, setLightbox] = useState<number | null>(null);

  const visible = group === "All" ? items : items.filter((item) => item.group === group);

  const close = useCallback(() => setLightbox(null), []);
  const step = useCallback(
    (direction: number) => {
      setLightbox((current) => {
        if (current === null) return current;
        return (current + direction + visible.length) % visible.length;
      });
    },
    [visible.length],
  );

  useEffect(() => {
    if (lightbox === null) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") close();
      if (event.key === "ArrowRight") step(1);
      if (event.key === "ArrowLeft") step(-1);
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [lightbox, close, step]);

  const active = lightbox !== null ? visible[lightbox] : null;

  return (
    <div>
      <div className="no-scrollbar mb-10 flex gap-2 overflow-x-auto pb-1">
        {GALLERY_GROUPS.map((name) => (
          <button key={name} type="button" onClick={() => setGroup(name)} data-active={group === name} className="chip">
            {name}
            <span className="text-[0.62rem] opacity-70">
              {name === "All" ? items.length : items.filter((i) => i.group === name).length}
            </span>
          </button>
        ))}
      </div>

      <div className="columns-1 gap-5 sm:columns-2 lg:columns-3 [&>*]:mb-5">
        {visible.map((item, index) => (
          <Reveal key={`${item.src}-${index}`} delay={(index % 3) * 80}>
            <button
              type="button"
              onClick={() => setLightbox(index)}
              className="group relative block w-full overflow-hidden rounded-[1.4rem] border border-gold-400/12 text-left transition duration-500 hover:border-gold-400/50"
              aria-label={`Open photo: ${item.alt}`}
            >
              <SmartImage
                src={item.src}
                alt={item.alt}
                className={`${item.tall ? "aspect-[3/4]" : "aspect-[4/3]"} w-full`}
                imgClassName="transition-transform duration-[900ms] group-hover:scale-110"
              />
              <span className="absolute inset-0 bg-gradient-to-t from-noir-950 via-noir-950/10 to-transparent opacity-70 transition-opacity duration-500 group-hover:opacity-90" />
              <span className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-4">
                <span className="translate-y-2 text-[0.78rem] font-semibold leading-snug text-cream opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                  {item.alt}
                </span>
                <span className="shrink-0 rounded-full border border-gold-400/40 bg-noir-950/70 px-2.5 py-1 text-[0.58rem] font-bold uppercase tracking-[0.16em] text-gold-200">
                  {item.group}
                </span>
              </span>
              <span className="pointer-events-none absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-full bg-noir-950/60 text-gold-200 opacity-0 backdrop-blur transition-all duration-500 group-hover:opacity-100">
                <Icon name="search" className="h-4 w-4" />
              </span>
            </button>
          </Reveal>
        ))}
      </div>

      {active && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center bg-noir-950/95 p-4 backdrop-blur-xl" role="dialog" aria-modal="true">
          <button
            type="button"
            onClick={close}
            className="absolute right-5 top-5 grid h-11 w-11 place-items-center rounded-full border border-cream/20 text-cream transition hover:border-gold-400/70 hover:text-gold-200"
            aria-label="Close photo"
          >
            <Icon name="close" className="h-5 w-5" strokeWidth={2} />
          </button>
          <button
            type="button"
            onClick={() => step(-1)}
            className="absolute left-3 grid h-12 w-12 place-items-center rounded-full border border-gold-400/30 bg-noir-900/70 text-gold-200 transition hover:border-gold-400/80 sm:left-8"
            aria-label="Previous photo"
          >
            <Icon name="arrowLeft" className="h-5 w-5" strokeWidth={2} />
          </button>
          <button
            type="button"
            onClick={() => step(1)}
            className="absolute right-3 grid h-12 w-12 place-items-center rounded-full border border-gold-400/30 bg-noir-900/70 text-gold-200 transition hover:border-gold-400/80 sm:right-8"
            aria-label="Next photo"
          >
            <Icon name="arrowRight" className="h-5 w-5" strokeWidth={2} />
          </button>

          <figure className="fade-in w-full max-w-4xl">
            <SmartImage src={active.src} alt={active.alt} className="aspect-[16/10] w-full rounded-3xl" priority />
            <figcaption className="mt-4 flex flex-wrap items-center justify-between gap-3 text-[0.82rem] text-sand/75">
              <span>{active.alt}</span>
              <span className="text-gold-300">
                {(lightbox ?? 0) + 1} / {visible.length} · {active.group}
              </span>
            </figcaption>
          </figure>
        </div>
      )}
    </div>
  );
}
