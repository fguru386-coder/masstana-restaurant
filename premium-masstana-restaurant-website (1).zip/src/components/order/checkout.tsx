"use client";

import Link from "next/link";
import { useState } from "react";

import { useCart } from "@/components/cart/cart-provider";
import { Icon } from "@/components/ui/icons";
import { Reveal } from "@/components/ui/reveal";
import { SmartImage } from "@/components/ui/smart-image";
import { DELIVERY_ZONES } from "@/lib/data/content";
import type { Dish } from "@/lib/data/menu";
import { DELIVERY, IS_WHATSAPP_PLACEHOLDER, SITE, WHATSAPP_NUMBER, formatPKR, whatsappLink } from "@/lib/site";
import { buildOrderMessage, prettyOrderType, prettyPayment } from "@/lib/whatsapp";

type Result = {
  code: string;
  persisted: boolean;
  totals: { subtotal: number; deliveryFee: number; discount: number; total: number; itemCount: number };
};

const PAYMENTS = [
  { id: "cash", label: "Cash on delivery", icon: "receipt" },
  { id: "easypaisa", label: "EasyPaisa / JazzCash", icon: "phone" },
  { id: "card", label: "Card on delivery", icon: "tag" },
];

export function Checkout({ suggestions }: { suggestions: Dish[] }) {
  const {
    lines,
    itemCount,
    subtotal,
    deliveryFee,
    discount,
    total,
    freeDeliveryGap,
    orderType,
    area,
    promoCode,
    promo,
    promoMessage,
    increment,
    decrement,
    remove,
    clear,
    setOrderType,
    setArea,
    applyPromo,
    clearPromo,
    add,
    qtyOf,
    openCart,
  } = useCart();

  const [form, setForm] = useState({ name: "", phone: "", address: "", notes: "", payment: "cash" });
  const [code, setCode] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [failure, setFailure] = useState("");

  const update = (key: keyof typeof form, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: "" }));
  };

  const validate = () => {
    const next: Record<string, string> = {};
    if (form.name.trim().length < 2) next.name = "Please enter your full name.";
    const digits = form.phone.replace(/\D/g, "");
    if (digits.length < 10) next.phone = "Enter a valid phone number, e.g. 0300 1234567.";
    if (orderType === "delivery" && form.address.trim().length < 8) {
      next.address = "Please enter your complete delivery address (house, street, mohalla).";
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setFailure("");
    if (lines.length === 0) {
      setFailure("Your cart is empty — add a few dishes first.");
      return;
    }
    if (!validate()) return;

    setSubmitting(true);
    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: form.name,
          phone: form.phone,
          address: form.address,
          area,
          orderType,
          notes: form.notes,
          paymentMethod: form.payment,
          promoCode: promo ? promo.code : undefined,
          items: lines.map((line) => ({
            id: line.id,
            name: line.name,
            price: line.price,
            qty: line.qty,
            image: line.image,
            category: line.category,
          })),
        }),
      });
      const data = await response.json();
      if (!response.ok || !data.ok) {
        setFailure(data?.error ?? "Something went wrong while saving your order.");
        setSubmitting(false);
        return;
      }
      setResult({ code: data.code, persisted: Boolean(data.persisted), totals: data.totals });
      clear();
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch {
      setFailure("Could not reach the order server. Please try again or order on WhatsApp.");
    } finally {
      setSubmitting(false);
    }
  };

  const message = buildOrderMessage({
    lines,
    subtotal,
    deliveryFee,
    discount,
    total,
    itemCount,
    customerName: form.name,
    phone: form.phone,
    address: form.address,
    area,
    orderType,
    notes: form.notes,
    promoCode: promo ? promo.code : undefined,
    paymentMethod: form.payment,
    orderCode: result?.code,
  });

  /* ---------------- confirmation state ---------------- */
  if (result) {
    return (
      <div className="mx-auto max-w-3xl">
        <Reveal>
          <div className="glass relative overflow-hidden rounded-[2rem] p-8 text-center sm:p-12">
            <div className="pointer-events-none absolute -top-24 left-1/2 h-56 w-72 -translate-x-1/2 rounded-full bg-gold-500/15 blur-[90px]" />
            <span className="animate-glow-ring mx-auto grid h-20 w-20 place-items-center rounded-full bg-gradient-to-br from-gold-300 to-ember-500 text-noir-950">
              <Icon name="check" className="h-9 w-9" strokeWidth={2.6} />
            </span>
            <h2 className="mt-6 text-3xl text-cream">Order received, shukriya!</h2>
            <p className="mt-3 text-[0.92rem] text-sand/75">
              Your order has been recorded by {SITE.name}. Our kitchen confirms every order by phone or WhatsApp within
              a few minutes.
            </p>
            <div className="mt-6 inline-flex items-center gap-3 rounded-2xl border border-gold-400/35 bg-gold-400/10 px-6 py-3">
              <Icon name="receipt" className="h-5 w-5 text-gold-300" />
              <span className="font-display text-2xl tracking-[0.12em] text-gold-100">{result.code}</span>
            </div>

            <dl className="mt-8 grid gap-3 text-left sm:grid-cols-2">
              {[
                { label: "Items", value: `${result.totals.itemCount} item(s)` },
                { label: "Subtotal", value: formatPKR(result.totals.subtotal) },
                {
                  label: orderType === "delivery" ? "Delivery" : "Service",
                  value: result.totals.deliveryFee === 0 ? "FREE" : formatPKR(result.totals.deliveryFee),
                },
                { label: "Discount", value: result.totals.discount > 0 ? `-${formatPKR(result.totals.discount)}` : "—" },
                { label: "Order type", value: prettyOrderType(orderType) },
                { label: "Payment", value: prettyPayment(form.payment) },
              ].map((row) => (
                <div key={row.label} className="flex items-center justify-between gap-3 rounded-xl border border-cream/8 bg-cream/[0.02] px-4 py-3">
                  <dt className="text-[0.76rem] uppercase tracking-[0.14em] text-sand/55">{row.label}</dt>
                  <dd className="font-semibold text-cream">{row.value}</dd>
                </div>
              ))}
              <div className="flex items-center justify-between gap-3 rounded-xl border border-gold-400/40 bg-gold-400/10 px-4 py-3 sm:col-span-2">
                <dt className="font-display text-base text-gold-200">Total payable</dt>
                <dd className="font-display text-2xl gold-text">{formatPKR(result.totals.total)}</dd>
              </div>
            </dl>

            <div className="mt-8 grid gap-3 sm:grid-cols-2">
              <a href={whatsappLink(message)} target="_blank" rel="noopener noreferrer" className="btn btn-gold w-full">
                <Icon name="phone" className="h-4 w-4" />
                Send order on WhatsApp
              </a>
              <Link href="/menu" className="btn btn-outline w-full">
                <Icon name="arrowLeft" className="h-4 w-4" />
                Order something else
              </Link>
            </div>

            <div className="mt-8 space-y-2 rounded-2xl border border-cream/10 bg-noir-950/50 p-4 text-left text-[0.74rem] leading-relaxed text-sand/60">
              <p className="flex items-center gap-2 font-bold uppercase tracking-[0.14em] text-gold-300">
                <Icon name="sparkle" className="h-4 w-4" /> Demo &amp; setup notes
              </p>
              <p>
                {result.persisted
                  ? "This order was written to the restaurant's PostgreSQL database through the /api/orders endpoint."
                  : "The database was unreachable in this preview, so the order was generated locally only. In production it is written through the /api/orders endpoint."}
              </p>
              {IS_WHATSAPP_PLACEHOLDER && (
                <p>
                  WhatsApp button currently uses the placeholder <code className="text-gold-200">{WHATSAPP_NUMBER}</code> — the owner
                  must set the real number in <code className="text-gold-200">src/lib/site.ts</code>.
                </p>
              )}
              <p>No payment was taken online. Payment is collected on delivery or at the counter.</p>
            </div>
          </div>
        </Reveal>
      </div>
    );
  }

  /* ---------------- empty cart ---------------- */
  if (lines.length === 0) {
    return (
      <div className="glass mx-auto max-w-xl rounded-[2rem] p-10 text-center">
        <span className="mx-auto grid h-20 w-20 place-items-center rounded-full border border-gold-400/25 bg-gold-400/5">
          <Icon name="bag" className="h-9 w-9 text-gold-300/70" />
        </span>
        <h2 className="mt-6 text-2xl text-cream">Your cart is empty</h2>
        <p className="mt-2 text-[0.88rem] text-sand/70">
          Pick your favourites from the menu — biryani, BBQ platters, burgers, Chinese or a family deal — and come back
          here to check out in under a minute.
        </p>
        <div className="mt-7 flex flex-wrap justify-center gap-3">
          <Link href="/menu" className="btn btn-gold">
            <Icon name="utensils" className="h-4 w-4" />
            Browse full menu
          </Link>
          <Link href="/offers" className="btn btn-outline">
            <Icon name="tag" className="h-4 w-4" />
            See today's deals
          </Link>
        </div>
      </div>
    );
  }

  /* ---------------- checkout ---------------- */
  return (
    <form onSubmit={submit} className="grid gap-8 lg:grid-cols-[1.15fr_0.85fr] lg:items-start">
      <div className="space-y-6">
        {/* cart lines */}
        <Reveal>
          <section className="glass rounded-[1.75rem] p-6">
            <div className="flex items-center justify-between gap-4">
              <h2 className="text-xl text-cream">
                Your order <span className="text-gold-300">({itemCount})</span>
              </h2>
              <div className="flex gap-2">
                <button type="button" onClick={openCart} className="btn btn-ghost !px-3 !py-2 !text-[0.62rem]">
                  <Icon name="bag" className="h-3.5 w-3.5" />
                  Cart
                </button>
                <button type="button" onClick={clear} className="btn btn-ghost !px-3 !py-2 !text-[0.62rem]">
                  <Icon name="trash" className="h-3.5 w-3.5" />
                  Clear
                </button>
              </div>
            </div>

            <ul className="mt-5 divide-y divide-cream/8">
              {lines.map((line) => (
                <li key={line.id} className="flex items-center gap-4 py-4">
                  <SmartImage src={line.image} alt={line.name} className="h-16 w-16 shrink-0 rounded-xl" sizes="64px" />
                  <div className="min-w-0 flex-1">
                    <h3 className="truncate text-[0.92rem] text-cream">{line.name}</h3>
                    <p className="text-[0.74rem] text-sand/55">{formatPKR(line.price)} each</p>
                  </div>
                  <div className="flex items-center gap-1 rounded-full border border-gold-400/35 bg-gold-400/8 p-0.5">
                    <button
                      type="button"
                      onClick={() => decrement(line.id)}
                      className="grid h-7 w-7 place-items-center rounded-full text-gold-200 transition hover:bg-gold-400/25 active:scale-90"
                      aria-label={`Decrease ${line.name}`}
                    >
                      <Icon name="minus" className="h-3.5 w-3.5" strokeWidth={2.4} />
                    </button>
                    <span className="min-w-5 text-center text-sm font-bold text-gold-100">{line.qty}</span>
                    <button
                      type="button"
                      onClick={() => increment(line.id)}
                      className="grid h-7 w-7 place-items-center rounded-full text-gold-200 transition hover:bg-gold-400/25 active:scale-90"
                      aria-label={`Increase ${line.name}`}
                    >
                      <Icon name="plus" className="h-3.5 w-3.5" strokeWidth={2.4} />
                    </button>
                  </div>
                  <span className="w-24 shrink-0 text-right font-display text-base text-gold-200">
                    {formatPKR(line.price * line.qty)}
                  </span>
                  <button
                    type="button"
                    onClick={() => remove(line.id)}
                    className="shrink-0 text-sand/45 transition hover:text-ember-400"
                    aria-label={`Remove ${line.name}`}
                  >
                    <Icon name="trash" className="h-4 w-4" />
                  </button>
                </li>
              ))}
            </ul>

            {/* order type */}
            <div className="mt-6 grid gap-3 sm:grid-cols-3">
              {(["delivery", "pickup", "dine-in"] as const).map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setOrderType(type)}
                  data-active={orderType === type}
                  className="chip justify-center !px-3 !py-3 !text-[0.68rem]"
                >
                  <Icon name={type === "delivery" ? "bike" : type === "pickup" ? "bag" : "utensils"} className="h-4 w-4" />
                  {type === "delivery" ? "Home delivery" : type === "pickup" ? "Takeaway" : "Dine-in"}
                </button>
              ))}
            </div>

            {orderType === "delivery" && (
              <div className="mt-4">
                <label htmlFor="area" className="mb-2 block text-[0.72rem] font-bold uppercase tracking-[0.16em] text-sand/60">
                  Delivery area
                </label>
                <select id="area" className="field" value={area} onChange={(e) => setArea(e.target.value)}>
                  {DELIVERY_ZONES.map((zone) => (
                    <option key={zone.area} value={zone.area}>
                      {zone.area} — {zone.fee === 0 ? "fee on request" : formatPKR(zone.fee)} · {zone.eta}
                    </option>
                  ))}
                </select>
                {freeDeliveryGap > 0 ? (
                  <p className="mt-2 text-[0.74rem] text-sand/60">
                    Add <span className="font-bold text-gold-200">{formatPKR(freeDeliveryGap)}</span> more for free delivery.
                  </p>
                ) : (
                  <p className="mt-2 text-[0.74rem] font-semibold text-emerald-300">
                    Free delivery unlocked — orders above {formatPKR(DELIVERY.freeOver)}.
                  </p>
                )}
              </div>
            )}
          </section>
        </Reveal>

        {/* customer details */}
        <Reveal delay={80}>
          <section className="glass rounded-[1.75rem] p-6">
            <h2 className="text-xl text-cream">Delivery &amp; contact details</h2>
            <p className="mt-1 text-[0.82rem] text-sand/65">
              We call this number to confirm your order before dispatch.
            </p>

            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-1">
                <label htmlFor="name" className="mb-2 block text-[0.72rem] font-bold uppercase tracking-[0.16em] text-sand/60">
                  Full name *
                </label>
                <input
                  id="name"
                  className="field"
                  value={form.name}
                  onChange={(e) => update("name", e.target.value)}
                  placeholder="e.g. Ahmed Raza"
                  autoComplete="name"
                />
                {errors.name && <p className="mt-1.5 text-[0.72rem] text-ember-300">{errors.name}</p>}
              </div>

              <div className="sm:col-span-1">
                <label htmlFor="phone" className="mb-2 block text-[0.72rem] font-bold uppercase tracking-[0.16em] text-sand/60">
                  Phone / WhatsApp *
                </label>
                <input
                  id="phone"
                  className="field"
                  value={form.phone}
                  onChange={(e) => update("phone", e.target.value)}
                  placeholder="0300 1234567"
                  inputMode="tel"
                  autoComplete="tel"
                />
                {errors.phone && <p className="mt-1.5 text-[0.72rem] text-ember-300">{errors.phone}</p>}
              </div>

              {orderType === "delivery" && (
                <div className="sm:col-span-2">
                  <label htmlFor="address" className="mb-2 block text-[0.72rem] font-bold uppercase tracking-[0.16em] text-sand/60">
                    Complete address *
                  </label>
                  <textarea
                    id="address"
                    rows={3}
                    className="field resize-none"
                    value={form.address}
                    onChange={(e) => update("address", e.target.value)}
                    placeholder="House #, street, mohalla / colony, landmark, Sargodha"
                    autoComplete="street-address"
                  />
                  {errors.address && <p className="mt-1.5 text-[0.72rem] text-ember-300">{errors.address}</p>}
                </div>
              )}

              <div className="sm:col-span-2">
                <label htmlFor="notes" className="mb-2 block text-[0.72rem] font-bold uppercase tracking-[0.16em] text-sand/60">
                  Order notes (optional)
                </label>
                <textarea
                  id="notes"
                  rows={2}
                  className="field resize-none"
                  value={form.notes}
                  onChange={(e) => update("notes", e.target.value)}
                  placeholder="Less spicy · no onion · extra naan · call on arrival…"
                />
              </div>

              <fieldset className="sm:col-span-2">
                <legend className="mb-2 block text-[0.72rem] font-bold uppercase tracking-[0.16em] text-sand/60">
                  Payment method
                </legend>
                <div className="grid gap-2 sm:grid-cols-3">
                  {PAYMENTS.map((method) => (
                    <button
                      key={method.id}
                      type="button"
                      onClick={() => update("payment", method.id)}
                      data-active={form.payment === method.id}
                      className="chip justify-center !px-3 !py-3 !text-[0.66rem]"
                    >
                      <Icon name={method.icon} className="h-4 w-4" />
                      {method.label}
                    </button>
                  ))}
                </div>
              </fieldset>
            </div>
          </section>
        </Reveal>
      </div>

      {/* summary */}
      <div className="lg:sticky lg:top-28">
        <Reveal delay={40}>
          <section className="glass rounded-[1.75rem] p-6">
            <h2 className="text-xl text-cream">Order summary</h2>

            <div className="mt-5 flex gap-2">
              <input
                className="field !py-2.5 text-[0.8rem] uppercase tracking-wider"
                placeholder="Promo code"
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    applyPromo(code);
                  }
                }}
                aria-label="Promo code"
              />
              <button type="button" onClick={() => applyPromo(code)} className="btn btn-outline shrink-0 !px-4 !py-2.5 !text-[0.66rem]">
                Apply
              </button>
            </div>
            <div className="mt-2 flex flex-wrap gap-2">
              {["MASS10", "FREESHIP", "STUDENT15"].map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => {
                    setCode(c);
                    applyPromo(c);
                  }}
                  className="rounded-full border border-dashed border-gold-400/35 px-2.5 py-1 text-[0.62rem] font-bold uppercase tracking-[0.14em] text-gold-300/85 transition hover:border-gold-400 hover:text-gold-200"
                >
                  {c}
                </button>
              ))}
            </div>
            {promoCode && (
              <div className="mt-3 flex items-center justify-between gap-2 text-[0.74rem]">
                <span className={promo ? "text-emerald-300" : "text-ember-300"}>{promoMessage}</span>
                <button type="button" onClick={clearPromo} className="text-sand/55 underline-offset-2 hover:text-gold-200 hover:underline">
                  remove
                </button>
              </div>
            )}

            <dl className="mt-5 space-y-2 border-t border-cream/8 pt-5 text-[0.86rem]">
              <div className="flex justify-between text-sand/80">
                <dt>Subtotal ({itemCount} items)</dt>
                <dd>{formatPKR(subtotal)}</dd>
              </div>
              <div className="flex justify-between text-sand/80">
                <dt>{orderType === "delivery" ? `Delivery · ${area.split(" & ")[0]}` : "Service charge"}</dt>
                <dd>{deliveryFee === 0 ? <span className="text-emerald-300">FREE</span> : formatPKR(deliveryFee)}</dd>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-emerald-300">
                  <dt>Discount{promo ? ` (${promo.code})` : ""}</dt>
                  <dd>-{formatPKR(discount)}</dd>
                </div>
              )}
              <div className="flex items-baseline justify-between border-t border-cream/8 pt-3">
                <dt className="font-display text-base text-cream">Total (PKR)</dt>
                <dd className="font-display text-3xl gold-text">{formatPKR(total)}</dd>
              </div>
            </dl>

            {failure && (
              <p className="mt-4 rounded-xl border border-ember-400/35 bg-ember-500/10 px-4 py-3 text-[0.78rem] text-ember-200">
                {failure}
              </p>
            )}

            <button type="submit" disabled={submitting} className="btn btn-gold mt-5 w-full">
              {submitting ? (
                <>
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-noir-950/40 border-t-noir-950" />
                  Placing order…
                </>
              ) : (
                <>
                  <Icon name="check" className="h-4 w-4" strokeWidth={2.4} />
                  Place order · {formatPKR(total)}
                </>
              )}
            </button>

            <a href={whatsappLink(message)} target="_blank" rel="noopener noreferrer" className="btn btn-outline mt-2.5 w-full">
              <Icon name="phone" className="h-4 w-4" />
              Send this order on WhatsApp
            </a>

            <ul className="mt-5 space-y-2 border-t border-cream/8 pt-5 text-[0.74rem] text-sand/60">
              <li className="flex items-start gap-2">
                <Icon name="shield" className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
                No online payment is collected — pay cash on delivery or at the counter.
              </li>
              <li className="flex items-start gap-2">
                <Icon name="clock" className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
                Typical delivery time {SITE.city} city: 25–40 minutes.
              </li>
              <li className="flex items-start gap-2">
                <Icon name="sparkle" className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
                {IS_WHATSAPP_PLACEHOLDER ? (
                  <span>
                    WhatsApp number is the placeholder <code className="text-gold-200">{WHATSAPP_NUMBER}</code>. Owner: set the real
                    number in <code className="text-gold-200">src/lib/site.ts</code>.
                  </span>
                ) : (
                  <span>Orders are confirmed on WhatsApp within minutes.</span>
                )}
              </li>
            </ul>
          </section>
        </Reveal>

        {suggestions.length > 0 && (
          <Reveal delay={100}>
            <section className="mt-6 rounded-[1.75rem] border border-gold-400/12 bg-noir-900/60 p-6">
              <h3 className="text-base text-cream">Complete your order</h3>
              <ul className="mt-4 space-y-3">
                {suggestions.slice(0, 4).map((dish) => (
                  <li key={dish.id} className="flex items-center gap-3">
                    <SmartImage src={dish.image} alt={dish.name} className="h-12 w-12 shrink-0 rounded-lg" sizes="48px" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[0.82rem] text-cream">{dish.name}</p>
                      <p className="text-[0.72rem] text-gold-300/85">{formatPKR(dish.price)}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => add(dish)}
                      className="btn btn-outline shrink-0 !px-3 !py-2 !text-[0.6rem]"
                      aria-label={`Add ${dish.name}`}
                    >
                      {qtyOf(dish.id) > 0 ? `+1 (${qtyOf(dish.id)})` : "Add"}
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          </Reveal>
        )}
      </div>
    </form>
  );
}
