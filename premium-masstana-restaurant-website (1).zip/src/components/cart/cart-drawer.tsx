"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

import { useCart } from "@/components/cart/cart-provider";
import { DELIVERY_ZONES } from "@/lib/data/content";
import { DELIVERY, SITE, formatPKR, whatsappLink } from "@/lib/site";
import { buildOrderMessage } from "@/lib/whatsapp";

import { Icon } from "../ui/icons";
import { SmartImage } from "../ui/smart-image";

export function CartDrawer() {
  const {
    lines,
    itemCount,
    subtotal,
    deliveryFee,
    discount,
    total,
    freeDeliveryGap,
    orderType,
    area,
    promoCode,
    promoMessage,
    promo,
    isOpen,
    increment,
    decrement,
    remove,
    clear,
    setOrderType,
    setArea,
    applyPromo,
    clearPromo,
    closeCart,
  } = useCart();

  const [code, setCode] = useState("");
  const [rendered, setRendered] = useState(false);

  useEffect(() => setRendered(true), []);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeCart();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [closeCart]);

  const progress = Math.min(100, (subtotal / DELIVERY.freeOver) * 100);
  const waMessage = buildOrderMessage({
    lines,
    subtotal,
    deliveryFee,
    discount,
    total,
    itemCount,
    orderType,
    area,
    promoCode: promo ? promo.code : undefined,
  });

  if (!rendered) return null;

  return (
    <div className={`fixed inset-0 z-[90] ${isOpen ? "" : "pointer-events-none"}`} aria-hidden={!isOpen}>
      <button
        type="button"
        tabIndex={isOpen ? 0 : -1}
        onClick={closeCart}
        aria-label="Close cart"
        className={`absolute inset-0 cursor-default bg-noir-950/80 backdrop-blur-sm transition-opacity duration-500 ${
          isOpen ? "opacity-100" : "opacity-0"
        }`}
      />

      <aside
        role="dialog"
        aria-label="Your cart"
        className={`absolute right-0 top-0 flex h-full w-full max-w-[27rem] flex-col border-l border-gold-400/20 bg-noir-900/95 shadow-[0_0_80px_-20px_rgba(217,169,79,0.45)] backdrop-blur-2xl transition-transform duration-500 [transition-timing-function:cubic-bezier(0.22,1,0.36,1)] ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <header className="flex items-center justify-between gap-4 border-b border-gold-400/15 px-6 py-5">
          <div>
            <p className="eyebrow !text-[0.6rem]">Your selection</p>
            <h2 className="mt-1 text-xl text-cream">
              Order Cart <span className="text-gold-300">({itemCount})</span>
            </h2>
          </div>
          <button
            type="button"
            onClick={closeCart}
            className="grid h-10 w-10 place-items-center rounded-full border border-cream/15 text-sand transition hover:border-gold-400/60 hover:text-gold-200 active:scale-90"
            aria-label="Close cart"
          >
            <Icon name="close" className="h-4.5 w-4.5" strokeWidth={2} />
          </button>
        </header>

        {lines.length > 0 && (
          <div className="border-b border-gold-400/10 px-6 py-4">
            {freeDeliveryGap > 0 && orderType === "delivery" ? (
              <p className="text-[0.72rem] text-sand/75">
                Add <span className="font-bold text-gold-200">{formatPKR(freeDeliveryGap)}</span> more for{" "}
                <span className="font-bold text-gold-200">free delivery</span>
              </p>
            ) : (
              <p className="text-[0.72rem] font-semibold text-emerald-300">
                {orderType === "delivery" ? "Free delivery unlocked on this order" : "No delivery fee for this order type"}
              </p>
            )}
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-cream/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-gold-400 to-ember-500 transition-[width] duration-700"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto px-6 py-5">
          {lines.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center gap-4 text-center">
              <span className="grid h-20 w-20 place-items-center rounded-full border border-gold-400/25 bg-gold-400/5">
                <Icon name="bag" className="h-8 w-8 text-gold-300/70" />
              </span>
              <div>
                <h3 className="text-lg text-cream">Your cart is empty</h3>
                <p className="mt-1 max-w-xs text-[0.83rem] text-sand/65">
                  Add biryani, BBQ, burgers or a family deal — everything on our menu is ready to order.
                </p>
              </div>
              <Link href="/menu" onClick={closeCart} className="btn btn-gold !text-[0.72rem]">
                Browse the menu
                <Icon name="arrowRight" className="h-4 w-4" />
              </Link>
            </div>
          ) : (
            <ul className="space-y-4">
              {lines.map((line) => (
                <li key={line.id} className="fade-in flex gap-3 rounded-2xl border border-cream/8 bg-cream/[0.02] p-3">
                  <SmartImage
                    src={line.image}
                    alt={line.name}
                    className="h-20 w-20 shrink-0 rounded-xl"
                    sizes="80px"
                  />
                  <div className="flex flex-1 flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-[0.9rem] leading-snug text-cream">{line.name}</h4>
                      <button
                        type="button"
                        onClick={() => remove(line.id)}
                        className="shrink-0 text-sand/50 transition hover:text-ember-400"
                        aria-label={`Remove ${line.name}`}
                      >
                        <Icon name="trash" className="h-4 w-4" />
                      </button>
                    </div>
                    <span className="text-[0.7rem] text-sand/55">{formatPKR(line.price)} each</span>
                    <div className="mt-auto flex items-center justify-between gap-2 pt-2">
                      <div className="flex items-center gap-1 rounded-full border border-gold-400/35 bg-gold-400/8 p-0.5">
                        <button
                          type="button"
                          onClick={() => decrement(line.id)}
                          className="grid h-7 w-7 place-items-center rounded-full text-gold-200 transition hover:bg-gold-400/25 active:scale-90"
                          aria-label={`Decrease ${line.name}`}
                        >
                          <Icon name="minus" className="h-3.5 w-3.5" strokeWidth={2.4} />
                        </button>
                        <span className="min-w-5 text-center text-sm font-bold text-gold-100">{line.qty}</span>
                        <button
                          type="button"
                          onClick={() => increment(line.id)}
                          className="grid h-7 w-7 place-items-center rounded-full text-gold-200 transition hover:bg-gold-400/25 active:scale-90"
                          aria-label={`Increase ${line.name}`}
                        >
                          <Icon name="plus" className="h-3.5 w-3.5" strokeWidth={2.4} />
                        </button>
                      </div>
                      <span className="font-display text-base text-gold-200">{formatPKR(line.price * line.qty)}</span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {lines.length > 0 && (
          <footer className="border-t border-gold-400/15 bg-noir-950/60 px-6 py-5">
            <div className="flex gap-2">
              {(["delivery", "pickup", "dine-in"] as const).map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setOrderType(type)}
                  data-active={orderType === type}
                  className="chip flex-1 !px-2 justify-center !text-[0.62rem]"
                >
                  {type === "delivery" ? "Delivery" : type === "pickup" ? "Pickup" : "Dine-in"}
                </button>
              ))}
            </div>

            {orderType === "delivery" && (
              <select
                className="field mt-3 !py-2.5 text-[0.82rem]"
                value={area}
                onChange={(e) => setArea(e.target.value)}
                aria-label="Delivery area"
              >
                {DELIVERY_ZONES.map((zone) => (
                  <option key={zone.area} value={zone.area}>
                    {zone.area} — {zone.fee === 0 ? "on request" : formatPKR(zone.fee)}
                  </option>
                ))}
              </select>
            )}

            <div className="mt-3 flex gap-2">
              <input
                className="field !py-2.5 text-[0.8rem] uppercase tracking-wider"
                placeholder="Promo code (MASS10)"
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                onKeyDown={(e) => {
                  if (e.key === "Enter") applyPromo(code);
                }}
                aria-label="Promo code"
              />
              <button type="button" onClick={() => applyPromo(code)} className="btn btn-outline !px-4 !py-2.5 !text-[0.68rem]">
                Apply
              </button>
            </div>
            {promoCode && (
              <div className="mt-2 flex items-center justify-between gap-2 text-[0.72rem]">
                <span className={promo ? "text-emerald-300" : "text-ember-300"}>{promoMessage}</span>
                <button type="button" onClick={clearPromo} className="text-sand/60 underline-offset-2 hover:text-gold-200 hover:underline">
                  remove
                </button>
              </div>
            )}

            <dl className="mt-4 space-y-1.5 border-t border-cream/8 pt-4 text-[0.84rem]">
              <div className="flex justify-between text-sand/80">
                <dt>Subtotal</dt>
                <dd>{formatPKR(subtotal)}</dd>
              </div>
              <div className="flex justify-between text-sand/80">
                <dt>{orderType === "delivery" ? `Delivery · ${area.split(" ")[0]}` : "Service"}</dt>
                <dd>{deliveryFee === 0 ? <span className="text-emerald-300">FREE</span> : formatPKR(deliveryFee)}</dd>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-emerald-300">
                  <dt>Discount{promo ? ` (${promo.code})` : ""}</dt>
                  <dd>-{formatPKR(discount)}</dd>
                </div>
              )}
              <div className="flex items-baseline justify-between pt-2 text-cream">
                <dt className="font-display text-base">Total</dt>
                <dd className="font-display text-2xl gold-text">{formatPKR(total)}</dd>
              </div>
            </dl>

            <div className="mt-4 grid gap-2">
              <Link href="/order" onClick={closeCart} className="btn btn-gold w-full !text-[0.74rem]">
                <Icon name="receipt" className="h-4 w-4" />
                Checkout now
              </Link>
              <div className="grid grid-cols-2 gap-2">
                <a
                  href={whatsappLink(waMessage)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-outline w-full !px-3 !py-2.5 !text-[0.66rem]"
                >
                  <Icon name="phone" className="h-4 w-4" />
                  WhatsApp
                </a>
                <button type="button" onClick={clear} className="btn btn-ghost w-full !px-3 !py-2.5 !text-[0.66rem]">
                  <Icon name="trash" className="h-4 w-4" />
                  Clear
                </button>
              </div>
            </div>
            <p className="mt-3 text-center text-[0.62rem] leading-relaxed text-sand/45">
              {SITE.addressLine} · Owner {SITE.owner}
            </p>
          </footer>
        )}
      </aside>
    </div>
  );
}

export function CartToast() {
  const { toast } = useCart();
  if (!toast) return null;
  return (
    <div className="pointer-events-none fixed bottom-6 left-1/2 z-[95] -translate-x-1/2 px-4">
      <div className="animate-pop glass-gold flex items-center gap-3 rounded-full px-5 py-3 shadow-[0_18px_44px_-18px_rgba(217,169,79,0.8)]">
        <span className="grid h-7 w-7 place-items-center rounded-full bg-gradient-to-br from-gold-300 to-ember-500 text-noir-950">
          <Icon name="check" className="h-4 w-4" strokeWidth={2.6} />
        </span>
        <span className="text-[0.8rem] font-semibold text-cream">{toast.text}</span>
      </div>
    </div>
  );
}
