"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

import { DELIVERY_ZONES, evaluatePromo, type Offer } from "@/lib/data/content";
import type { Dish } from "@/lib/data/menu";
import { DELIVERY } from "@/lib/site";
import type { CartLine } from "@/lib/types";

type OrderType = "delivery" | "pickup" | "dine-in";

type Persisted = {
  lines: CartLine[];
  promoCode: string;
  orderType: OrderType;
  area: string;
};

type CartContextValue = {
  lines: CartLine[];
  itemCount: number;
  subtotal: number;
  deliveryFee: number;
  discount: number;
  total: number;
  freeDeliveryGap: number;
  orderType: OrderType;
  area: string;
  promoCode: string;
  promo: Offer | null;
  promoMessage: string;
  isOpen: boolean;
  toast: { id: number; text: string } | null;
  qtyOf: (id: string) => number;
  add: (dish: Dish | CartLine, qty?: number) => void;
  increment: (id: string) => void;
  decrement: (id: string) => void;
  remove: (id: string) => void;
  clear: () => void;
  setQty: (id: string, qty: number) => void;
  setOrderType: (type: OrderType) => void;
  setArea: (area: string) => void;
  applyPromo: (code: string) => { ok: boolean; message: string };
  clearPromo: () => void;
  openCart: () => void;
  closeCart: () => void;
};

const STORAGE_KEY = "masstana-cart-v1";
const CartContext = createContext<CartContextValue | null>(null);

function zoneFee(area: string): number {
  const zone = DELIVERY_ZONES.find((z) => z.area === area);
  return zone ? zone.fee : DELIVERY.baseFee;
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [promoCode, setPromoCode] = useState("");
  const [orderType, setOrderType] = useState<OrderType>("delivery");
  const [area, setArea] = useState<string>(DELIVERY_ZONES[0].area);
  const [isOpen, setIsOpen] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [toast, setToast] = useState<{ id: number; text: string } | null>(null);

  /* --- hydrate from localStorage --- */
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<Persisted>;
        if (Array.isArray(parsed.lines)) setLines(parsed.lines.filter((l) => l && l.id && l.qty > 0));
        if (typeof parsed.promoCode === "string") setPromoCode(parsed.promoCode);
        if (parsed.orderType) setOrderType(parsed.orderType);
        if (parsed.area) setArea(parsed.area);
      }
    } catch {
      /* corrupted storage — start fresh */
    }
    setHydrated(true);
  }, []);

  /* --- persist --- */
  useEffect(() => {
    if (!hydrated) return;
    try {
      const payload: Persisted = { lines, promoCode, orderType, area };
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch {
      /* storage full or unavailable */
    }
  }, [lines, promoCode, orderType, area, hydrated]);

  /* --- toast auto dismiss --- */
  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 2600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  /* --- lock body scroll while drawer open --- */
  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  const subtotal = useMemo(() => lines.reduce((sum, l) => sum + l.price * l.qty, 0), [lines]);
  const itemCount = useMemo(() => lines.reduce((sum, l) => sum + l.qty, 0), [lines]);

  const rawDeliveryFee = orderType === "delivery" ? zoneFee(area) : 0;
  const deliveryFee = subtotal >= DELIVERY.freeOver ? 0 : rawDeliveryFee;

  const promoResult = useMemo(
    () => evaluatePromo(promoCode, subtotal, deliveryFee),
    [promoCode, subtotal, deliveryFee],
  );
  const discount = promoResult.ok ? promoResult.discount : 0;
  const total = Math.max(0, subtotal + deliveryFee - discount);
  const freeDeliveryGap = Math.max(0, DELIVERY.freeOver - subtotal);

  const pushToast = useCallback((text: string) => setToast({ id: Date.now(), text }), []);

  const add = useCallback(
    (dish: Dish | CartLine, qty = 1) => {
      const line: CartLine = {
        id: dish.id,
        name: dish.name,
        price: dish.price,
        qty,
        image: dish.image,
        category: dish.category,
      };
      setLines((prev) => {
        const existing = prev.find((l) => l.id === line.id);
        if (existing) {
          return prev.map((l) => (l.id === line.id ? { ...l, qty: Math.min(99, l.qty + qty) } : l));
        }
        return [...prev, line];
      });
      pushToast(`${line.name} added to cart`);
    },
    [pushToast],
  );

  const increment = useCallback((id: string) => {
    setLines((prev) => prev.map((l) => (l.id === id ? { ...l, qty: Math.min(99, l.qty + 1) } : l)));
  }, []);

  const decrement = useCallback((id: string) => {
    setLines((prev) =>
      prev.flatMap((l) => (l.id === id ? (l.qty > 1 ? [{ ...l, qty: l.qty - 1 }] : []) : [l])),
    );
  }, []);

  const remove = useCallback((id: string) => {
    setLines((prev) => prev.filter((l) => l.id !== id));
  }, []);

  const setQty = useCallback((id: string, qty: number) => {
    setLines((prev) =>
      qty <= 0 ? prev.filter((l) => l.id !== id) : prev.map((l) => (l.id === id ? { ...l, qty: Math.min(99, qty) } : l)),
    );
  }, []);

  const clear = useCallback(() => {
    setLines([]);
    setPromoCode("");
  }, []);

  const applyPromo = useCallback(
    (code: string) => {
      const result = evaluatePromo(code, subtotal, deliveryFee);
      if (result.ok) {
        setPromoCode(code.trim().toUpperCase());
        pushToast(result.message);
        return { ok: true, message: result.message };
      }
      pushToast(result.message);
      return { ok: false, message: result.message };
    },
    [subtotal, deliveryFee, pushToast],
  );

  const qtyOf = useCallback((id: string) => lines.find((l) => l.id === id)?.qty ?? 0, [lines]);

  const value: CartContextValue = {
    lines,
    itemCount,
    subtotal,
    deliveryFee,
    discount,
    total,
    freeDeliveryGap,
    orderType,
    area,
    promoCode,
    promo: promoResult.ok ? (promoResult.offer ?? null) : null,
    promoMessage: promoCode ? promoResult.message : "",
    isOpen,
    toast,
    qtyOf,
    add,
    increment,
    decrement,
    remove,
    clear,
    setQty,
    setOrderType,
    setArea,
    applyPromo,
    clearPromo: () => setPromoCode(""),
    openCart: () => setIsOpen(true),
    closeCart: () => setIsOpen(false),
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used inside <CartProvider>");
  return ctx;
}
