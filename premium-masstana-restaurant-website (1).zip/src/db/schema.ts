import { boolean, integer, jsonb, pgTable, real, serial, text, timestamp } from "drizzle-orm/pg-core";

/** Restaurant menu catalogue — seeded from src/lib/data/menu.ts on first run. */
export const menuItems = pgTable("menu_items", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(),
  oldPrice: integer("old_price"),
  image: text("image").notNull(),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  rating: real("rating").notNull().default(4.5),
  serves: text("serves"),
  popular: boolean("popular").notNull().default(false),
  available: boolean("available").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

/** Orders created from the online ordering page. */
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  customerName: text("customer_name").notNull(),
  phone: text("phone").notNull(),
  address: text("address"),
  area: text("area"),
  orderType: text("order_type").notNull().default("delivery"),
  notes: text("notes"),
  paymentMethod: text("payment_method").notNull().default("cash"),
  items: jsonb("items").$type<
    { id: string; name: string; price: number; qty: number; image?: string; category?: string }[]
  >().notNull(),
  itemCount: integer("item_count").notNull().default(0),
  subtotal: integer("subtotal").notNull(),
  deliveryFee: integer("delivery_fee").notNull().default(0),
  discount: integer("discount").notNull().default(0),
  total: integer("total").notNull(),
  promoCode: text("promo_code"),
  status: text("status").notNull().default("received"),
  channel: text("channel").notNull().default("website"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** Guest reviews submitted through the Customer Reviews page. */
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  city: text("city"),
  rating: integer("rating").notNull().default(5),
  title: text("title"),
  body: text("body").notNull(),
  dish: text("dish"),
  source: text("source").notNull().default("Website"),
  approved: boolean("approved").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** Messages from the contact form. */
export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  subject: text("subject"),
  message: text("message").notNull(),
  kind: text("kind").notNull().default("general"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type MenuItemRow = typeof menuItems.$inferSelect;
export type OrderRow = typeof orders.$inferSelect;
export type ReviewRow = typeof reviews.$inferSelect;
export type ContactRow = typeof contactMessages.$inferSelect;
