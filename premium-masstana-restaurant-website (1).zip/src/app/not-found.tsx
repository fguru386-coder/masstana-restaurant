import Link from "next/link";

import { Icon, Logo } from "@/components/ui/icons";
import { SmartImage } from "@/components/ui/smart-image";
import { IMG } from "@/lib/data/images";
import { SITE } from "@/lib/site";

const SUGGESTIONS = [
  { href: "/menu", label: "Full menu", icon: "utensils" },
  { href: "/order", label: "Order online", icon: "bag" },
  { href: "/offers", label: "Today's offers", icon: "tag" },
  { href: "/gallery", label: "Gallery", icon: "sparkle" },
  { href: "/contact", label: "Contact us", icon: "mail" },
];

export default function NotFound() {
  return (
    <section className="relative flex min-h-[80vh] items-center overflow-hidden px-5 py-24 sm:px-8">
      <div className="absolute inset-0 -z-10">
        <SmartImage src={IMG.elegantDark} alt="" className="h-full w-full" imgClassName="opacity-25" />
        <div className="absolute inset-0 bg-gradient-to-b from-noir-950 via-noir-950/85 to-noir-950" />
      </div>

      <div className="page-enter mx-auto w-full max-w-2xl text-center">
        <span className="mx-auto grid h-16 w-16 place-items-center">
          <Logo className="h-16 w-16" />
        </span>
        <p className="eyebrow mt-6">Error 404</p>
        <h1 className="mt-3 font-display text-6xl gold-text sm:text-8xl">Lost</h1>
        <p className="mt-4 text-[0.95rem] leading-relaxed text-sand/75">
          This page isn't on the menu. The biryani, however, definitely is — {SITE.addressLine}.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-2.5">
          {SUGGESTIONS.map((item) => (
            <Link key={item.href} href={item.href} className="chip">
              <Icon name={item.icon} className="h-3.5 w-3.5" />
              {item.label}
            </Link>
          ))}
        </div>
        <div className="mt-9 flex flex-wrap justify-center gap-3">
          <Link href="/" className="btn btn-gold">
            <Icon name="arrowLeft" className="h-4 w-4" />
            Back to home
          </Link>
          <a href={SITE.phoneHref} className="btn btn-outline">
            <Icon name="phone" className="h-4 w-4" />
            Call the restaurant
          </a>
        </div>
      </div>
    </section>
  );
}
