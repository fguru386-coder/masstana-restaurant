import type { Metadata } from "next";
import Link from "next/link";

import { PageHero } from "@/components/layout/page-hero";
import { Icon } from "@/components/ui/icons";
import { Reveal } from "@/components/ui/reveal";
import { Badge, Section, SectionHeading } from "@/components/ui/section";
import { SmartImage } from "@/components/ui/smart-image";
import { DELIVERY_PROMISES, DELIVERY_STEPS, DELIVERY_ZONES } from "@/lib/data/content";
import { IMG, LOCAL } from "@/lib/data/images";
import { DELIVERY, SITE, formatPKR, whatsappLink } from "@/lib/site";

export const metadata: Metadata = {
  title: "Home Delivery — Areas, Charges & Order Instructions",
  description:
    "MASSTANA RESTAURANT home delivery across Sargodha: zone-wise delivery charges from Rs 120, 25–40 minute average delivery, free delivery above Rs 3,000, insulated packing and late-night delivery till 2 AM.",
  alternates: { canonical: "/delivery" },
};

const PACKAGING = [
  { icon: "shield", title: "Sealed & tamper-proof", body: "Every box leaves the pass with a sticker seal so you know nothing was opened." },
  { icon: "flame", title: "Thermal insulation", body: "Karahi, handi and BBQ travel in insulated bags that hold heat for 45 minutes." },
  { icon: "dessert", title: "Cold stays cold", body: "Kulfi, falooda, shakes and cakes ride in a separate chilled compartment." },
  { icon: "utensils", title: "Gravy, naan & cutlery", body: "Gravy packed separately, naan wrapped in cloth, cutlery and napkins included." },
];

const INSTRUCTIONS = [
  "Add your dishes to the cart on the Order Online page, then choose Home Delivery.",
  "Select your exact zone — the delivery fee and estimated time update instantly.",
  "Write the full address: house number, street, mohalla, landmark and floor if applicable.",
  "Add cooking notes (mild spice, no onion, extra naan) — the kitchen reads every note.",
  "Keep your phone nearby: our rider calls if the location is hard to find.",
  "Pay cash on delivery, or use EasyPaisa / JazzCash for bulk and event orders.",
  "Minimum order value is Rs 300. Orders above Rs 3,000 deliver free automatically.",
  "Something wrong? Call within 30 minutes with your order code and we replace or refund it.",
];

export default function DeliveryPage() {
  return (
    <>
      <PageHero
        eyebrow="Home delivery"
        title="Hot food across"
        highlight="Sargodha, daily"
        description={`Our own riders cover an ${DELIVERY.radiusKm} km radius from ${SITE.addressLine}. Insulated bags, sealed boxes and an average drop time of ${DELIVERY.prepTime} minutes — from 7 AM until 2 AM.`}
        image={LOCAL.delivery}
        crumb="Home Delivery"
      />

      <Section className="pt-10">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {DELIVERY_PROMISES.map((promise, index) => (
            <Reveal key={promise.title} delay={index * 70}>
              <div className="glass tilt-card flex h-full items-start gap-4 rounded-2xl p-6">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-gold-400/25 bg-gold-400/8 text-gold-300">
                  <Icon name={promise.icon} className="h-5 w-5" />
                </span>
                <span>
                  <span className="block text-[0.98rem] font-bold text-cream">{promise.title}</span>
                  <span className="mt-1 block text-[0.8rem] text-sand/65">{promise.body}</span>
                </span>
              </div>
            </Reveal>
          ))}
        </div>
      </Section>

      {/* --------- Zones --------- */}
      <Section className="pt-4">
        <SectionHeading
          eyebrow="Delivery areas & charges"
          title="Zone-wise fees,"
          highlight="no surprises at the door"
          description={`Free delivery on every order above ${formatPKR(DELIVERY.freeOver)}. Use code FREESHIP above ${formatPKR(1500)} to waive the fee as well.`}
        />

        <Reveal>
          <div className="mt-12 overflow-hidden rounded-[1.5rem] border border-gold-400/15">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px] text-left">
                <thead className="bg-gradient-to-r from-gold-400/18 to-ember-500/12 text-[0.66rem] uppercase tracking-[0.18em] text-gold-200">
                  <tr>
                    <th className="px-6 py-4 font-bold">Area / zone</th>
                    <th className="px-6 py-4 font-bold">Distance</th>
                    <th className="px-6 py-4 font-bold">Estimated time</th>
                    <th className="px-6 py-4 text-right font-bold">Delivery fee</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-cream/8 bg-noir-950/60 text-[0.86rem]">
                  {DELIVERY_ZONES.map((zone) => (
                    <tr key={zone.area} className="group transition-colors hover:bg-gold-400/[0.06]">
                      <td className="px-6 py-4 text-cream">
                        <span className="flex items-center gap-2.5">
                          <Icon name="pin" className="h-4 w-4 shrink-0 text-gold-400/70 transition group-hover:text-gold-300" />
                          {zone.area}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sand/70">{zone.distance}</td>
                      <td className="px-6 py-4 text-sand/70">{zone.eta}</td>
                      <td className="px-6 py-4 text-right font-display text-lg text-gold-200">
                        {zone.fee === 0 ? <span className="text-sm text-sand/60">On request</span> : formatPKR(zone.fee)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-gold-400/15 bg-noir-900/70 px-6 py-4 text-[0.76rem] text-sand/60">
              <span>Base fee {formatPKR(DELIVERY.baseFee)} · Free above {formatPKR(DELIVERY.freeOver)} · Minimum order {formatPKR(DELIVERY.minOrder)}</span>
              <a
                href={whatsappLink(`Assalam-o-Alaikum ${SITE.name}! Do you deliver to my area?`)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-gold-300 underline-offset-4 hover:underline"
              >
                <Icon name="phone" className="h-3.5 w-3.5" />
                Not sure if we cover your area? Ask us
              </a>
            </div>
          </div>
        </Reveal>
      </Section>

      {/* --------- Steps --------- */}
      <Section className="border-y border-gold-400/10 bg-noir-900/40">
        <SectionHeading eyebrow="Order instructions" title="How delivery" highlight="works here" />
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
          {DELIVERY_STEPS.map((step, index) => (
            <Reveal key={step.step} delay={index * 70} className="h-full">
              <div className="tilt-card flex h-full flex-col gap-3 rounded-2xl border border-gold-400/12 bg-noir-950/60 p-6">
                <span className="font-display text-3xl text-gold-400/40">{step.step}</span>
                <h3 className="text-[1.02rem] text-cream">{step.title}</h3>
                <p className="text-[0.82rem] leading-relaxed text-sand/65">{step.body}</p>
              </div>
            </Reveal>
          ))}
        </div>

        <div className="mt-12 grid gap-8 lg:grid-cols-2">
          <Reveal>
            <div className="glass rounded-[1.5rem] p-7">
              <h3 className="text-xl text-cream">Before you order — 8 quick points</h3>
              <ol className="mt-5 space-y-3">
                {INSTRUCTIONS.map((line, index) => (
                  <li key={line} className="flex gap-3 text-[0.86rem] leading-relaxed text-sand/75">
                    <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full border border-gold-400/35 text-[0.66rem] font-bold text-gold-300">
                      {index + 1}
                    </span>
                    {line}
                  </li>
                ))}
              </ol>
              <div className="mt-6 flex flex-wrap gap-3">
                <Link href="/order" className="btn btn-gold">
                  <Icon name="bike" className="h-4 w-4" />
                  Order for delivery
                </Link>
                <Link href="/menu" className="btn btn-outline">
                  Browse menu
                </Link>
              </div>
            </div>
          </Reveal>

          <Reveal delay={90}>
            <div className="overflow-hidden rounded-[1.5rem] border border-gold-400/15">
              <SmartImage src={IMG.chefFlame} alt="Chef plating an order for delivery" className="aspect-[4/3] w-full" sizes="(max-width:1024px) 92vw, 46vw" />
              <div className="grid gap-4 bg-noir-950/70 p-7 sm:grid-cols-2">
                {PACKAGING.map((item) => (
                  <div key={item.title} className="flex gap-3">
                    <Icon name={item.icon} className="mt-0.5 h-5 w-5 shrink-0 text-gold-300" />
                    <span>
                      <span className="block text-[0.9rem] font-bold text-cream">{item.title}</span>
                      <span className="mt-1 block text-[0.78rem] leading-relaxed text-sand/65">{item.body}</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </Section>

      {/* --------- Map --------- */}
      <Section>
        <div className="grid items-start gap-8 lg:grid-cols-[1fr_1.2fr]">
          <div>
            <SectionHeading
              align="left"
              eyebrow="Coverage map"
              title="Find us at"
              highlight="49 Tail, Sargodha"
              description="We dispatch from a single kitchen at 49 Tail, which keeps every order in the same radius and every rider accountable."
            />
            <div className="mt-7 space-y-4">
              <div className="flex items-start gap-3 rounded-2xl border border-cream/8 bg-cream/[0.02] p-5">
                <Icon name="pin" className="mt-0.5 h-5 w-5 shrink-0 text-gold-300" />
                <div>
                  <p className="text-[0.95rem] font-bold text-cream">{SITE.name}</p>
                  <p className="mt-0.5 text-[0.84rem] text-sand/70">{SITE.addressLine}</p>
                  <p className="mt-0.5 text-[0.8rem] text-sand/55">Owner: {SITE.owner}</p>
                </div>
              </div>
              <div className="flex items-start gap-3 rounded-2xl border border-cream/8 bg-cream/[0.02] p-5">
                <Icon name="clock" className="mt-0.5 h-5 w-5 shrink-0 text-gold-300" />
                <div>
                  <p className="text-[0.95rem] font-bold text-cream">Delivery timings</p>
                  <p className="mt-0.5 text-[0.84rem] text-sand/70">Mon – Thu · 7:00 AM – 1:00 AM</p>
                  <p className="text-[0.84rem] text-sand/70">Fri – Sun · 7:00 AM – 2:30 AM</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-3">
                <a href={SITE.mapLinkUrl} target="_blank" rel="noopener noreferrer" className="btn btn-gold">
                  <Icon name="map" className="h-4 w-4" />
                  Open in Google Maps
                </a>
                <a href={SITE.phoneHref} className="btn btn-outline">
                  <Icon name="phone" className="h-4 w-4" />
                  {SITE.phoneDisplay}
                </a>
              </div>
            </div>
          </div>

          <Reveal delay={80}>
            <div className="relative overflow-hidden rounded-[1.75rem] border border-gold-400/20">
              <iframe
                title="Map placeholder for MASSTANA RESTAURANT, 49 Tail Sargodha"
                src={SITE.mapEmbedUrl}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="h-[420px] w-full grayscale-[35%] contrast-[1.05] sm:h-[520px]"
                style={{ border: 0, filter: "invert(0.9) hue-rotate(180deg) saturate(0.7)" }}
              />
              <div className="pointer-events-none absolute inset-x-4 top-4 flex flex-wrap items-center gap-2">
                <Badge tone="ember">
                  <Icon name="sparkle" className="h-3 w-3" strokeWidth={2.2} />
                  Placeholder pin
                </Badge>
                <span className="rounded-full border border-gold-400/30 bg-noir-950/80 px-3 py-1 text-[0.64rem] text-sand/75 backdrop-blur">
                  Exact location will be marked once confirmed by the owner
                </span>
              </div>
            </div>
          </Reveal>
        </div>
      </Section>
    </>
  );
}
