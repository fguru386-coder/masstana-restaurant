import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";

import { CartDrawer, CartToast } from "@/components/cart/cart-drawer";
import { CartProvider } from "@/components/cart/cart-provider";
import { Footer } from "@/components/layout/footer";
import { Navbar } from "@/components/layout/navbar";
import { BackToTop, PageTransition, Preloader, ScrollProgress } from "@/components/layout/site-chrome";
import { SITE, IS_WHATSAPP_PLACEHOLDER, WHATSAPP_NUMBER } from "@/lib/site";

import "./globals.css";

const url = (path = "") => `https://masstanarestaurant.pk${path}`;

export const metadata: Metadata = {
  metadataBase: new URL("https://masstanarestaurant.pk"),
  title: {
    default: `${SITE.name} | Multi-Cuisine Restaurant in Sargodha — Biryani, BBQ, Chinese & Fast Food`,
    template: `%s | ${SITE.name} Sargodha`,
  },
  description:
    "MASSTANA RESTAURANT, 49 Tail Sargodha — dum biryani, charcoal BBQ, karahi, nihari, Chinese, continental, pizza, breakfast, desserts & deals. Dine-in, takeaway and online home delivery in PKR. Owner: Faiz Guru.",
  keywords: [
    "Masstana Restaurant",
    "restaurant in Sargodha",
    "49 Tail Sargodha food",
    "best biryani Sargodha",
    "BBQ platter Sargodha",
    "online food delivery Sargodha",
    "Chinese food Sargodha",
    "halwa puri breakfast Sargodha",
    "family deals Sargodha",
    "Faiz Guru",
  ],
  authors: [{ name: SITE.owner }],
  creator: SITE.name,
  openGraph: {
    type: "website",
    locale: "en_PK",
    url: url(),
    siteName: SITE.name,
    title: `${SITE.name} — Multi-Cuisine Restaurant, 49 Tail Sargodha`,
    description:
      "Dum biryani, charcoal BBQ, wok-fresh Chinese, continental grills, desi nashta and desserts. Order online for dine-in, takeaway or home delivery in Sargodha.",
    images: [{ url: "/images/hero-feast.jpg", width: 1200, height: 800, alt: `${SITE.name} signature feast` }],
  },
  twitter: {
    card: "summary_large_image",
    title: `${SITE.name} — Sargodha`,
    description: "Premium multi-cuisine restaurant: BBQ, biryani, Chinese, continental & desserts. Order online.",
    images: ["/images/hero-feast.jpg"],
  },
  robots: { index: true, follow: true },
  alternates: { canonical: url() },
};

export const viewport: Viewport = {
  themeColor: "#06050a",
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Restaurant",
  name: SITE.name,
  description:
    "Multi-cuisine restaurant in Sargodha serving Pakistani BBQ, biryani, Chinese, continental, breakfast, desserts and family deals with dine-in, takeaway and home delivery.",
  image: url("/images/hero-feast.jpg"),
  url: url(),
  telephone: SITE.phoneDisplay,
  email: SITE.email,
  servesCuisine: ["Pakistani", "BBQ", "Chinese", "Continental", "Fast Food", "Desserts"],
  priceRange: "Rs 120 - Rs 5,499",
  currenciesAccepted: "PKR",
  paymentAccepted: "Cash, EasyPaisa, JazzCash, Bank Transfer",
  founder: { "@type": "Person", name: SITE.owner },
  address: {
    "@type": "PostalAddress",
    streetAddress: "49 Tail",
    addressLocality: "Sargodha",
    addressRegion: "Punjab",
    addressCountry: "PK",
  },
  openingHoursSpecification: [
    {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday"],
      opens: "07:00",
      closes: "01:00",
    },
    {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: ["Friday", "Saturday", "Sunday"],
      opens: "07:00",
      closes: "02:30",
    },
  ],
  acceptsReservations: "True",
  hasMenu: url("/menu"),
  potentialAction: {
    "@type": "OrderAction",
    target: { "@type": "EntryPoint", urlTemplate: url("/order"), actionPlatform: "https://schema.org/WebPlatform" },
    deliveryMethod: ["http://purl.org/goodrelations/v1#DeliveryModeOwnFleet", "http://purl.org/goodrelations/v1#DeliveryModePickUp"],
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Marcellus&family=Manrope:wght@300;400;500;600;700;800&family=Parisienne&display=swap"
          rel="stylesheet"
        />
        <link rel="icon" href="/favicon.svg" type="image/svg+xml" />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      </head>
      <body className="ambient-bg grain min-h-screen bg-noir-950 font-body text-cream antialiased">
        <CartProvider>
          <Preloader />
          <ScrollProgress />
          <a
            href="#main"
            className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[120] focus:rounded-full focus:bg-gold-400 focus:px-4 focus:py-2 focus:text-noir-950"
          >
            Skip to content
          </a>
          <Navbar />
          <main id="main">
            <PageTransition>{children}</PageTransition>
          </main>
          <Footer />
          <CartDrawer />
          <CartToast />
          <BackToTop />
          {IS_WHATSAPP_PLACEHOLDER && (
            <div className="sr-only">
              WhatsApp ordering uses the placeholder number {WHATSAPP_NUMBER}; update it in src/lib/site.ts.
            </div>
          )}
        </CartProvider>
      </body>
    </html>
  );
}
