import type { Metadata } from "next";
import Link from "next/link";

import { ContactForm } from "@/components/contact/contact-form";
import { PageHero } from "@/components/layout/page-hero";
import { BrandIcon, Icon } from "@/components/ui/icons";
import { Reveal } from "@/components/ui/reveal";
import { Badge, Section, SectionHeading } from "@/components/ui/section";
import { IMG } from "@/lib/data/images";
import { SITE, whatsappLink } from "@/lib/site";

export const metadata: Metadata = {
  title: "Contact Us — Address, Phone, Hours & Reservations",
  description:
    "Contact MASSTANA RESTAURANT: 49 Tail, Sargodha, Pakistan. Owner Faiz Guru. Table reservations, catering quotations, feedback and complaints. Opening hours 7 AM to 2 AM daily.",
  alternates: { canonical: "/contact" },
};

const NEXT_STEPS = [
  { icon: "clock", title: "We reply fast", body: "Messages sent during opening hours are answered within 1–3 hours." },
  { icon: "phone", title: "Urgent orders", body: "For same-day orders or delivery queries, call or WhatsApp — it is always faster." },
  { icon: "chef", title: "Catering quotes", body: "Share headcount, date and menu; a quotation reaches you within 24 hours." },
];

export default function ContactPage() {
  return (
    <>
      <PageHero
        eyebrow="Contact us"
        title="Talk to the"
        highlight="Masstana family"
        description="Reservations, catering, feedback or a complaint — reach us by phone, WhatsApp, email or the form below. We are at 49 Tail, Sargodha, every day of the week."
        image={IMG.cafeLamps}
        crumb="Contact Us"
      />

      <Section className="pt-10">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {[
            {
              icon: "pin",
              title: "Visit us",
              lines: [SITE.name, SITE.addressLine, `Owner: ${SITE.owner}`],
              href: SITE.mapLinkUrl,
              cta: "Open in Maps",
              external: true,
            },
            {
              icon: "phone",
              title: "Call the restaurant",
              lines: [SITE.phoneDisplay, SITE.phoneAltDisplay, "Placeholder lines"],
              href: SITE.phoneHref,
              cta: "Call now",
              external: false,
            },
            {
              icon: "mail",
              title: "Email us",
              lines: [SITE.email, "Reservations & catering", "Replies within 24 hours"],
              href: `mailto:${SITE.email}`,
              cta: "Send email",
              external: false,
            },
            {
              icon: "clock",
              title: "Opening hours",
              lines: ["Mon – Thu · 7 AM – 1 AM", "Fri – Sun · 7 AM – 2:30 AM", "BBQ grill from 5 PM"],
              href: "/delivery",
              cta: "Delivery timings",
              external: false,
            },
          ].map((card, index) => (
            <Reveal key={card.title} delay={index * 80} className="h-full">
              <div className="tilt-card flex h-full flex-col gap-3 rounded-[1.5rem] border border-gold-400/12 bg-gradient-to-br from-noir-800/70 to-noir-950/85 p-6">
                <span className="grid h-11 w-11 place-items-center rounded-xl border border-gold-400/25 bg-gold-400/8 text-gold-300">
                  <Icon name={card.icon} className="h-5 w-5" />
                </span>
                <h2 className="text-[1.05rem] text-cream">{card.title}</h2>
                <ul className="flex-1 space-y-1 text-[0.82rem] text-sand/70">
                  {card.lines.map((line) => (
                    <li key={line}>{line}</li>
                  ))}
                </ul>
                {card.external ? (
                  <a
                    href={card.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-[0.72rem] font-bold uppercase tracking-[0.16em] text-gold-300 transition hover:text-gold-200"
                  >
                    {card.cta}
                    <Icon name="arrowRight" className="h-3.5 w-3.5" />
                  </a>
                ) : (
                  <Link
                    href={card.href}
                    className="inline-flex items-center gap-2 text-[0.72rem] font-bold uppercase tracking-[0.16em] text-gold-300 transition hover:text-gold-200"
                  >
                    {card.cta}
                    <Icon name="arrowRight" className="h-3.5 w-3.5" />
                  </Link>
                )}
              </div>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section className="pt-2">
        <div className="grid gap-8 lg:grid-cols-[1.15fr_0.85fr] lg:items-start">
          <ContactForm />

          <div className="space-y-6 lg:sticky lg:top-28">
            <Reveal delay={60}>
              <div className="glass rounded-[1.5rem] p-7">
                <h2 className="text-xl text-cream">What happens next</h2>
                <ul className="mt-5 space-y-4">
                  {NEXT_STEPS.map((step) => (
                    <li key={step.title} className="flex gap-3">
                      <Icon name={step.icon} className="mt-0.5 h-5 w-5 shrink-0 text-gold-300" />
                      <span>
                        <span className="block text-[0.92rem] font-bold text-cream">{step.title}</span>
                        <span className="mt-0.5 block text-[0.82rem] leading-relaxed text-sand/65">{step.body}</span>
                      </span>
                    </li>
                  ))}
                </ul>
                <div className="mt-6 grid gap-2">
                  <a
                    href={whatsappLink(`Assalam-o-Alaikum ${SITE.name}!`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-gold w-full"
                  >
                    <Icon name="phone" className="h-4 w-4" />
                    Chat on WhatsApp
                  </a>
                  <Link href="/order" className="btn btn-outline w-full">
                    <Icon name="bag" className="h-4 w-4" />
                    Order online instead
                  </Link>
                </div>
              </div>
            </Reveal>

            <Reveal delay={120}>
              <div className="glass rounded-[1.5rem] p-7">
                <h2 className="text-xl text-cream">Detailed opening hours</h2>
                <ul className="mt-5 divide-y divide-cream/8 text-[0.84rem]">
                  {SITE.hours.map((slot) => (
                    <li key={slot.days} className="flex items-center justify-between gap-4 py-3">
                      <span className="text-sand/70">{slot.days}</span>
                      <span className="text-right font-semibold text-gold-200">{slot.time}</span>
                    </li>
                  ))}
                </ul>
                <p className="mt-5 flex flex-wrap items-center gap-2 text-[0.74rem] text-sand/55">
                  <Badge tone="ember">
                    <Icon name="clock" className="h-3 w-3" strokeWidth={2.2} />
                    Last kitchen order 30 min before close
                  </Badge>
                </p>
              </div>
            </Reveal>

            <Reveal delay={160}>
              <div className="glass rounded-[1.5rem] p-7">
                <h2 className="text-lg text-cream">Follow Masstana</h2>
                <p className="mt-2 text-[0.82rem] text-sand/65">
                  New dishes, BBQ nights and flash deals are posted first on our socials.
                </p>
                <div className="mt-4 flex gap-2.5">
                  {SITE.socials.map((social) => (
                    <a
                      key={social.label}
                      href={social.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={social.label}
                      className="grid h-11 w-11 place-items-center rounded-full border border-cream/12 bg-cream/[0.03] text-sand transition duration-300 hover:-translate-y-1 hover:border-gold-400/60 hover:text-gold-200"
                    >
                      <BrandIcon name={social.icon} className="h-4.5 w-4.5" />
                    </a>
                  ))}
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </Section>

      {/* --------- Map --------- */}
      <Section className="border-t border-gold-400/10 bg-noir-900/40">
        <SectionHeading
          eyebrow="Location"
          title="Find us on"
          highlight="the map"
          description="49 Tail, Sargodha, Punjab, Pakistan — free parking, family hall entrance on the right and the BBQ counter facing the road."
        />
        <Reveal>
          <div className="relative mt-12 overflow-hidden rounded-[1.75rem] border border-gold-400/20">
            <iframe
              title={`Google Maps placeholder for ${SITE.name}, ${SITE.addressLine}`}
              src={SITE.mapEmbedUrl}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="h-[380px] w-full sm:h-[480px]"
              style={{ border: 0, filter: "invert(0.9) hue-rotate(180deg) saturate(0.7)" }}
            />
            <div className="pointer-events-none absolute inset-x-4 top-4 flex flex-wrap items-center gap-2">
              <Badge tone="ember">
                <Icon name="sparkle" className="h-3 w-3" strokeWidth={2.2} />
                Placeholder location
              </Badge>
              <span className="rounded-full border border-gold-400/30 bg-noir-950/80 px-3 py-1 text-[0.64rem] text-sand/75 backdrop-blur">
                The exact pin will be set once the owner confirms the precise address
              </span>
            </div>
            <div className="glass absolute bottom-4 left-4 right-4 flex flex-wrap items-center justify-between gap-4 rounded-2xl p-5 sm:right-auto sm:max-w-md">
              <div>
                <p className="font-display text-lg text-cream">{SITE.name}</p>
                <p className="mt-0.5 text-[0.82rem] text-sand/70">{SITE.addressLine}</p>
                <p className="mt-0.5 text-[0.78rem] text-sand/55">
                  {SITE.phoneDisplay} · {SITE.email}
                </p>
              </div>
              <a href={SITE.mapLinkUrl} target="_blank" rel="noopener noreferrer" className="btn btn-gold !px-4 !py-2.5 !text-[0.66rem]">
                <Icon name="map" className="h-4 w-4" />
                Directions
              </a>
            </div>
          </div>
        </Reveal>
      </Section>

      <Section className="pt-14">
        <Reveal>
          <div className="glass-gold mx-auto flex max-w-4xl flex-col items-center gap-5 rounded-[1.75rem] p-8 text-center sm:p-10">
            <Icon name="chef" className="h-10 w-10 text-gold-200" />
            <h2 className="text-2xl text-cream sm:text-3xl">Planning an event or a big family dinner?</h2>
            <p className="max-w-2xl text-[0.9rem] leading-relaxed text-sand/75">
              We cater up to 400 guests with biryani deg, live BBQ counters and dessert stations. Send your date,
              headcount and preferred menu using the form above and {SITE.owner} will call you back with a quotation.
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              <Link href="/offers" className="btn btn-gold">
                <Icon name="tag" className="h-4 w-4" />
                See party platters
              </Link>
              <Link href="/menu" className="btn btn-outline">
                <Icon name="utensils" className="h-4 w-4" />
                Plan your menu
              </Link>
            </div>
          </div>
        </Reveal>
      </Section>
    </>
  );
}
