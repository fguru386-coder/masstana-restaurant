import { NextResponse } from "next/server";

import { CATEGORIES } from "@/lib/data/menu";
import { getMenuItems } from "@/lib/services";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const category = searchParams.get("category");
  const query = searchParams.get("q")?.trim().toLowerCase();

  let dishes = await getMenuItems();
  if (category && category !== "all") dishes = dishes.filter((dish) => dish.category === category);
  if (query) {
    dishes = dishes.filter(
      (dish) =>
        dish.name.toLowerCase().includes(query) ||
        dish.description.toLowerCase().includes(query) ||
        (dish.tags ?? []).some((tag) => tag.includes(query)),
    );
  }

  return NextResponse.json({
    ok: true,
    count: dishes.length,
    categories: CATEGORIES.map(({ id, label, blurb }) => ({ id, label, blurb })),
    dishes,
  });
}
