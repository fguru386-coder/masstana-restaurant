import { NextResponse } from "next/server";

import { addReview, getReviews } from "@/lib/services";

export const dynamic = "force-dynamic";

export async function GET() {
  const reviews = await getReviews();
  const average = reviews.length ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length : 0;
  return NextResponse.json({ ok: true, count: reviews.length, average: Number(average.toFixed(2)), reviews });
}

export async function POST(request: Request) {
  let body: { name?: string; city?: string; rating?: number; title?: string; body?: string; dish?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid JSON payload." }, { status: 400 });
  }

  const name = String(body?.name ?? "").trim();
  const text = String(body?.body ?? "").trim();
  if (name.length < 2) return NextResponse.json({ ok: false, error: "Please enter your name." }, { status: 422 });
  if (text.length < 15) {
    return NextResponse.json({ ok: false, error: "Please write at least 15 characters." }, { status: 422 });
  }

  const review = await addReview({
    name,
    city: String(body?.city ?? "Sargodha"),
    rating: Number(body?.rating ?? 5),
    title: String(body?.title ?? ""),
    body: text,
    dish: body?.dish ? String(body.dish) : undefined,
  });

  return NextResponse.json({ ok: true, review }, { status: 201 });
}
