import { NextResponse } from "next/server";

import { addContactMessage } from "@/lib/services";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: { name?: string; email?: string; phone?: string; subject?: string; message?: string; kind?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid JSON payload." }, { status: 400 });
  }

  const name = String(body?.name ?? "").trim();
  const message = String(body?.message ?? "").trim();
  if (name.length < 2) return NextResponse.json({ ok: false, error: "Please enter your name." }, { status: 422 });
  if (message.length < 12) {
    return NextResponse.json({ ok: false, error: "Please write a message of at least 12 characters." }, { status: 422 });
  }

  const result = await addContactMessage({
    name,
    email: body?.email,
    phone: body?.phone,
    subject: body?.subject,
    message,
    kind: body?.kind,
  });

  return NextResponse.json(
    {
      ok: true,
      persisted: result.persisted,
      id: result.id ?? null,
      message: result.persisted ? "Message saved." : "Message captured in demo mode.",
    },
    { status: 201 },
  );
}
