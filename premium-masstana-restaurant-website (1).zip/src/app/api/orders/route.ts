import { NextResponse } from "next/server";

import { createOrder, recentOrders } from "@/lib/services";
import type { OrderInput } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid JSON payload." }, { status: 400 });
  }

  const result = await createOrder(body as OrderInput);
  if (!result.ok) {
    return NextResponse.json({ ok: false, error: result.error }, { status: 422 });
  }

  return NextResponse.json(
    {
      ok: true,
      code: result.code,
      persisted: result.persisted,
      totals: result.totals,
      status: "received",
      note: result.persisted
        ? "Order saved to the restaurant database."
        : "Order generated in demo mode — database was unreachable.",
    },
    { status: 201 },
  );
}

export async function GET() {
  try {
    const rows = await recentOrders(20);
    return NextResponse.json({
      ok: true,
      count: rows.length,
      orders: rows.map((row) => ({
        code: row.code,
        customerName: row.customerName,
        orderType: row.orderType,
        area: row.area,
        itemCount: row.itemCount,
        total: row.total,
        status: row.status,
        createdAt: row.createdAt,
      })),
    });
  } catch {
    return NextResponse.json({ ok: false, count: 0, orders: [] });
  }
}
