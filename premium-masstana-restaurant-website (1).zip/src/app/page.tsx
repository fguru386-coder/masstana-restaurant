import type { Metadata } from "next";
import Link from "next/link";

import { OfferCard } from "@/components/offers/offer-grid";
import { DealCard, FoodCard } from "@/components/ui/food-card";
import { Icon, Stars } from "@/components/ui/icons";
import { CountUp, Reveal } from "@/components/ui/reveal";
import { Badge, Section, SectionHeading } from "@/components/ui/section";
import { SmartImage } from "@/components/ui/smart-image";
import { DELIVERY_PROMISES, FEATURES, OFFERS, STATS } from "@/lib/data/content";
import { CATEGORIES } from "@/lib/data/menu";
import { IMG, LOCAL } from "@/lib/data/images";
import { getMenuItems, getReviews } from "@/lib/services";
import { DELIVERY, SITE, formatPKR } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "MASSTANA RESTAURANT | Multi-Cuisine Restaurant in Sargodha",
  description:
    "Dum biryani, charcoal BBQ, karahi, nihari, Chinese, continental, pizza, breakfast, desserts and family deals at MASSTANA RESTAURANT, 49 Tail Sargodha. Dine-in, takeaway and online home delivery in PKR.",
  alternates: { canonical: "/" },
};

const MARQUEE_ITEMS = [
  "Charcoal BBQ",
  "Dum Biryani",
  "Chicken Karahi",
  "Beef Nihari",
  "Iron Plate Shashlik",
  "Zinger Burgers",
  "Halwa Puri",
  "Kulfi Falooda",
  "Family Deals",
  "Open till 2 AM",
];

export default async function HomePage() {
  const dishes = await getMenuItems();
  const reviews = await getReviews();
  const featured = dishes.filter((dish) => dish.popular).slice(0, 8);
  const heroDish = featured[0] ?? dishes[0];
  const dealDishes = dishes.filter((dish) => dish.category === "deals").slice(0, 2);
  const topReviews = reviews.slice(0, 3);

  return (
    <>
      {/* ============================ HERO ============================ */}
      <section className="relative flex min-h-[94vh] items-center overflow-hidden pb-16 pt-28 sm:pt-32">
        <div className="absolute inset-0 -z-10">
          <SmartImage src={LOCAL.heroFeast} alt="" className="h-full w-full animate-kenburns" imgClassName="opacity-55" priority />
          <div className="absolute inset-0 bg-gradient-to-r from-noir-950 via-noir-950/80 to-noir-950/35" />
          <div className="absolute inset-0 bg-gradient-to-t from-noir-950 via-transparent to-noir-950/70" />
          <div className="absolute -left-24 top-1/3 h-72 w-72 rounded-full bg-ember-500/20 blur-[120px] animate-ember" />
          <div className="absolute right-10 top-10 h-64 w-64 rounded-full bg-gold-500/15 blur-[110px] animate-ember" />
        </div>

        <div className="mx-auto grid w-full max-w-7xl items-center gap-14 px-5 sm:px-8 lg:grid-cols-[1.15fr_0.85fr]">
          <div className="page-enter">
            <div className="flex flex-wrap items-center gap-3">
              <Badge tone="gold">
                <Icon name="pin" className="h-3 w-3" strokeWidth={2.2} />
                {SITE.addressLine}
              </Badge>
              <Badge tone="ember">
                <Icon name="clock" className="h-3 w-3" strokeWidth={2.2} />
                Open till 2 AM
              </Badge>
              <span className="inline-flex items-center gap-2 rounded-full border border-cream/12 bg-cream/5 px-3 py-1 text-[0.62rem] font-bold uppercase tracking-[0.16em] text-sand">
                <Stars value={4.8} className="h-3 w-3" />
                4.8 · 2,400+ guests
              </span>
            </div>

            <p className="script mt-7 text-2xl text-gold-300/90">Assalam-o-Alaikum, welcome to</p>
            <h1 className="mt-1 font-display text-[3.1rem] leading-[0.95] tracking-[0.02em] text-cream sm:text-7xl lg:text-[5.6rem]">
              MASSTANA
              <span className="mt-2 block gold-text text-2xl tracking-[0.34em] sm:text-3xl lg:text-4xl">RESTAURANT</span>
            </h1>

            <p className="mt-6 max-w-xl text-[1rem] leading-relaxed text-sand/80">
              Sargodha's multi-cuisine table — dum biryani sealed in its own steam, kababs kissed by live charcoal,
              wok-fired Chinese, continental grills, desi nashta from 7 AM and desserts made in-house.{" "}
              <span className="text-gold-200">Dine-in, takeaway or delivered hot to your door.</span>
            </p>

            <div className="mt-9 flex flex-wrap gap-3">
              <Link href="/order" className="btn btn-gold">
                <Icon name="bag" className="h-4 w-4" />
                Order online
              </Link>
              <Link href="/menu" className="btn btn-outline">
                <Icon name="utensils" className="h-4 w-4" />
                Explore menu
              </Link>
              <a href={SITE.phoneHref} className="btn btn-ghost">
                <Icon name="phone" className="h-4 w-4" />
                {SITE.phoneDisplay}
              </a>
            </div>

            <dl className="mt-12 grid max-w-2xl grid-cols-2 gap-5 sm:grid-cols-4">
              {STATS.map((stat, index) => {
                const numeric = parseFloat(stat.value.replace(/[^0-9.]/g, ""));
                const suffix = stat.value.replace(/[0-9.]/g, "");
                return (
                  <Reveal key={stat.label} delay={index * 90}>
                    <div className="border-l border-gold-400/25 pl-4">
                      <dt className="font-display text-3xl gold-text">
                        <CountUp value={numeric} suffix={suffix} />
                      </dt>
                      <dd className="mt-1 text-[0.68rem] uppercase tracking-[0.16em] text-sand/60">{stat.label}</dd>
                    </div>
                  </Reveal>
                );
              })}
            </dl>
          </div>

          {/* floating glass cards */}
          <div className="relative hidden lg:block">
            <Reveal delay={200}>
              <div className="glass animate-float-slow relative rounded-[1.8rem] p-5 shadow-[0_40px_90px_-40px_rgba(0,0,0,1)]">
                <div className="relative overflow-hidden rounded-[1.3rem]">
                  <SmartImage src={heroDish.image} alt={heroDish.name} className="aspect-[4/3] w-full" sizes="420px" priority />
                  <span className="absolute left-3 top-3 rounded-full bg-noir-950/75 px-3 py-1.5 text-[0.6rem] font-bold uppercase tracking-[0.18em] text-gold-200 backdrop-blur">
                    House signature
                  </span>
                </div>
                <div className="mt-4 flex items-end justify-between gap-4">
                  <div>
                    <h2 className="text-lg text-cream">{heroDish.name}</h2>
                    <p className="mt-1 flex items-center gap-2 text-[0.75rem] text-sand/65">
                      <Stars value={heroDish.rating ?? 4.8} className="h-3.5 w-3.5" />
                      {heroDish.serves}
                    </p>
                  </div>
                  <span className="font-display text-2xl gold-text">{formatPKR(heroDish.price)}</span>
                </div>
                <Link href="/menu" className="btn btn-gold mt-4 w-full !text-[0.7rem]">
                  See full menu
                  <Icon name="arrowRight" className="h-4 w-4" />
                </Link>
              </div>
            </Reveal>

            <Reveal delay={320}>
              <Link
                href="/delivery"
                className="glass-gold animate-float absolute -bottom-10 -left-14 flex w-64 items-center gap-3 rounded-2xl p-4 transition hover:-translate-y-1"
              >
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-gold-300 to-ember-500 text-noir-950">
                  <Icon name="bike" className="h-6 w-6" />
                </span>
                <span>
                  <span className="block text-[0.82rem] font-bold text-cream">Free delivery</span>
                  <span className="block text-[0.7rem] text-sand/70">on orders over {formatPKR(DELIVERY.freeOver)}</span>
                </span>
              </Link>
            </Reveal>
          </div>
        </div>

        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-noir-950 to-transparent" />
      </section>

      {/* ============================ MARQUEE ============================ */}
      <div className="marquee-mask relative z-10 overflow-hidden border-y border-gold-400/12 bg-noir-900/70 py-4">
        <div className="marquee-track">
          {[0, 1].map((dup) => (
            <div key={dup} className="flex shrink-0 items-center gap-10 pr-10">
              {MARQUEE_ITEMS.map((item) => (
                <span key={`${dup}-${item}`} className="flex items-center gap-10 whitespace-nowrap">
                  <span className="text-[0.72rem] font-semibold uppercase tracking-[0.3em] text-sand/70">{item}</span>
                  <Icon name="sparkle" className="h-3.5 w-3.5 text-gold-400/70" />
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* ============================ STORY ============================ */}
      <Section>
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <Reveal>
            <div className="relative">
              <div className="overflow-hidden rounded-[2rem] border border-gold-400/15">
                <SmartImage src={LOCAL.interior} alt="Masstana Restaurant dining room" className="aspect-[4/3] w-full" sizes="(max-width:1024px) 92vw, 46vw" />
              </div>
              <div className="absolute -bottom-10 -right-4 w-48 overflow-hidden rounded-[1.4rem] border border-gold-400/30 shadow-[0_30px_70px_-30px_rgba(0,0,0,1)] sm:-right-10 sm:w-60">
                <SmartImage src={IMG.chefGrill} alt="Chef grilling kebabs over flame" className="aspect-[4/5] w-full" sizes="240px" />
              </div>
              <div className="glass-gold absolute -left-3 top-6 rounded-2xl px-4 py-3 sm:-left-8">
                <p className="font-display text-2xl gold-text">Since {SITE.since}</p>
                <p className="text-[0.62rem] uppercase tracking-[0.18em] text-sand/70">49 Tail, Sargodha</p>
              </div>
            </div>
          </Reveal>

          <div>
            <SectionHeading
              align="left"
              eyebrow="Our story"
              title="From one tawa to"
              highlight="Sargodha's favourite table"
              description={`${SITE.owner} started Masstana in ${SITE.since} with a single tawa, a chai kettle and his mother's paratha recipe. Twelve years later it is a full multi-cuisine kitchen — but the rule never changed: cook everything fresh, never compromise on masala, and treat every guest like family.`}
            />
            <div className="mt-8 space-y-4">
              {FEATURES.slice(0, 4).map((feature, index) => (
                <Reveal key={feature.title} delay={index * 80}>
                  <div className="group flex items-start gap-4 rounded-2xl border border-cream/8 bg-cream/[0.02] p-4 transition duration-400 hover:border-gold-400/40 hover:bg-gold-400/[0.06]">
                    <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-gold-400/25 bg-gold-400/8 text-gold-300 transition duration-400 group-hover:scale-110 group-hover:text-gold-200">
                      <Icon name={feature.icon} className="h-5 w-5" />
                    </span>
                    <span>
                      <span className="block text-[0.95rem] font-bold text-cream">{feature.title}</span>
                      <span className="mt-1 block text-[0.82rem] leading-relaxed text-sand/65">{feature.body}</span>
                    </span>
                  </div>
                </Reveal>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/about" className="btn btn-outline">
                Meet {SITE.owner}
                <Icon name="arrowRight" className="h-4 w-4" />
              </Link>
              <Link href="/gallery" className="btn btn-ghost">
                <Icon name="sparkle" className="h-4 w-4" />
                See the restaurant
              </Link>
            </div>
          </div>
        </div>
      </Section>

      {/* ============================ SIGNATURE DISHES ============================ */}
      <Section className="border-y border-gold-400/10 bg-noir-900/40">
        <SectionHeading
          eyebrow="Most ordered"
          title="Signature dishes our guests"
          highlight="order again and again"
          description="Hand-picked from 96 dishes across eight kitchens. Prices in Pakistani Rupees, taxes shown at checkout."
        />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {featured.map((dish, index) => (
            <FoodCard key={dish.id} dish={dish} index={index} />
          ))}
        </div>
        <Reveal delay={120}>
          <div className="mt-12 flex justify-center">
            <Link href="/menu" className="btn btn-gold">
              View the complete menu
              <Icon name="arrowRight" className="h-4 w-4" />
            </Link>
          </div>
        </Reveal>
      </Section>

      {/* ============================ CATEGORIES ============================ */}
      <Section>
        <SectionHeading
          eyebrow="Eight kitchens, one roof"
          title="Choose your"
          highlight="craving"
          description="Every cuisine is cooked in its own section by chefs who specialise in it — no shared masala, no shortcuts."
        />
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {CATEGORIES.map((category, index) => (
            <Reveal key={category.id} delay={(index % 4) * 80} className="h-full">
              <Link
                href={`/menu?c=${category.id}`}
                className="group relative flex h-full flex-col overflow-hidden rounded-[1.5rem] border border-gold-400/12 transition duration-500 hover:border-gold-400/50"
              >
                <SmartImage
                  src={category.cover}
                  alt={category.label}
                  className="aspect-[5/4] w-full"
                  imgClassName="transition-transform duration-[900ms] group-hover:scale-110"
                  sizes="(max-width:640px) 92vw, (max-width:1024px) 45vw, 24vw"
                />
                <span className="absolute inset-0 bg-gradient-to-t from-noir-950 via-noir-950/45 to-transparent transition-opacity duration-500 group-hover:from-noir-950/95" />
                <span className="absolute inset-x-0 bottom-0 p-5">
                  <span className="flex items-center gap-2 text-[0.6rem] font-bold uppercase tracking-[0.22em] text-gold-300/85">
                    <Icon name={category.icon} className="h-4 w-4" />
                    {category.urdu}
                  </span>
                  <span className="mt-1.5 block font-display text-xl text-cream transition-colors group-hover:text-gold-200">
                    {category.label}
                  </span>
                  <span className="mt-1 block text-[0.76rem] leading-snug text-sand/65">{category.blurb}</span>
                </span>
                <span className="absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-full border border-gold-400/35 bg-noir-950/60 text-gold-200 opacity-0 backdrop-blur transition-all duration-500 group-hover:opacity-100">
                  <Icon name="arrowRight" className="h-4 w-4" />
                </span>
              </Link>
            </Reveal>
          ))}
        </div>
      </Section>

      {/* ============================ OFFERS ============================ */}
      <Section className="border-y border-gold-400/10 bg-noir-900/40">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHeading
            align="left"
            eyebrow="Running offers"
            title="Deals worth"
            highlight="the drive"
            description="Apply the code at checkout — discounts calculate instantly, no minimum surprises."
          />
          <Reveal delay={120}>
            <Link href="/offers" className="btn btn-outline">
              All offers
              <Icon name="arrowRight" className="h-4 w-4" />
            </Link>
          </Reveal>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {OFFERS.slice(0, 3).map((offer, index) => (
            <OfferCard key={offer.code} offer={offer} index={index} />
          ))}
        </div>
      </Section>

      {/* ============================ DELIVERY ============================ */}
      <Section>
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div>
            <SectionHeading
              align="left"
              eyebrow="Home delivery"
              title="Hot food, fast wheels,"
              highlight="all over Sargodha"
              description={`Our own riders cover an ${DELIVERY.radiusKm} km radius from 49 Tail — insulated bags keep karahi steaming and kulfi frozen. Most zones receive their order in ${DELIVERY.prepTime} minutes.`}
            />
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              {DELIVERY_PROMISES.map((promise, index) => (
                <Reveal key={promise.title} delay={index * 80}>
                  <div className="tilt-card flex h-full items-start gap-3 rounded-2xl border border-cream/8 bg-cream/[0.02] p-4">
                    <Icon name={promise.icon} className="mt-0.5 h-5 w-5 shrink-0 text-gold-300" />
                    <span>
                      <span className="block text-[0.9rem] font-bold text-cream">{promise.title}</span>
                      <span className="mt-1 block text-[0.78rem] text-sand/60">{promise.body}</span>
                    </span>
                  </div>
                </Reveal>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/delivery" className="btn btn-outline">
                <Icon name="map" className="h-4 w-4" />
                Delivery areas &amp; charges
              </Link>
              <Link href="/order" className="btn btn-gold">
                <Icon name="bike" className="h-4 w-4" />
                Order for delivery
              </Link>
            </div>
          </div>

          <Reveal delay={100}>
            <div className="relative overflow-hidden rounded-[2rem] border border-gold-400/15">
              <SmartImage src={LOCAL.delivery} alt="Masstana delivery rider at night" className="aspect-[4/3] w-full" sizes="(max-width:1024px) 92vw, 46vw" />
              <div className="absolute inset-0 bg-gradient-to-t from-noir-950 via-noir-950/25 to-transparent" />
              <div className="absolute inset-x-5 bottom-5 flex flex-wrap items-center gap-3">
                <span className="glass rounded-2xl px-4 py-3 text-[0.78rem] text-sand">
                  <span className="block font-display text-lg text-gold-200">{formatPKR(120)}</span>
                  starting delivery fee
                </span>
                <span className="glass rounded-2xl px-4 py-3 text-[0.78rem] text-sand">
                  <span className="block font-display text-lg text-gold-200">{DELIVERY.prepTime} min</span>
                  average drop time
                </span>
                <span className="glass rounded-2xl px-4 py-3 text-[0.78rem] text-sand">
                  <span className="block font-display text-lg text-gold-200">{DELIVERY.radiusKm} km</span>
                  covered radius
                </span>
              </div>
            </div>
          </Reveal>
        </div>
      </Section>

      {/* ============================ DEALS ============================ */}
      {dealDishes.length > 0 && (
        <Section className="border-y border-gold-400/10 bg-noir-900/40">
          <SectionHeading
              eyebrow="Bundle & save"
              title="Family, couple & student"
            highlight="deals"
            description="Honest portions at bundle prices — cooked to order, packed hot and delivered across Sargodha."
          />
          <div className="mt-12 grid gap-6">
            {dealDishes.map((dish, index) => (
              <DealCard key={dish.id} dish={dish} index={index} />
            ))}
          </div>
          <Reveal delay={100}>
            <div className="mt-10 flex justify-center">
              <Link href="/offers" className="btn btn-ghost">
                <Icon name="tag" className="h-4 w-4" />
                See every combo deal
              </Link>
            </div>
          </Reveal>
        </Section>
      )}

      {/* ============================ REVIEWS ============================ */}
      <Section>
        <SectionHeading
          eyebrow="Guest love"
          title="What Sargodha says"
          highlight="about us"
        />
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {topReviews.map((review, index) => (
            <Reveal key={review.id} delay={index * 90} className="h-full">
              <article className="tilt-card flex h-full flex-col gap-4 rounded-[1.5rem] border border-gold-400/12 bg-gradient-to-br from-noir-800/80 to-noir-950/90 p-6">
                <Icon name="quote" className="h-8 w-8 text-gold-400/30" />
                <Stars value={review.rating} className="h-4 w-4" />
                <h3 className="text-[1rem] font-bold text-gold-200">{review.title}</h3>
                <p className="line-clamp-5 text-[0.86rem] leading-relaxed text-sand/75">{review.body}</p>
                <p className="mt-auto flex items-center gap-3 border-t border-cream/8 pt-4 text-[0.78rem] text-sand/60">
                  <span className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-gold-300 to-ember-500 font-display text-xs text-noir-950">
                    {review.name.slice(0, 1)}
                  </span>
                  <span>
                    <span className="block font-semibold text-cream">{review.name}</span>
                    {review.city}
                  </span>
                </p>
              </article>
            </Reveal>
          ))}
        </div>
        <Reveal delay={120}>
          <div className="mt-10 flex justify-center">
            <Link href="/reviews" className="btn btn-outline">
              Read all reviews
              <Icon name="arrowRight" className="h-4 w-4" />
            </Link>
          </div>
        </Reveal>
      </Section>

      {/* ============================ CTA BAND ============================ */}
      <section className="relative overflow-hidden px-5 pb-20 sm:px-8">
        <div className="mx-auto max-w-7xl">
          <Reveal>
            <div className="relative overflow-hidden rounded-[2rem] border border-gold-400/25 bg-gradient-to-br from-[#1b1420] via-noir-900 to-[#241610] p-8 sm:p-14">
              <div className="pointer-events-none absolute inset-0 opacity-30">
                <SmartImage src={IMG.candleTable} alt="" className="h-full w-full" imgClassName="opacity-40" />
              </div>
              <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-ember-500/20 blur-[110px] animate-ember" />
              <div className="relative grid items-center gap-8 lg:grid-cols-[1.4fr_1fr]">
                <div>
                  <span className="eyebrow">Reserve · Order · Celebrate</span>
                  <h2 className="mt-4 text-3xl leading-tight text-cream sm:text-5xl">
                    A table is waiting for you at <span className="gold-text">49 Tail</span>
                  </h2>
                  <p className="mt-4 max-w-xl text-[0.92rem] leading-relaxed text-sand/75">
                    Family halls, private party rooms and an open kitchen view. Book a table, order takeaway or get it
                    delivered — {SITE.owner} and the team are ready.
                  </p>
                </div>
                <div className="grid gap-3">
                  <Link href="/order" className="btn btn-gold w-full">
                    <Icon name="bag" className="h-4 w-4" />
                    Start your order
                  </Link>
                  <a href={SITE.phoneHref} className="btn btn-outline w-full">
                    <Icon name="phone" className="h-4 w-4" />
                    Call to reserve
                  </a>
                  <Link href="/contact" className="btn btn-ghost w-full">
                    <Icon name="mail" className="h-4 w-4" />
                    Plan an event
                  </Link>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
