import type { MetadataRoute } from "next";

const BASE = "https://masstanarestaurant.pk";

const routes: { path: string; priority: number; changeFrequency: MetadataRoute.Sitemap[number]["changeFrequency"] }[] = [
  { path: "", priority: 1, changeFrequency: "daily" },
  { path: "/menu", priority: 0.95, changeFrequency: "weekly" },
  { path: "/order", priority: 0.95, changeFrequency: "weekly" },
  { path: "/offers", priority: 0.9, changeFrequency: "weekly" },
  { path: "/delivery", priority: 0.85, changeFrequency: "monthly" },
  { path: "/about", priority: 0.8, changeFrequency: "monthly" },
  { path: "/gallery", priority: 0.75, changeFrequency: "monthly" },
  { path: "/reviews", priority: 0.75, changeFrequency: "weekly" },
  { path: "/contact", priority: 0.8, changeFrequency: "monthly" },
  { path: "/faq", priority: 0.7, changeFrequency: "monthly" },
];

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  return routes.map((route) => ({
    url: `${BASE}${route.path}`,
    lastModified: now,
    changeFrequency: route.changeFrequency,
    priority: route.priority,
  }));
}
