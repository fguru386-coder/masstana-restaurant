import type { Metadata } from "next";
import Link from "next/link";

import { PageHero } from "@/components/layout/page-hero";
import { OfferGrid } from "@/components/offers/offer-grid";
import { DealCard } from "@/components/ui/food-card";
import { Icon } from "@/components/ui/icons";
import { Reveal } from "@/components/ui/reveal";
import { Section, SectionHeading } from "@/components/ui/section";
import { SmartImage } from "@/components/ui/smart-image";
import { OFFERS } from "@/lib/data/content";
import { MENU } from "@/lib/data/menu";
import { IMG } from "@/lib/data/images";
import { SITE, formatPKR, whatsappLink } from "@/lib/site";

export const metadata: Metadata = {
  title: "Offers — Discounts, Combo Deals & Promotions in Sargodha",
  description:
    "Current MASSTANA RESTAURANT offers: MASS10 (10% off), FAMILY20, STUDENT15, FREESHIP, BBQ25, LATE15, FIRST500 and SWEET100, plus family, couple, student and party platter combo deals in PKR.",
  alternates: { canonical: "/offers" },
};

const TERMS = [
  "Only one promo code can be used per order.",
  "Discounts apply to food value; delivery fees are shown separately unless the code waives them.",
  "Student discount requires a valid student ID (photo accepted on WhatsApp).",
  "Time-based offers (BBQ25, LATE15) apply only inside their stated hours.",
  "Offers cannot be combined with event or catering quotations.",
  "Prices are in Pakistani Rupees and may change with ingredient costs — the menu page always shows the current price.",
];

export default function OffersPage() {
  const featured = OFFERS.find((offer) => offer.code === "MASS10") ?? OFFERS[0];
  const rest = OFFERS.filter((offer) => offer.code !== featured.code);
  const deals = MENU.filter((dish) => dish.category === "deals");

  return (
    <>
      <PageHero
        eyebrow="Offers & promotions"
        title="Discounts, combos"
        highlight="and late-night deals"
        description="Every code below works at checkout on the Order Online page — discounts calculate instantly against your cart total."
        image={IMG.festiveTable}
        crumb="Offers"
      />

      {/* --------- Headline offer --------- */}
      <Section className="pt-10">
        <Reveal>
          <div className="relative overflow-hidden rounded-[2rem] border border-gold-400/25">
            <SmartImage src={featured.image} alt={featured.title} className="absolute inset-0 h-full w-full" imgClassName="opacity-30" priority />
            <div className="absolute inset-0 bg-gradient-to-r from-noir-950 via-noir-950/85 to-noir-950/40" />
            <div className="pointer-events-none absolute -right-10 -top-10 h-64 w-64 rounded-full bg-ember-500/20 blur-[100px] animate-ember" />
            <div className="relative grid gap-8 p-8 sm:p-12 lg:grid-cols-[1.4fr_1fr] lg:items-center">
              <div>
                <span className="eyebrow">{featured.badge} · {featured.subtitle}</span>
                <h2 className="mt-4 text-4xl leading-tight text-cream sm:text-5xl">
                  {featured.value}% off <span className="gold-text">every single order</span>
                </h2>
                <p className="mt-4 max-w-xl text-[0.94rem] leading-relaxed text-sand/75">{featured.description}</p>
                <ul className="mt-5 flex flex-wrap gap-x-6 gap-y-2 text-[0.8rem] text-sand/65">
                  {featured.terms.map((term) => (
                    <li key={term} className="flex items-center gap-2">
                      <Icon name="check" className="h-4 w-4 text-gold-400" strokeWidth={2.2} />
                      {term}
                    </li>
                  ))}
                </ul>
                <div className="mt-7 flex flex-wrap gap-3">
                  <Link href="/order" className="btn btn-gold">
                    <Icon name="bag" className="h-4 w-4" />
                    Apply {featured.code} at checkout
                  </Link>
                  <a
                    href={whatsappLink(`Assalam-o-Alaikum ${SITE.name}! I would like to use the ${featured.code} offer.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-outline"
                  >
                    <Icon name="phone" className="h-4 w-4" />
                    Order on WhatsApp
                  </a>
                </div>
              </div>

              <div className="glass-gold rounded-[1.5rem] p-7 text-center">
                <p className="text-[0.66rem] font-bold uppercase tracking-[0.28em] text-sand/70">Your promo code</p>
                <p className="mt-3 font-display text-5xl tracking-[0.12em] text-cream text-shadow-gold">{featured.code}</p>
                <div className="mt-4 hairline" />
                <p className="mt-4 text-[0.82rem] text-sand/75">
                  Minimum order {formatPKR(featured.minOrder)} · maximum discount{" "}
                  {featured.maxDiscount ? formatPKR(featured.maxDiscount) : "unlimited"}
                </p>
                <p className="mt-1 text-[0.76rem] text-gold-300">{featured.validUntil}</p>
              </div>
            </div>
          </div>
        </Reveal>
      </Section>

      {/* --------- All offers --------- */}
      <Section className="pt-6">
        <SectionHeading
          eyebrow={`${OFFERS.length} active offers`}
          title="Pick the code that"
          highlight="fits your order"
          description="Tap any code to copy it, then paste it into the promo box in your cart or at checkout."
        />
        <div className="mt-12">
          <OfferGrid offers={rest} />
        </div>
      </Section>

      {/* --------- Combo deals --------- */}
      <Section className="border-y border-gold-400/10 bg-noir-900/40">
        <SectionHeading
          eyebrow="Combo deals"
          title="Family, couple, student"
          highlight="& party platters"
          description="Bundle pricing cooked to order — add any deal straight to your cart from this page."
        />
        <div className="mt-12 grid gap-6">
          {deals.map((dish, index) => (
            <DealCard key={dish.id} dish={dish} index={index} />
          ))}
        </div>
      </Section>

      {/* --------- Terms --------- */}
      <Section>
        <div className="grid gap-8 lg:grid-cols-[1fr_1.1fr] lg:items-start">
          <Reveal>
            <div className="overflow-hidden rounded-[1.5rem] border border-gold-400/15">
              <SmartImage src={IMG.bbqCharcoal} alt="Charcoal grill loaded with kebabs" className="aspect-[4/3] w-full" sizes="(max-width:1024px) 92vw, 46vw" />
            </div>
          </Reveal>
          <div>
            <SectionHeading align="left" eyebrow="Terms & conditions" title="The fine print," highlight="in plain words" />
            <ul className="mt-7 space-y-3">
              {TERMS.map((term, index) => (
                <Reveal key={term} delay={index * 60}>
                  <li className="flex gap-3 rounded-xl border border-cream/8 bg-cream/[0.02] p-4 text-[0.86rem] leading-relaxed text-sand/75">
                    <Icon name="sparkle" className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
                    {term}
                  </li>
                </Reveal>
              ))}
            </ul>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link href="/order" className="btn btn-gold">
                <Icon name="bag" className="h-4 w-4" />
                Start your order
              </Link>
              <Link href="/faq" className="btn btn-outline">
                <Icon name="quote" className="h-4 w-4" />
                Read the FAQ
              </Link>
            </div>
          </div>
        </div>
      </Section>
    </>
  );
}
