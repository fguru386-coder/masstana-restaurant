import type { Metadata } from "next";
import Link from "next/link";

import { PageHero } from "@/components/layout/page-hero";
import { ReviewWall } from "@/components/reviews/review-wall";
import { Icon } from "@/components/ui/icons";
import { CountUp, Reveal } from "@/components/ui/reveal";
import { Section, SectionHeading } from "@/components/ui/section";
import { IMG } from "@/lib/data/images";
import { getReviews } from "@/lib/services";
import { SITE, whatsappLink } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Customer Reviews — What Sargodha Says About Masstana",
  description:
    "Verified customer reviews of MASSTANA RESTAURANT, 49 Tail Sargodha — biryani, BBQ platters, home delivery speed, Chinese food, desserts and family deals. Read and write reviews.",
  alternates: { canonical: "/reviews" },
};

const SOURCES = [
  { label: "Google reviews", value: 4.8, icon: "sparkle" },
  { label: "Website reviews", value: 4.9, icon: "heart" },
  { label: "Delivery rating", value: 4.7, icon: "bike" },
];

export default async function ReviewsPage() {
  const reviews = await getReviews();
  const average = reviews.length ? reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length : 0;

  return (
    <>
      <PageHero
        eyebrow="Customer reviews"
        title="Rated by the city"
        highlight="that eats here"
        description="Real feedback from Sargodha families, students, late-night BBQ lovers and event organisers. Write your own review — it publishes on this page instantly."
        image={IMG.roundTables}
        crumb="Customer Reviews"
      />

      <Section className="pt-12">
        <div className="grid gap-6 sm:grid-cols-3">
          {SOURCES.map((source, index) => (
            <Reveal key={source.label} delay={index * 90}>
              <div className="glass tilt-card flex items-center gap-4 rounded-2xl p-6">
                <span className="grid h-12 w-12 place-items-center rounded-xl border border-gold-400/25 bg-gold-400/8 text-gold-300">
                  <Icon name={source.icon} className="h-6 w-6" />
                </span>
                <div>
                  <p className="font-display text-3xl gold-text">
                    <CountUp value={source.value} />
                  </p>
                  <p className="mt-0.5 text-[0.72rem] uppercase tracking-[0.16em] text-sand/60">{source.label}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <div className="mt-10">
          <SectionHeading
            eyebrow={`${reviews.length} published reviews · average ${average.toFixed(1)} / 5`}
            title="Guest experiences,"
            highlight="dish by dish"
            description="Filter by star rating, then read what people ordered and how it went."
          />
        </div>

        <div className="mt-12">
          <ReviewWall initial={reviews} />
        </div>
      </Section>

      <Section className="border-t border-gold-400/10 bg-noir-900/40">
        <Reveal>
          <div className="glass mx-auto max-w-4xl rounded-[1.75rem] p-8 text-center sm:p-12">
            <span className="mx-auto grid h-14 w-14 place-items-center rounded-full border border-gold-400/30 bg-gold-400/8 text-gold-300">
              <Icon name="shield" className="h-7 w-7" />
            </span>
            <h2 className="mt-6 text-2xl text-cream sm:text-3xl">Something didn't go right?</h2>
            <p className="mx-auto mt-3 max-w-2xl text-[0.9rem] leading-relaxed text-sand/70">
              Tell us within 30 minutes with your order code and we replace the dish or refund it. Honest complaints make
              our kitchen better — {SITE.owner} reads every single one.
            </p>
            <div className="mt-7 flex flex-wrap justify-center gap-3">
              <Link href="/contact" className="btn btn-gold">
                <Icon name="mail" className="h-4 w-4" />
                Report an issue
              </Link>
              <a
                href={whatsappLink(`Assalam-o-Alaikum ${SITE.name}, I have feedback about my order:`)}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-outline"
              >
                <Icon name="phone" className="h-4 w-4" />
                Message on WhatsApp
              </a>
            </div>
          </div>
        </Reveal>
      </Section>
    </>
  );
}
