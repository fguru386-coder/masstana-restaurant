import type { Metadata } from "next";
import Link from "next/link";
import { Suspense } from "react";

import { MenuBrowser } from "@/components/menu/menu-browser";
import { PageHero } from "@/components/layout/page-hero";
import { Icon } from "@/components/ui/icons";
import { Reveal } from "@/components/ui/reveal";
import { Section } from "@/components/ui/section";
import { CATEGORIES } from "@/lib/data/menu";
import { IMG } from "@/lib/data/images";
import { getMenuItems } from "@/lib/services";
import { SITE, whatsappLink } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Menu — Biryani, BBQ, Chinese, Continental, Breakfast, Desserts & Deals",
  description:
    "Complete MASSTANA RESTAURANT menu with 96 dishes: Pakistani biryani, karahi, nihari, haleem, BBQ kababs, zinger burgers, pizza, shawarma, Chinese chow mein, shashlik, continental steaks and pasta, breakfast halwa puri, desserts and beverages. Prices in PKR.",
  alternates: { canonical: "/menu" },
};

export default async function MenuPage({ searchParams }: { searchParams: Promise<{ c?: string }> }) {
  const { c } = await searchParams;
  const dishes = await getMenuItems();
  const active = CATEGORIES.find((category) => category.id === c);

  return (
    <>
      <PageHero
        eyebrow="The full menu"
        title="Eight kitchens,"
        highlight="one legendary table"
        description="Search, filter and add straight to your cart. Every price is in Pakistani Rupees and every dish is cooked after you order it — nothing sits under a warmer."
        image={IMG.festiveTable}
        crumb="Menu"
      >
        <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
          <Link href="/menu" className={`chip ${!c ? "!border-gold-400 !text-gold-100" : ""}`}>
            All dishes · {dishes.length}
          </Link>
          {CATEGORIES.map((category) => (
            <Link
              key={category.id}
              href={`/menu?c=${category.id}`}
              className={`chip ${c === category.id ? "!border-gold-400 !text-gold-100" : ""}`}
            >
              <Icon name={category.icon} className="h-3.5 w-3.5" />
              {category.label}
            </Link>
          ))}
        </div>
      </PageHero>

      <Section className="pt-12">
        {active && (
          <Reveal>
            <div className="glass-gold mb-10 flex flex-wrap items-center justify-between gap-4 rounded-2xl px-6 py-4">
              <div className="flex items-center gap-4">
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-noir-950/50 text-gold-200">
                  <Icon name={active.icon} className="h-5 w-5" />
                </span>
                <div>
                  <p className="font-display text-lg text-cream">
                    {active.label} <span className="script text-base text-gold-300/80">{active.urdu}</span>
                  </p>
                  <p className="text-[0.78rem] text-sand/70">{active.blurb}</p>
                </div>
              </div>
              <Link href="/menu" className="btn btn-ghost !px-4 !py-2 !text-[0.64rem]">
                <Icon name="close" className="h-3.5 w-3.5" strokeWidth={2.2} />
                Show all kitchens
              </Link>
            </div>
          </Reveal>
        )}

        <Suspense
          fallback={
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {Array.from({ length: 8 }).map((_, index) => (
                <div key={index} className="h-80 animate-pulse rounded-[1.35rem] border border-cream/8 bg-cream/[0.03]" />
              ))}
            </div>
          }
        >
          <MenuBrowser key={c ?? "all"} dishes={dishes} />
        </Suspense>
      </Section>

      <Section className="pt-0">
        <Reveal>
          <div className="glass flex flex-col items-start justify-between gap-6 rounded-[1.75rem] p-8 lg:flex-row lg:items-center">
            <div>
              <h2 className="text-2xl text-cream">Can't find your favourite dish?</h2>
              <p className="mt-2 max-w-2xl text-[0.88rem] leading-relaxed text-sand/70">
                Our kitchen prepares custom orders — less spicy, no onion, extra gravy, bigger portions, dietary
                adjustments and off-menu desi dishes on request. Tell us what you want and we will cook it.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <a
                href={whatsappLink(`Assalam-o-Alaikum ${SITE.name}! I would like a custom order:`)}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-gold"
              >
                <Icon name="phone" className="h-4 w-4" />
                Ask on WhatsApp
              </a>
              <Link href="/contact" className="btn btn-outline">
                <Icon name="mail" className="h-4 w-4" />
                Contact the kitchen
              </Link>
            </div>
          </div>
        </Reveal>

        <Reveal delay={80}>
          <p className="mt-6 text-center text-[0.74rem] leading-relaxed text-sand/45">
            All prices are in Pakistani Rupees (PKR) and are inclusive of standard preparation. Government taxes, where
            applicable, are shown separately at checkout. Menu items are subject to daily availability — BBQ counters
            fire up from 5:00 PM and breakfast runs 7:00 AM to 11:30 AM.
          </p>
        </Reveal>
      </Section>
    </>
  );
}
