import type { Metadata } from "next";
import Link from "next/link";

import { GalleryGrid } from "@/components/gallery/gallery-grid";
import { PageHero } from "@/components/layout/page-hero";
import { Icon } from "@/components/ui/icons";
import { Reveal } from "@/components/ui/reveal";
import { Section, SectionHeading } from "@/components/ui/section";
import { SmartImage } from "@/components/ui/smart-image";
import { GALLERY } from "@/lib/data/content";
import { IMG, LOCAL } from "@/lib/data/images";
import { SITE } from "@/lib/site";

export const metadata: Metadata = {
  title: "Gallery — Food, Kitchen & Dining Room Photography",
  description:
    "Photo gallery of MASSTANA RESTAURANT in Sargodha: charcoal BBQ, dum biryani, Chinese wok flames, desserts, drinks, the dining room and our delivery riders.",
  alternates: { canonical: "/gallery" },
};

const MOMENTS = [
  { title: "Coal & smoke", body: "Every kabab meets live charcoal between 5 PM and 1 AM.", image: IMG.kebabSizzle },
  { title: "Wok fire", body: "Chinese section at full flame — wok hei you can taste.", image: IMG.chineseKitchen },
  { title: "Dum sealing", body: "Biryani handi sealed with dough, steamed for 40 minutes.", image: IMG.biryaniBrass },
  { title: "Sweet counter", body: "Kheer, kulfi and brownies finished in-house every morning.", image: IMG.kulfi },
];

export default function GalleryPage() {
  return (
    <>
      <PageHero
        eyebrow="Gallery"
        title="A look inside"
        highlight="Masstana"
        description="Food, fire, plating and the people behind it — captured in our kitchen and dining room at 49 Tail, Sargodha."
        image={IMG.dimTable}
        crumb="Gallery"
      />

      <Section className="pt-12">
        <SectionHeading
          eyebrow={`${GALLERY.length} photographs`}
          title="Moments from"
          highlight="our kitchen & table"
          description="Tap any photograph to open it full screen. Use the arrow keys to move through the gallery."
        />
      </Section>

      <Section className="pt-0">
        <GalleryGrid items={GALLERY} />
      </Section>

      <Section className="border-y border-gold-400/10 bg-noir-900/40">
        <SectionHeading eyebrow="Behind the pass" title="Four moments that" highlight="define our taste" />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {MOMENTS.map((moment, index) => (
            <Reveal key={moment.title} delay={index * 90} className="h-full">
              <article className="group h-full overflow-hidden rounded-[1.5rem] border border-gold-400/12 transition duration-500 hover:border-gold-400/45">
                <div className="relative overflow-hidden">
                  <SmartImage
                    src={moment.image}
                    alt={moment.title}
                    className="aspect-[4/5] w-full"
                    imgClassName="transition-transform duration-[900ms] group-hover:scale-110"
                    sizes="(max-width:640px) 92vw, 24vw"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-noir-950 via-noir-950/30 to-transparent" />
                </div>
                <div className="-mt-14 relative p-5">
                  <h3 className="font-display text-xl text-gold-200">{moment.title}</h3>
                  <p className="mt-1.5 text-[0.82rem] leading-relaxed text-sand/70">{moment.body}</p>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section>
        <Reveal>
          <div className="relative overflow-hidden rounded-[2rem] border border-gold-400/20">
            <SmartImage src={LOCAL.interior} alt="Masstana dining room" className="aspect-[16/9] w-full" imgClassName="opacity-60" />
            <div className="absolute inset-0 bg-gradient-to-r from-noir-950 via-noir-950/70 to-transparent" />
            <div className="absolute inset-0 flex flex-col justify-center gap-5 p-8 sm:p-14">
              <span className="eyebrow">Visit us</span>
              <h2 className="max-w-xl text-3xl leading-tight text-cream sm:text-4xl">
                Pictures are nice. <span className="gold-text">The smell of charcoal is better.</span>
              </h2>
              <p className="max-w-lg text-[0.9rem] text-sand/75">
                {SITE.addressLine} · open daily from 7:00 AM. Family halls, private rooms and outdoor seating available.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/order" className="btn btn-gold">
                  <Icon name="bag" className="h-4 w-4" />
                  Order online
                </Link>
                <a href={SITE.mapLinkUrl} target="_blank" rel="noopener noreferrer" className="btn btn-outline">
                  <Icon name="map" className="h-4 w-4" />
                  Get directions
                </a>
              </div>
            </div>
          </div>
        </Reveal>
      </Section>
    </>
  );
}
