import type { Metadata } from "next";
import Link from "next/link";

import { FaqAccordion } from "@/components/faq/faq-accordion";
import { PageHero } from "@/components/layout/page-hero";
import { Icon } from "@/components/ui/icons";
import { Reveal } from "@/components/ui/reveal";
import { Section, SectionHeading } from "@/components/ui/section";
import { FAQS } from "@/lib/data/content";
import { IMG } from "@/lib/data/images";
import { SITE, whatsappLink } from "@/lib/site";

export const metadata: Metadata = {
  title: "FAQ — Ordering, Delivery, Menu & Payments",
  description:
    "Frequently asked questions about MASSTANA RESTAURANT Sargodha: how online ordering works, delivery areas and charges, halal meat, custom spice levels, reservations, catering and payment methods.",
  alternates: { canonical: "/faq" },
};

const QUICK_ANSWERS = [
  {
    icon: "clock",
    title: "Opening hours",
    body: "Mon–Thu 7 AM – 1 AM · Fri–Sun 7 AM – 2:30 AM. Breakfast 7–11:30 AM, BBQ grill from 5 PM.",
    href: "/contact",
    cta: "See timings",
  },
  {
    icon: "bike",
    title: "Delivery charges",
    body: "From Rs 120 inside Satellite Town up to Rs 250 for outer zones. Free above Rs 3,000.",
    href: "/delivery",
    cta: "Delivery areas",
  },
  {
    icon: "tag",
    title: "Active promo codes",
    body: "MASS10, FAMILY20, STUDENT15, FREESHIP, BBQ25, LATE15, FIRST500 and SWEET100.",
    href: "/offers",
    cta: "See offers",
  },
  {
    icon: "receipt",
    title: "Payment",
    body: "Cash on delivery and counter cash by default. EasyPaisa, JazzCash, bank transfer and card for bulk orders.",
    href: "/order",
    cta: "Start ordering",
  },
];

export default function FaqPage() {
  return (
    <>
      <PageHero
        eyebrow="FAQ"
        title="Questions we get"
        highlight="every single day"
        description="Ordering, delivery, menu customisation, reservations, catering, payments and hygiene — answered plainly. Still stuck? Call or WhatsApp us."
        image={IMG.marbleTable}
        crumb="FAQ"
      />

      <Section className="pt-12">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {QUICK_ANSWERS.map((card, index) => (
            <Reveal key={card.title} delay={index * 80} className="h-full">
              <Link
                href={card.href}
                className="tilt-card flex h-full flex-col gap-3 rounded-2xl border border-gold-400/12 bg-gradient-to-br from-noir-800/70 to-noir-950/85 p-6"
              >
                <span className="grid h-11 w-11 place-items-center rounded-xl border border-gold-400/25 bg-gold-400/8 text-gold-300">
                  <Icon name={card.icon} className="h-5 w-5" />
                </span>
                <h2 className="text-[1.05rem] text-cream">{card.title}</h2>
                <p className="flex-1 text-[0.82rem] leading-relaxed text-sand/65">{card.body}</p>
                <span className="inline-flex items-center gap-2 text-[0.7rem] font-bold uppercase tracking-[0.16em] text-gold-300">
                  {card.cta}
                  <Icon name="arrowRight" className="h-3.5 w-3.5" />
                </span>
              </Link>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section className="pt-0">
        <SectionHeading
          eyebrow={`${FAQS.length} answers`}
          title="Everything you wanted"
          highlight="to ask us"
        />
        <div className="mx-auto mt-12 max-w-4xl">
          <FaqAccordion faqs={FAQS} />
        </div>
      </Section>

      <Section className="pt-0">
        <Reveal>
          <div className="glass-gold mx-auto flex max-w-4xl flex-col items-center gap-5 rounded-[1.75rem] p-8 text-center sm:p-10">
            <Icon name="chef" className="h-10 w-10 text-gold-200" />
            <h2 className="text-2xl text-cream sm:text-3xl">Ask {SITE.owner} directly</h2>
            <p className="max-w-xl text-[0.9rem] leading-relaxed text-sand/75">
              Menu changes, bulk orders, wedding catering quotations, private dining or a complaint — the owner answers
              personally during opening hours.
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              <a href={SITE.phoneHref} className="btn btn-gold">
                <Icon name="phone" className="h-4 w-4" />
                {SITE.phoneDisplay}
              </a>
              <a
                href={whatsappLink(`Assalam-o-Alaikum ${SITE.name}, I have a question:`)}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-outline"
              >
                <Icon name="mail" className="h-4 w-4" />
                WhatsApp us
              </a>
              <Link href="/contact" className="btn btn-ghost">
                Contact form
              </Link>
            </div>
            <p className="text-[0.7rem] text-sand/50">
              Phone numbers on this site are placeholders until the restaurant confirms its live lines.
            </p>
          </div>
        </Reveal>
      </Section>
    </>
  );
}
