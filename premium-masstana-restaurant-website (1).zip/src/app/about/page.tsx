import type { Metadata } from "next";
import Link from "next/link";

import { PageHero } from "@/components/layout/page-hero";
import { Icon } from "@/components/ui/icons";
import { CountUp, Reveal } from "@/components/ui/reveal";
import { Section, SectionHeading } from "@/components/ui/section";
import { SmartImage } from "@/components/ui/smart-image";
import { FEATURES, STATS, TEAM, TIMELINE } from "@/lib/data/content";
import { IMG, LOCAL } from "@/lib/data/images";
import { SITE, whatsappLink } from "@/lib/site";

export const metadata: Metadata = {
  title: "About Us — The Story of Masstana Restaurant & Faiz Guru",
  description:
    "Meet Faiz Guru, founder of MASSTANA RESTAURANT at 49 Tail, Sargodha. From a single tawa in 2014 to a multi-cuisine kitchen with charcoal BBQ, Chinese wok, continental grill and in-house desserts.",
  alternates: { canonical: "/about" },
};

const VALUES = [
  { icon: "flame", title: "Cooked to order", body: "Nothing is pre-cooked in bulk. Your karahi and kababs start when your order lands." },
  { icon: "leaf", title: "Halal & daily fresh", body: "Meat, dairy and vegetables sourced every morning from Sargodha suppliers." },
  { icon: "heart", title: "Honest portions", body: "Weights are printed on the menu and measured on a scale — no shrinking plates." },
  { icon: "shield", title: "Clean kitchen", body: "Open kitchen, daily oil changes, sanitised prep tables and gloves in every section." },
];

export default function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About us"
        title="The house that"
        highlight="charcoal built"
        description="Twelve years, one address and a family recipe book that keeps growing. This is Masstana — Sargodha's multi-cuisine kitchen run by Faiz Guru."
        image={IMG.elegantDark}
        crumb="About Us"
      />

      {/* --------- Story --------- */}
      <Section className="pt-12">
        <div className="grid items-center gap-14 lg:grid-cols-[0.95fr_1.05fr]">
          <Reveal>
            <div className="relative">
              <div className="overflow-hidden rounded-[2rem] border border-gold-400/20">
                <SmartImage
                  src={LOCAL.owner}
                  alt={`${SITE.owner}, founder and head chef of ${SITE.name}`}
                  className="aspect-[4/5] w-full"
                  sizes="(max-width:1024px) 92vw, 42vw"
                  priority
                />
              </div>
              <div className="glass-gold absolute -bottom-6 left-6 right-6 rounded-2xl p-5 text-center sm:left-10 sm:right-10">
                <p className="script text-3xl text-gold-200">Faiz Guru</p>
                <p className="mt-1 text-[0.62rem] font-bold uppercase tracking-[0.28em] text-sand/70">
                  Founder &amp; Head Chef · since {SITE.since}
                </p>
              </div>
              <div className="pointer-events-none absolute -right-4 -top-4 h-28 w-28 rounded-full border border-gold-400/25" />
              <div className="pointer-events-none absolute -right-8 -top-8 h-28 w-28 rounded-full border border-gold-400/12" />
            </div>
          </Reveal>

          <div>
            <SectionHeading
              align="left"
              eyebrow="Our story"
              title="It started with one tawa,"
              highlight="a chai kettle and a promise"
            />
            <div className="mt-6 space-y-4 text-[0.92rem] leading-relaxed text-sand/78">
              <Reveal delay={80}>
                <p>
                  In {SITE.since}, <span className="text-gold-200">{SITE.owner}</span> set up a single tawa on 49 Tail in
                  Sargodha with a paratha recipe from his mother and a chai kettle that never cooled. Twenty plates a day,
                  sold out by noon. Guests kept asking for more — kababs, then karahi, then biryani.
                </p>
              </Reveal>
              <Reveal delay={140}>
                <p>
                  Every addition came the same way: learn it properly, cook it fresh, taste it yourself before it goes on
                  the menu. Today Masstana runs four specialised sections — desi handi and dum, a live charcoal BBQ grill,
                  a Chinese wok counter and a continental grill — plus a bakery and dessert counter that makes kheer, kulfi
                  and brownies in-house every morning.
                </p>
              </Reveal>
              <Reveal delay={200}>
                <p>
                  We still do the things that made the first twenty plates work: halal meat bought fresh every morning,
                  masala ground in-house, kababs cooked over real coal, and portions weighed rather than guessed. The
                  dining room seats 120 with family halls and private party rooms, our riders cover an {SITE.city} radius of
                  18 km, and the kitchen stays open until 2 AM for the city's midnight cravings.
                </p>
              </Reveal>
            </div>

            <Reveal delay={240}>
              <blockquote className="mt-8 rounded-2xl border-l-2 border-gold-400/60 bg-cream/[0.03] p-6">
                <p className="font-display text-lg leading-relaxed text-cream">
                  “A restaurant is not a building. It is the smell that reaches the street and the plate that comes back
                  empty. Everything else is decoration.”
                </p>
                <footer className="mt-3 text-[0.76rem] uppercase tracking-[0.2em] text-gold-300">
                  {SITE.owner} · {SITE.ownerTitle}
                </footer>
              </blockquote>
            </Reveal>
          </div>
        </div>
      </Section>

      {/* --------- Stats --------- */}
      <Section className="border-y border-gold-400/10 bg-noir-900/40">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {STATS.map((stat, index) => {
            const numeric = parseFloat(stat.value.replace(/[^0-9.]/g, ""));
            const suffix = stat.value.replace(/[0-9.]/g, "");
            return (
              <Reveal key={stat.label} delay={index * 90}>
                <div className="glass tilt-card rounded-2xl p-7 text-center">
                  <p className="font-display text-4xl gold-text">
                    <CountUp value={numeric} suffix={suffix} />
                  </p>
                  <p className="mt-2 text-[0.7rem] uppercase tracking-[0.18em] text-sand/60">{stat.label}</p>
                </div>
              </Reveal>
            );
          })}
        </div>
      </Section>

      {/* --------- Timeline --------- */}
      <Section>
        <SectionHeading
          eyebrow="Milestones"
          title="Twelve years of"
          highlight="growth & flavour"
          description="How a street-side tawa became a full multi-cuisine restaurant with its own delivery fleet."
        />
        <div className="relative mx-auto mt-14 max-w-4xl">
          <div className="absolute left-4 top-0 h-full w-px bg-gradient-to-b from-gold-400/60 via-gold-400/25 to-transparent sm:left-1/2" />
          <div className="space-y-8">
            {TIMELINE.map((entry, index) => (
              <Reveal key={entry.year} delay={index * 70}>
                <div className={`relative flex gap-6 sm:w-1/2 ${index % 2 === 1 ? "sm:ml-auto sm:flex-row-reverse sm:text-right" : ""}`}>
                  <span className="absolute left-4 top-6 z-10 h-3 w-3 -translate-x-1/2 rounded-full bg-gradient-to-br from-gold-300 to-ember-500 shadow-[0_0_0_5px_rgba(217,169,79,0.14)] sm:left-auto sm:right-0 sm:translate-x-1/2" />
                  <div className={`ml-10 flex-1 sm:ml-0 ${index % 2 === 1 ? "sm:mr-10" : "sm:mr-0 sm:ml-10"}`}>
                    <div className="glass tilt-card rounded-2xl p-6">
                      <span className="font-display text-2xl gold-text">{entry.year}</span>
                      <h3 className="mt-2 text-lg text-cream">{entry.title}</h3>
                      <p className="mt-2 text-[0.85rem] leading-relaxed text-sand/70">{entry.body}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </Section>

      {/* --------- Features --------- */}
      <Section className="border-y border-gold-400/10 bg-noir-900/40">
        <SectionHeading
          eyebrow="Why guests choose us"
          title="Six reasons Sargodha"
          highlight="keeps coming back"
        />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((feature, index) => (
            <Reveal key={feature.title} delay={(index % 3) * 90} className="h-full">
              <article className="tilt-card group h-full rounded-[1.5rem] border border-gold-400/12 bg-gradient-to-br from-noir-800/70 to-noir-950/85 p-7">
                <span className="grid h-13 w-13 place-items-center rounded-2xl border border-gold-400/25 bg-gold-400/8 p-3.5 text-gold-300 transition duration-500 group-hover:scale-110 group-hover:text-gold-100">
                  <Icon name={feature.icon} className="h-6 w-6" />
                </span>
                <h3 className="mt-5 text-xl text-cream">{feature.title}</h3>
                <p className="mt-2.5 text-[0.86rem] leading-relaxed text-sand/70">{feature.body}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </Section>

      {/* --------- Values --------- */}
      <Section>
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <Reveal>
            <div className="overflow-hidden rounded-[2rem] border border-gold-400/15">
              <SmartImage src={IMG.kitchenFlame} alt="Masstana kitchen at full flame" className="aspect-[4/3] w-full" sizes="(max-width:1024px) 92vw, 46vw" />
            </div>
          </Reveal>
          <div>
            <SectionHeading align="left" eyebrow="Our standards" title="Four rules we" highlight="never break" />
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              {VALUES.map((value, index) => (
                <Reveal key={value.title} delay={index * 80}>
                  <div className="h-full rounded-2xl border border-cream/8 bg-cream/[0.02] p-5 transition duration-400 hover:border-gold-400/40">
                    <Icon name={value.icon} className="h-6 w-6 text-gold-300" />
                    <h3 className="mt-3 text-[1rem] text-cream">{value.title}</h3>
                    <p className="mt-1.5 text-[0.82rem] leading-relaxed text-sand/65">{value.body}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </Section>

      {/* --------- Team --------- */}
      <Section className="border-t border-gold-400/10 bg-noir-900/40">
        <SectionHeading
          eyebrow="The people"
          title="Hands behind"
          highlight="every plate"
          description="Each kitchen section has its own specialist — that is why the biryani never tastes like the chow mein."
        />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {TEAM.map((member, index) => (
            <Reveal key={member.name} delay={(index % 4) * 80} className="h-full">
              <article className="group h-full overflow-hidden rounded-[1.5rem] border border-gold-400/12 bg-noir-950/60 transition duration-500 hover:border-gold-400/45">
                <div className="relative overflow-hidden">
                  <SmartImage
                    src={member.image}
                    alt={member.name}
                    className="aspect-[4/5] w-full"
                    imgClassName="transition-transform duration-[900ms] group-hover:scale-110"
                    sizes="(max-width:640px) 92vw, 24vw"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-noir-950 via-transparent to-transparent" />
                </div>
                <div className="-mt-12 relative p-5">
                  <h3 className="font-display text-xl text-gold-200">{member.name}</h3>
                  <p className="mt-1 text-[0.66rem] font-bold uppercase tracking-[0.18em] text-sand/55">{member.role}</p>
                  <p className="mt-3 text-[0.82rem] leading-relaxed text-sand/70">{member.bio}</p>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </Section>

      {/* --------- CTA --------- */}
      <Section>
        <Reveal>
          <div className="relative overflow-hidden rounded-[2rem] border border-gold-400/25 bg-gradient-to-br from-[#1c1421] via-noir-900 to-[#251710] p-8 sm:p-14">
            <div className="pointer-events-none absolute -left-16 -top-16 h-64 w-64 rounded-full bg-gold-500/15 blur-[100px] animate-ember" />
            <div className="relative grid items-center gap-8 lg:grid-cols-[1.5fr_1fr]">
              <div>
                <span className="eyebrow">Come taste the difference</span>
                <h2 className="mt-4 text-3xl leading-tight text-cream sm:text-4xl">
                  {SITE.addressLine} — <span className="gold-text">we save you a seat</span>
                </h2>
                <p className="mt-4 max-w-xl text-[0.92rem] leading-relaxed text-sand/75">
                  Dine in with the family, collect takeaway at the counter, or order online and let our rider bring it
                  hot. Breakfast from 7 AM, BBQ from 5 PM, kitchen open till 2 AM.
                </p>
              </div>
              <div className="grid gap-3">
                <Link href="/order" className="btn btn-gold w-full">
                  <Icon name="bag" className="h-4 w-4" />
                  Order online
                </Link>
                <Link href="/menu" className="btn btn-outline w-full">
                  <Icon name="utensils" className="h-4 w-4" />
                  See the menu
                </Link>
                <a
                  href={whatsappLink(`Assalam-o-Alaikum ${SITE.name}! I would like to book a table.`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-ghost w-full"
                >
                  <Icon name="phone" className="h-4 w-4" />
                  Book a table
                </a>
              </div>
            </div>
          </div>
        </Reveal>
      </Section>
    </>
  );
}
