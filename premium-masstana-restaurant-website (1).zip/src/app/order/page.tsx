import type { Metadata } from "next";
import Link from "next/link";

import { PageHero } from "@/components/layout/page-hero";
import { Checkout } from "@/components/order/checkout";
import { Icon } from "@/components/ui/icons";
import { Reveal } from "@/components/ui/reveal";
import { Section, SectionHeading } from "@/components/ui/section";
import { IMG } from "@/lib/data/images";
import { DELIVERY_STEPS } from "@/lib/data/content";
import { getMenuItems } from "@/lib/services";
import { DELIVERY, IS_WHATSAPP_PLACEHOLDER, SITE, WHATSAPP_NUMBER, formatPKR } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Online Ordering — Cart, Checkout & WhatsApp Orders",
  description:
    "Order online from MASSTANA RESTAURANT Sargodha: add dishes to your cart, apply promo codes, choose home delivery or takeaway, and confirm on WhatsApp. Prices in PKR.",
  alternates: { canonical: "/order" },
};

export default async function OrderPage() {
  const dishes = await getMenuItems();
  const suggestions = dishes.filter((dish) => dish.popular).slice(0, 6);

  return (
    <>
      <PageHero
        compact
        eyebrow="Online ordering"
        title="Your cart, your"
        highlight="rules"
        description="Home delivery, takeaway or dine-in — one cart, live totals, promo codes and a WhatsApp order message generated for you."
        image={IMG.buffetTable}
        crumb="Order Online"
      />

      <Section className="pt-10">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: "clock", title: `${DELIVERY.prepTime} min`, body: "Average delivery inside Sargodha" },
            { icon: "receipt", title: formatPKR(DELIVERY.minOrder), body: "Minimum order value" },
            { icon: "bike", title: formatPKR(DELIVERY.freeOver), body: "Orders above this deliver free" },
            { icon: "shield", title: "Pay on delivery", body: "Cash, EasyPaisa, JazzCash or card" },
          ].map((card, index) => (
            <Reveal key={card.title} delay={index * 70}>
              <div className="glass tilt-card flex items-center gap-4 rounded-2xl p-5">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-gold-400/25 bg-gold-400/8 text-gold-300">
                  <Icon name={card.icon} className="h-5 w-5" />
                </span>
                <span>
                  <span className="block font-display text-lg text-gold-200">{card.title}</span>
                  <span className="block text-[0.74rem] text-sand/60">{card.body}</span>
                </span>
              </div>
            </Reveal>
          ))}
        </div>

        <div className="mt-10">
          <Checkout suggestions={suggestions} />
        </div>
      </Section>

      <Section className="border-t border-gold-400/10 bg-noir-900/40">
        <SectionHeading eyebrow="How it works" title="Five steps from" highlight="craving to doorstep" />
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
          {DELIVERY_STEPS.map((step, index) => (
            <Reveal key={step.step} delay={index * 70} className="h-full">
              <div className="tilt-card flex h-full flex-col gap-3 rounded-2xl border border-gold-400/12 bg-noir-950/60 p-6">
                <span className="font-display text-3xl text-gold-400/40">{step.step}</span>
                <h3 className="text-[1.02rem] text-cream">{step.title}</h3>
                <p className="text-[0.82rem] leading-relaxed text-sand/65">{step.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section className="pt-14">
        <Reveal>
          <div className="glass mx-auto max-w-4xl rounded-[1.75rem] p-8">
            <h2 className="flex items-center gap-3 text-xl text-cream">
              <Icon name="sparkle" className="h-6 w-6 text-gold-300" />
              How this ordering demo works
            </h2>
            <ul className="mt-5 grid gap-4 text-[0.86rem] leading-relaxed text-sand/75 sm:grid-cols-2">
              <li className="flex gap-3">
                <Icon name="check" className="mt-1 h-4 w-4 shrink-0 text-gold-400" strokeWidth={2.4} />
                <span>
                  <strong className="text-cream">Real cart &amp; pricing.</strong> Quantities, subtotal, zone-based
                  delivery fees, promo discounts and totals all calculate live in your browser and persist if you close
                  the tab.
                </span>
              </li>
              <li className="flex gap-3">
                <Icon name="check" className="mt-1 h-4 w-4 shrink-0 text-gold-400" strokeWidth={2.4} />
                <span>
                  <strong className="text-cream">Orders hit a real API.</strong> Placing an order POSTs to{" "}
                  <code className="rounded bg-noir-950/70 px-1.5 py-0.5 text-gold-200">/api/orders</code> and is written to
                  the PostgreSQL database through Drizzle ORM, returning an order code like MST-20260214-X7K2.
                </span>
              </li>
              <li className="flex gap-3">
                <Icon name="check" className="mt-1 h-4 w-4 shrink-0 text-gold-400" strokeWidth={2.4} />
                <span>
                  <strong className="text-cream">WhatsApp confirmation.</strong> A formatted order message is generated for
                  the restaurant. {IS_WHATSAPP_PLACEHOLDER ? `The number is still the placeholder ${WHATSAPP_NUMBER}.` : "Orders go straight to the owner's WhatsApp."}
                </span>
              </li>
              <li className="flex gap-3">
                <Icon name="check" className="mt-1 h-4 w-4 shrink-0 text-gold-400" strokeWidth={2.4} />
                <span>
                  <strong className="text-cream">No payment gateway.</strong> Nothing is charged online — payment is cash
                  on delivery, at the counter, or by EasyPaisa/JazzCash for bulk orders.
                </span>
              </li>
            </ul>

            <div className="mt-6 rounded-2xl border border-ember-400/25 bg-ember-500/8 p-5 text-[0.82rem] leading-relaxed text-ember-200/90">
              <p className="flex items-center gap-2 font-bold uppercase tracking-[0.14em] text-ember-300">
                <Icon name="sparkle" className="h-4 w-4" />
                Owner setup checklist
              </p>
              <ol className="mt-3 space-y-1.5 pl-5 [&>li]:list-decimal">
                <li>
                  Set the real WhatsApp number in <code className="text-gold-200">src/lib/site.ts</code> (or via{" "}
                  <code className="text-gold-200">NEXT_PUBLIC_WHATSAPP_NUMBER</code>) in international format, e.g.
                  923001234567.
                </li>
                <li>Replace the placeholder phone lines with the restaurant's real numbers.</li>
                <li>Confirm the exact Google Maps pin for {SITE.addressLine}.</li>
              </ol>
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/menu" className="btn btn-outline">
                <Icon name="utensils" className="h-4 w-4" />
                Back to menu
              </Link>
              <Link href="/offers" className="btn btn-ghost">
                <Icon name="tag" className="h-4 w-4" />
                See promo codes
              </Link>
              <Link href="/delivery" className="btn btn-ghost">
                <Icon name="bike" className="h-4 w-4" />
                Delivery areas
              </Link>
            </div>
          </div>
        </Reveal>
      </Section>
    </>
  );
}
