# MASSTANA RESTAURANT — Premium Multi-Page Restaurant Website

A complete, production-grade restaurant website for **MASSTANA RESTAURANT** (Owner: **Faiz Guru**, 49 Tail, Sargodha,
Pakistan). Built with **Next.js 16 (App Router, Turbopack) + React 19 + TypeScript + Tailwind CSS v4 + Drizzle ORM +
PostgreSQL**.

Dark luxury theme (obsidian black · royal gold · warm ember orange), glassmorphism, scroll-reveal animations,
a working cart with promo codes, and a real order API.

---

## 1. Pages

| Route | Page | What it contains |
| --- | --- | --- |
| `/` | Home | Hero with animated statistics, story, signature dishes, 8 kitchen categories, offers, delivery promo, deals, reviews, CTA |
| `/menu` | Menu | 96 dishes across 8 categories — search, category chips, sort, veg/spicy/bestseller filters, price filter, grouped browsing |
| `/about` | About Us | Story, founder profile (Faiz Guru), milestones timeline, 6 features, 4 values, 4 team members, animated stats |
| `/gallery` | Gallery | 24-photo masonry gallery with filters + full-screen lightbox (keyboard arrows / Esc) |
| `/order` | Online Ordering | Cart review, quantity controls, order type, delivery zone, promo codes, checkout form, order confirmation, WhatsApp order |
| `/delivery` | Home Delivery | 10 delivery zones with fees & ETA, packaging standards, 5-step process, 8 order instructions, coverage map |
| `/offers` | Offers | 8 promo codes with copy-to-clipboard, headline offer, all combo deals, terms & conditions |
| `/contact` | Contact Us | Address / phone / email cards, contact form (saves to DB), opening hours, socials, Google Maps section |
| `/reviews` | Customer Reviews | Rating summary with distribution bars, star filters, review wall, working "write a review" form |
| `/faq` | FAQ | 15 questions in 6 groups, accordion, search, quick-answer cards |

Plus `sitemap.xml`, `robots.txt`, a custom `404` page and JSON-LD `Restaurant` structured data.

---

## 2. Run it locally

```bash
# 1. Install dependencies
npm install

# 2. Create .env (a DATABASE_URL is already provided in this project)
echo "DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db" > .env
# Optional — set the real WhatsApp number (international format, no + or spaces):
# echo "NEXT_PUBLIC_WHATSAPP_NUMBER=923001234567" >> .env

# 3. Create the database tables
npx drizzle-kit push

# 4. Start the dev server
npm run dev            # http://localhost:3000

# Production
npm run build && npm start
```

**Seeding:** no manual seed step is required. The first request to `/menu` (or `GET /api/menu`) inserts all 96 dishes
into `menu_items`, and the first request to `/reviews` inserts 10 starter reviews. Both operations are idempotent and
fall back to the bundled dataset if the database is unreachable, so the site never renders broken.

---

## 3. ⚠️ Owner setup checklist (before going live)

1. **WhatsApp number** — currently the placeholder `YOUR_WHATSAPP_NUMBER`.
   Set the real number in **`src/lib/site.ts`**:
   ```ts
   export const WHATSAPP_NUMBER = "923001234567"; // your real number
   ```
   …or set the environment variable `NEXT_PUBLIC_WHATSAPP_NUMBER=923001234567`.
   Until then the WhatsApp buttons open the generic `wa.me` picker and a reminder banner is shown in the footer and on
   the order page.
2. **Phone lines** — `SITE.phoneDisplay` / `SITE.phoneAltDisplay` are placeholders (`+92 300 000 0000`).
3. **Google Maps pin** — `SITE.mapQuery` / `SITE.mapEmbedUrl` point at 49 Tail, Sargodha as a *placeholder*. Replace
   with the exact pin once confirmed; the pages show a "Placeholder location" badge until then.
4. **Email & socials** — update `SITE.email` and the social links in `src/lib/site.ts`.

---

## 4. Ordering system — what is real and what is demo

**Real (works end-to-end in this build):**

- Cart state with quantity controls, remove, clear, order type, delivery zone and promo codes
- Live totals: subtotal → zone delivery fee (free above Rs 3,000) → promo discount → total in PKR
- Cart persistence in `localStorage` (survives a refresh)
- `POST /api/orders` writes the order to PostgreSQL via Drizzle and returns an order code like `MST-20260214-X7K2`
- `POST /api/reviews` and `POST /api/contact` also persist to the database
- WhatsApp order message generation (formatted, itemised, with totals and address)

**Demo / not included:**

- **No payment gateway.** Nothing is charged online — payment is cash on delivery, at the counter, or by
  EasyPaisa/JazzCash for bulk orders.
- **No admin dashboard / kitchen display.** Orders can be inspected via `GET /api/orders` (latest 20) or directly in the
  `orders` table.
- Promo codes are validated against the offers defined in `src/lib/data/content.ts` (not a campaign system).
- Prices, dishes, offers, zones and reviews are sample data for a fictional restaurant.

---

## 5. API

| Method | Endpoint | Purpose |
| --- | --- | --- |
| `GET` | `/api/health` | Health check |
| `GET` | `/api/menu?category=&q=` | Menu catalogue (self-seeding) |
| `POST` | `/api/orders` | Create an order → `{ ok, code, persisted, totals }` |
| `GET` | `/api/orders` | Latest 20 orders (summary) |
| `GET` | `/api/reviews` | Reviews + average rating |
| `POST` | `/api/reviews` | Publish a guest review |
| `POST` | `/api/contact` | Save a contact-form message |

---

## 6. Database schema (`src/db/schema.ts`)

- **`menu_items`** — id (slug), name, category, description, price, old_price, image, tags (jsonb), rating, serves,
  popular, available, sort_order
- **`orders`** — code, customer, phone, address, area, order_type, notes, payment_method, items (jsonb), item_count,
  subtotal, delivery_fee, discount, total, promo_code, status, channel, created_at
- **`reviews`** — name, city, rating, title, body, dish, source, approved, created_at
- **`contact_messages`** — name, email, phone, subject, message, kind, created_at

All money columns are integers in **PKR**.

---

## 7. Project structure

```
src/
├─ app/
│  ├─ layout.tsx            fonts, metadata, JSON-LD, providers, navbar, footer, cart drawer, preloader
│  ├─ page.tsx              home
│  ├─ menu/ about/ gallery/ order/ delivery/ offers/ contact/ reviews/ faq/
│  ├─ not-found.tsx, sitemap.ts, robots.ts
│  └─ api/  health · menu · orders · reviews · contact
├─ components/
│  ├─ layout/   navbar · footer · newsletter · page-hero · site-chrome (preloader, scroll progress, back-to-top)
│  ├─ cart/     cart-provider (context + localStorage + promo engine) · cart-drawer (+ toast)
│  ├─ ui/       food-card · deal-card · icons (inline SVG) · reveal/count-up · section · smart-image
│  ├─ menu/     menu-browser (search, filters, sort, grouped view)
│  ├─ order/    checkout (cart, form, validation, API, WhatsApp, confirmation)
│  ├─ offers/   offer-grid (copy promo code)
│  ├─ gallery/  gallery-grid (masonry + lightbox)
│  ├─ reviews/  review-wall (summary, filters, write-a-review)
│  ├─ faq/      faq-accordion (groups + search)
│  └─ contact/  contact-form
├─ db/          index.ts (Drizzle pool) · schema.ts
└─ lib/
   ├─ site.ts       ⚠️ brand + contact config, WhatsApp placeholder, delivery rules, formatPKR
   ├─ navigation.ts shared nav links
   ├─ services.ts   DB access with self-seeding + graceful fallbacks
   ├─ types.ts      shared types
   ├─ whatsapp.ts   formatted WhatsApp order message builder
   └─ data/         menu.ts (96 dishes) · content.ts (offers, zones, gallery, reviews, faqs, story) · images.ts
public/images/      locally generated brand imagery (hero, owner, interior, delivery)
```

---

## 8. Design & performance notes

- Typography: **Marcellus** (display), **Manrope** (body), **Parisienne** (script accent) via Google Fonts.
- All motion uses CSS transforms/opacity with consistent 0.28–0.75 s easings (`cubic-bezier(0.22, 1, 0.36, 1)`), and the
  entire site respects `prefers-reduced-motion`.
- Scroll reveals use a single `IntersectionObserver` per element and unobserve after firing — no scroll-event jank.
- Images are lazy-loaded (`loading="lazy"`, `decoding="async"`), served at card-sized dimensions from the CDN, and every
  image has a shimmer placeholder plus a branded fallback so a failed request never shows a broken-image icon.
- Fully responsive: 1 → 2 → 3 → 4 column grids, mobile navigation drawer, mobile cart drawer, horizontally scrollable
  filter rails.
- SEO: per-page titles/descriptions, canonical URLs, Open Graph + Twitter cards, `sitemap.xml`, `robots.txt` and
  `Restaurant` JSON-LD with opening hours, cuisine, price range and address.
